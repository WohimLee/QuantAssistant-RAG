---
# Converted from: other\foreign_future_main_contracts\index.html
---

# 境外主连合约  
  
合约代码 | 合约名称  
---|---  
CBOT_Cmain | 玉米 主连  
CBOT_Omain | OATS  
CBOT_Smain | 大豆 主连  
CBOT_Wmain | 小麦 主连  
CBOT_YCmain | MINI CORN  
CBOT_YMmain | 迷你道指 主连  
CBOT_ZBmain | 三十年美债 主连  
CBOT_ZLmain | 大豆油 主连  
CBOT_ZMmain | 豆粕 主连  
CBOT_ZNmain | 十年国债 主连  
CBOT_ZRmain | RICE  
CBOT_ZTmain | 两年国债 主连  
CBOT_MYMmain | 微型E-迷你道指 主连  
CME_ADmain | 澳元 主连  
CME_BPmain | 英镑 主连  
CME_CDmain | 加元 主连  
CME_ECmain | 欧元 主连  
CME_ESmain | 迷你标普 主连  
CME_JYmain | 日元 主连  
CME_NQmain | 迷你纳斯达克100指数 主连  
CME_SFmain | 瑞郎 主连  
CME_M2Kmain | 微型E-迷你罗素2000指数 主连  
CME_MESmain | 微型E-迷你标普500 主连  
CME_MNQmain | 微型E-纳斯达克100 主连  
CME_RTYmain | E-迷你罗素2000指数 主连  
COMEX_GCmain | 黄金 主连  
COMEX_HGmain | 铜 主连  
COMEX_QImain | 迷你白银 主连  
COMEX_QOmain | 迷你黄金 主连  
COMEX_SImain | 白银 主连  
COMEX_MGCmain | 微黄金  
HKEX_HHImain | 国企指数 主连  
HKEX_HSImain | 恒生指数 主连  
HKEX_HTImain | 恒生科技指数 主连  
HKEX_MCHmain | 小型国企 主连  
HKEX_MHImain | 小型恒指 主连  
NYMEX_BZmain | 布伦原油(现金) 主连  
NYMEX_CLmain | WTI原油 主连  
NYMEX_HOmain | HEAT OIL  
NYMEX_NGmain | 天然气 主连  
NYMEX_PAmain | 钯金 主连  
NYMEX_PLmain | 铂金 主连  
NYMEX_QGmain | MININATGS  
NYMEX_QMmain | 迷你原油 主连  
SGX_CNmain | A50指数 主连
