---
# Converted from: strategy_enums_consts\index.html
---

# 枚举常量¶

## OrderType - 委托类型¶
    
    
    OrderType_Market = 49  # 市价单.
    OrderType_Limit = 50  # 限价单.
    

## OrderSide - 买卖方向¶
    
    
    Buy = 66  # 买入.
    Sell = 83  # 卖出.
    

## OpenCloseMode - 开平标志¶
    
    
    OpenCloseMode_Open = 1  # 开仓.
    OpenCloseMode_Close = 2  # 平仓.
    OpenCloseMode_CloseTd = 3  # 平今.
    OpenCloseMode_CloseYd = 4  # 平昨.
    

## PositionType - 持仓方向¶
    
    
    PositionType_Long = 'Long'  # 多头头寸(str)
    PositionType_Short = 'Short'  # 空头头寸(str)
    
    LongPosition = 66  # 多头头寸(int).
    ShortPosition = 83  # 空头头寸(int).
    

## OrderType - 委托类型¶
    
    
    OrderType_Market = 49  # 市价单.
    OrderType_Limit = 50  # 限价单.
    

## PriceType - 价格类型¶
    
    
    PriceType_Opposite = 1  # 对手价.
    PriceType_Bid = 2  # 买一价.
    PriceType_Market = 3  # 市价单.
    PriceType_Last = 4  # 最新价*ratio.
    

## OrderStatus - 委托状态¶
    
    
    OrderStatusSubmit = 48  # 终端提交.
    OrderStatusAccept = 49  # 已受理.
    OrderStatusTrigger = 50  # 策略待触发.
    OrderStatusPending = 52  # 已排队.
    OrderStatusPartFill = 53  # 部分成交.
    OrderStatusFilled = 54  # 完全成交.
    OrderStatusCancel = 57  # 完全撤单.
    OrderStatusCancelSurplus = 65  # 已撤余单.
    OrderStatusCommandFailed = 66  # 指令失败.
    OrderStatusExpireDel = 69  # 到期删除.
    
