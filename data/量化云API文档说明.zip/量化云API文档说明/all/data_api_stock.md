---
# Converted from: data_api_stock\index.html
---

# 股票数据函数¶

## 基本信息¶

###  stk_get_index_constituents \- 查询指数成分股 ¶
    
    
    stk_get_index_constituents(index, *, trade_date=None, start_date=None, end_date=None, df=True, fields=gdf.stk_get_index_constituents)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 10:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`index` |  `str` |  指数代码 |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前日期 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前日期 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_get_index_constituents`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`index` |  `str` |  指数代码  
`symbol` |  `str` |  成分股代码  
`weight` |  `int` |  成分股权重  
成分股 symbol 对应的指数权重  
`trade_date` |  `str` |  交易日期  
`market_value_total` |  `float` |  总市值（亿元）  
`market_value_circ` |  `float` |  流通市值（亿元）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_index_constituents(index='SHSE.000300')
        print(df)
        

  * Output: 
        
        index       symbol  weight  trade_date  market_value_total  market_value_circ
        0    SHSE.000300  SHSE.600000  0.0047  2023-12-25           1931.3732          1931.3732
        1    SHSE.000300  SHSE.600009  0.0026  2023-12-25            808.5076           626.0688
        2    SHSE.000300  SHSE.600010  0.0020  2023-12-25            649.2907           450.4088
        3    SHSE.000300  SHSE.600011  0.0020  2023-12-25           1230.7305           862.2205
        4    SHSE.000300  SHSE.600015  0.0021  2023-12-25            915.1084           737.3045
        ..           ...          ...     ...         ...                 ...                ...
        295  SHSE.000300  SZSE.300919  0.0008  2023-12-25            305.7077           303.5470
        296  SHSE.000300  SZSE.300957  0.0005  2023-12-25            278.7288           143.0451
        297  SHSE.000300  SZSE.300979  0.0004  2023-12-25            603.6891            75.5658
        298  SHSE.000300  SZSE.300999  0.0012  2023-12-25           1761.4751           176.3060
        299  SHSE.000300  SZSE.301269  0.0000  2023-12-25            557.5469           274.6418
        
        [300 rows x 6 columns]
        

* * *

###  stk_get_industry_constituents \- 查询行业成分股 ¶
    
    
    stk_get_industry_constituents(industry_code, *, date=None, fields=gdf.stk_get_industry_constituents, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
证监会行业分类2012 / 申万行业分类2021 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`industry_code` |  `str` |  行业代码  
需要查询成分股的行业代码，可通过stk_get_industry_category获取 |  _必需_  
`date` |  `str | datetime | timestamp` |  查询日期  
查询行业成分股的指定日期，%Y-%m-%d 格式，默认最新时间 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_industry_constituents`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`industry_code` |  `str` |  行业代码  
成分股的行业代码  
`industry_name` |  `str` |  行业名称  
成分股的行业名称  
`symbol` |  `str` |  成分股票代码  
`sec_name` |  `str` |  成分股名称  
`date_in` |  `str` |  纳入日期  
成分股被纳入指定行业的日期，%Y-%m-%d 格式  
`date_out` |  `str` |  剔除日期  
成分股被剔除指定行业的日期，%Y-%m-%d 格式  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_industry_constituents(industry_code='01', date='2023-12-05')
        print(df)
        

  * Output: 
        
        industry_code industry_name       symbol sec_name     date_in date_out
        0             01            农业  BJSE.831087     秋乐种业  2014-08-18     None
        1             01            农业  BJSE.870866     绿亨科技  2017-02-16     None
        2             01            农业  SHSE.600108     亚盛集团  2012-12-31     None
        3             01            农业  SHSE.600313     农发种业  2015-07-20     None
        4             01            农业  SHSE.600354     敦煌种业  2012-12-31     None
        5             01            农业  SHSE.600359     新农开发  2012-12-31     None
        6             01            农业  SHSE.600371     万向德农  2012-12-31     None
        7             01            农业  SHSE.600506     统一股份  2012-12-31     None
        8             01            农业  SHSE.600540     新赛股份  2012-12-31     None
        9             01            农业  SHSE.600598      北大荒  2012-12-31     None
        10            01            农业  SHSE.601118     海南橡胶  2012-12-31     None
        11            01            农业  SZSE.000998     隆平高科  2012-12-31     None
        12            01            农业  SZSE.002041     登海种业  2012-12-31     None
        13            01            农业  SZSE.002772     众兴菌业  2015-06-10     None
        14            01            农业  SZSE.300087     荃银高科  2012-12-31     None
        15            01            农业  SZSE.300143     盈康生命  2012-12-31     None
        16            01            农业  SZSE.300189     神农科技  2012-12-31     None
        17            01            农业  SZSE.300511     雪榕生物  2016-04-14     None
        18            01            农业  SZSE.300970     华绿生物  2015-07-21     None
        19            01            农业  SZSE.300972     万辰集团  2015-08-18     None
        

* * *

###  stk_get_symbol_industry \- 查询股票的所属行业 ¶
    
    
    stk_get_symbol_industry(symbols, *, source='zjh2012', level=1, date=None, fields=gdf.stk_get_symbol_industry, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
证监会行业分类2012 / 申万行业分类2021 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`source` |  `str` |  行业来源  
'zjh2012'- 证监会行业分类 2012（默认）  
'sw2021'- 申万行业分类 2021 |  `'zjh2012'`  
`level` |  `int` |  行业分级   
1 - 一级行业（默认）   
2 - 二级行业   
3 - 三级行业 |  `1`  
`date` |  `str | datetime | timestamp` |  查询日期  
查询行业成分股的指定日期，%Y-%m-%d 格式，默认最新时间 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_symbol_industry`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`sec_name` |  `str` |  股票名称  
`industry_code` |  `str` |  行业代码  
指定行业来源下，symbol 所属的行业代码  
`industry_name` |  `str` |  行业名称  
指定行业来源下，symbol 所属的行业名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_symbol_industry(symbols='SHSE.600000, SZSE.000002', source="zjh2012", level=1)
        print(df)
        

  * Output: 
        
        symbol sec_name industry_code industry_name
        0  SHSE.600000     浦发银行             J           金融业
        1  SZSE.000002      万科A             K          房地产业
        

* * *

###  stk_get_sector_category \- 查询板块分类 ¶
    
    
    stk_get_sector_category(sector_type, *, fields=gdf.stk_get_sector_category, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1001:市场类 1002:地域类 1003:概念类 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`sector_type` |  `str` |  板块类型  
只能选择一种类型，可选择 1001:市场类 1002:地域类 1003:概念类 |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_sector_category`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`sector_code` |  `str` |  板块代码  
所选板块类型的板块代码  
`sector_name` |  `str` |  板块名称  
所选板块类型的板块名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_sector_category(sector_type='1003')
        print(df)
        

  * Output: 
        
        sector_code sector_name
        0        007001          军工
        1        007003         煤化工
        2        007004         新能源
        3        007005        节能环保
        4        007007         AB股
        ..          ...         ...
        435      007514       高带宽内存
        436      007515       多模态AI
        437      007516     东盟自贸区概念
        438      007517        小米汽车
        439      007518    PEEK材料概念
        
        [440 rows x 2 columns]
        

* * *

###  stk_get_sector_constituents \- 查询板块成分股 ¶
    
    
    stk_get_sector_constituents(sector_code, *, fields=gdf.stk_get_sector_constituents, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1001:市场类 1002:地域类 1003:概念类 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`sector_code` |  `str` |  板块代码  
需要查询成分股的板块代码，可通过stk_get_sector_category获取 |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_sector_constituents`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`sec_name` |  `str` |  股票名称  
`sector_code` |  `str` |  板块代码  
查询的板块代码  
`sector_name` |  `str` |  板块名称  
查询的板块代码对应的板块名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_sector_constituents(sector_code='007089')
        print(df)
        

  * Output: 
        
        sector_code sector_name       symbol sec_name
        0       007089        央视50  SHSE.600535      天士力
        1       007089        央视50  SHSE.601398     工商银行
        2       007089        央视50  SHSE.601939     建设银行
        3       007089        央视50  SHSE.601166     兴业银行
        4       007089        央视50  SZSE.000002      万科A
        5       007089        央视50  SHSE.600196     复星医药
        6       007089        央视50  SZSE.000895     双汇发展
        7       007089        央视50  SHSE.600563     法拉电子
        8       007089        央视50  SHSE.600398     海澜之家
        9       007089        央视50  SZSE.000848     承德露露
        10      007089        央视50  SHSE.600585     海螺水泥
        11      007089        央视50  SHSE.600600     青岛啤酒
        12      007089        央视50  SHSE.601988     中国银行
        13      007089        央视50  SZSE.002038     双鹭药业
        14      007089        央视50  SZSE.000049     德赛电池
        15      007089        央视50  SHSE.600519     贵州茅台
        16      007089        央视50  SHSE.600522     中天科技
        17      007089        央视50  SHSE.600016     民生银行
        18      007089        央视50  SHSE.600036     招商银行
        19      007089        央视50  SHSE.600276     恒瑞医药
        20      007089        央视50  SHSE.600660     福耀玻璃
        21      007089        央视50  SZSE.000423     东阿阿胶
        22      007089        央视50  SHSE.600085      同仁堂
        23      007089        央视50  SHSE.600104     上汽集团
        24      007089        央视50  SHSE.600690     海尔智家
        25      007089        央视50  SHSE.601318     中国平安
        26      007089        央视50  SHSE.601601     中国太保
        27      007089        央视50  SHSE.601607     上海医药
        28      007089        央视50  SZSE.000596     古井贡酒
        29      007089        央视50  SZSE.000651     格力电器
        30      007089        央视50  SHSE.600887     伊利股份
        31      007089        央视50  SZSE.002230     科大讯飞
        32      007089        央视50  SZSE.002120     韵达股份
        33      007089        央视50  SZSE.300070      碧水源
        34      007089        央视50  SZSE.002294      信立泰
        35      007089        央视50  SZSE.300136     信维通信
        36      007089        央视50  SZSE.002415     海康威视
        37      007089        央视50  SZSE.300003     乐普医疗
        38      007089        央视50  SZSE.300124     汇川技术
        39      007089        央视50  SZSE.002410      广联达
        40      007089        央视50  SZSE.300183     东软载波
        41      007089        央视50  SZSE.300244     迪安诊断
        42      007089        央视50  SZSE.002008     大族激光
        43      007089        央视50  SHSE.601088     中国神华
        44      007089        央视50  SZSE.000538     云南白药
        45      007089        央视50  SZSE.000726      鲁泰A
        46      007089        央视50  SZSE.300024      机器人
        47      007089        央视50  SZSE.000333     美的集团
        48      007089        央视50  SHSE.603986     兆易创新
        49      007089        央视50  SHSE.603160     汇顶科技
        

* * *

###  kpl_get_sector_category \- 查询KPL板块列表 ¶
    
    
    kpl_get_sector_category(fields=gdf.kpl_get_sector_category, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
- | 每个交易日 | 10:00am  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`fields` |  `str | list` |  指定需要返回的字段 |  `kpl_get_sector_category`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`sector_code` |  `str` |  板块代码  
`sector_name` |  `str` |  板块名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.kpl_get_sector_category()
        print(df)
        

  * Output: 
        
        sector_code sector_name
            0        801027          银行
            1        801571       一季报增长
            2        801366        业绩增长
            3        801646        信托概念
            4        801039        机场航空
            ..          ...         ...
            626      801690         血氧仪
            627      801570        氯化亚砜
            628      801697       LiFSI
            629      801572        中报增长
            630      801078          快充
        

* * *

###  kpl_get_sector_constituents \- 查询KPL板块成分股 ¶
    
    
    kpl_get_sector_constituents(*, symbol=None, sector_code=None, start_date=None, end_date=None, fields=gdf.kpl_get_sector_constituents, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
- | 每个交易日 | 10:00am  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`sector_code` |  `str | list` |  板块代码  
需要查询成分股的板块代码，可通过kpl_get_sector_category获取，可输入多个 |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `kpl_get_sector_constituents`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期   
指定时间段内的交易日期，%Y-%m-%d 格式  
`symbol` |  `str` |  股票代码  
`sec_name` |  `str` |  股票名称  
`sector_code` |  `str` |  板块代码  
查询的板块代码  
`sector_name` |  `str` |  板块名称  
查询的板块代码对应的板块名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.kpl_get_sector_constituents(sector_code='801027')
        print(df)
        

  * Output: 
        
        trade_date sector_code sector_name       symbol sec_name
            0   2024-05-16      801027          银行  SHSE.601398     工商银行
            1   2024-05-16      801027          银行  SHSE.601838     成都银行
            2   2024-05-16      801027          银行  SZSE.002936     郑州银行
            3   2024-05-16      801027          银行  SHSE.601818     光大银行
            4   2024-05-16      801027          银行  SHSE.601288     农业银行
            5   2024-05-16      801027          银行  SHSE.601128     常熟银行
            6   2024-05-16      801027          银行  SHSE.601328     交通银行
            7   2024-05-16      801027          银行  SHSE.601988     中国银行
            8   2024-05-16      801027          银行  SHSE.600016     民生银行
            9   2024-05-16      801027          银行  SHSE.601939     建设银行
            10  2024-05-16      801027          银行  SHSE.601916     浙商银行
            11  2024-05-16      801027          银行  SZSE.002958     青农商行
            12  2024-05-16      801027          银行  SHSE.601169     北京银行
            13  2024-05-16      801027          银行  SHSE.601860     紫金银行
            14  2024-05-16      801027          银行  SHSE.600000     浦发银行
            15  2024-05-16      801027          银行  SHSE.601825     沪农商行
            16  2024-05-16      801027          银行  SZSE.000001     平安银行
            17  2024-05-16      801027          银行  SHSE.600015     华夏银行
            18  2024-05-16      801027          银行  SHSE.601658     邮储银行
            19  2024-05-16      801027          银行  SHSE.601166     兴业银行
            20  2024-05-16      801027          银行  SHSE.601963     重庆银行
            21  2024-05-16      801027          银行  SZSE.002839     张家港行
            22  2024-05-16      801027          银行  SHSE.601997     贵阳银行
            23  2024-05-16      801027          银行  SHSE.601187     厦门银行
            24  2024-05-16      801027          银行  SZSE.002807     江阴银行
            25  2024-05-16      801027          银行  SHSE.601229     上海银行
            26  2024-05-16      801027          银行  SZSE.001227     兰州银行
            27  2024-05-16      801027          银行  SHSE.601665     齐鲁银行
            28  2024-05-16      801027          银行  SHSE.601077     渝农商行
            29  2024-05-16      801027          银行  SZSE.002142     宁波银行
            30  2024-05-16      801027          银行  SHSE.600919     江苏银行
            31  2024-05-16      801027          银行  SHSE.601998     中信银行
            32  2024-05-16      801027          银行  SHSE.600908     无锡银行
            33  2024-05-16      801027          银行  SHSE.601577     长沙银行
            34  2024-05-16      801027          银行  SHSE.600036     招商银行
            35  2024-05-16      801027          银行  SZSE.002948     青岛银行
            36  2024-05-16      801027          银行  SHSE.601009     南京银行
            37  2024-05-16      801027          银行  SHSE.603323     苏农银行
            38  2024-05-16      801027          银行  SHSE.600926     杭州银行
            39  2024-05-16      801027          银行  SZSE.002966     苏州银行
            40  2024-05-16      801027          银行  SHSE.600928     西安银行
            41  2024-05-16      801027          银行  SHSE.601528     瑞丰银行
        

* * *

###  stk_get_symbol_sector \- 查询股票的所属板块 ¶
    
    
    stk_get_symbol_sector(symbols, sector_type, *, fields=gdf.stk_get_symbol_sector, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1001:市场类 1002:地域类 1003:概念类 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`sector_type` |  `str` |  板块类型  
只能选择一种类型，可选择 1001:市场类 1002:地域类 1003:概念类 |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_symbol_sector`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`sec_name` |  `str` |  股票名称  
`sector_code` |  `str` |  板块代码  
指定板块类型下，symbol 所属的板块代码  
`sector_name` |  `str` |  板块名称  
指定板块类型下，symbol 所属的板块名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_symbol_sector(symbols='SHSE.600008,SZSE.000002', sector_type='1002')
        print(df)
        

  * Output: 
        
        sector_code sector_name       symbol sec_name
        0  006002001001         北京市  SHSE.600008     首创环保
        1  006006001015         深圳市  SZSE.000002      万科A
        

* * *

###  stk_get_dividend \- 查询股票分红送股信息 ¶
    
    
    stk_get_dividend(symbol, start_date, end_date, *, fields=gdf.stk_get_dividend, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_dividend`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`scheme_type` |  `str` |  分配方案  
现金分红，送股，转增  
`pub_date` |  `str` |  公告日  
%Y-%m-%d 格式  
`equity_reg_date` |  `str` |  股权登记日  
%Y-%m-%d 格式  
`ex_date` |  `str` |  除权除息日  
%Y-%m-%d 格式  
`cash_pay_date` |  `str` |  现金红利发放日  
%Y-%m-%d 格式  
`share_acct_date` |  `str` |  送转股到账日  
%Y-%m-%d 格式  
`share_lst_date` |  `str` |  新增股份上市流通日  
红股上市日或送（转增）股份上市交易日, %Y-%m-%d 格式  
`cash_af_tax` |  `float` |  税后红利  
单位：元/10 股  
`cash_bf_tax` |  `float` |  税前红利  
单位：元/10 股  
`bonus_ratio` |  `float` |  送股比例  
10:X  
`convert_ratio` |  `float` |  转增比例  
10:X  
`base_date` |  `str` |  股本基准日  
%Y-%m-%d 格式  
`base_share` |  `float` |  股本基数  
基准股本  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_dividend(symbol='SHSE.600000', start_date='2022-07-01', end_date='2022-07-31')
        print(df)
        

  * Output: 
        
        symbol scheme_type    pub_date equity_reg_date     ex_date cash_pay_date share_acct_date share_lst_date  cash_af_tax  cash_bf_tax  bonus_ratio  convert_ratio   base_date   base_share
        0  SHSE.600000        现金分红  2022-07-13      2022-07-20  2022-07-21    2022-07-21            None           None         3.69          4.1            0              0  2022-07-20  29352173289
        

* * *

###  stk_get_ration \- 查询股票配股信息 ¶
    
    
    stk_get_ration(symbol, start_date, end_date, *, fields=gdf.stk_get_ration, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_ration`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`pub_date` |  `str` |  公告日  
%Y-%m-%d 格式  
`equity_reg_date` |  `str` |  股权登记日  
%Y-%m-%d 格式  
`ex_date` |  `str` |  除权除息日  
%Y-%m-%d 格式  
`ration_ratio` |  `float` |  配股比例  
10:X  
`ration_price` |  `float` |  配股价格  
单位：元  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_ration(symbol='SZSE.000728', start_date="2005-01-01", end_date="2022-09-30")
        print(df)
        

  * Output: 
        
        symbol    pub_date equity_reg_date     ex_date  ration_ratio  ration_price
        0  SZSE.000728  2020-10-09      2020-10-13  2020-10-22             3          5.44
        

* * *

###  stk_get_adj_factor \- 查询股票的复权因子 ¶
    
    
    stk_get_adj_factor(symbol, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.stk_get_adj_factor, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_adj_factor`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`trade_date` |  `str` |  交易日期  
开始时间至结束时间的交易日期  
`adj_factor_bwd` |  `float` |  当日后复权因子  
T日后复权因子 = T-1日的收盘价 / T日昨收价  
`adj_factor_bwd_acc` |  `float` |  当日累计后复权因子  
T日累计后复权因子=T日后复权因子 × T-1日累计后复权因子, ... 第一个累计后复权因子=第一个后复权因子  
`adj_factor_fwd` |  `float` |  当日前复权因子  
T日前复权因子=T日累计后复权因子/复权基准日累计后复权因子  
`adj_factor_fwd_acc` |  `float` |  当日累计前复权因子  
T 日累计前复权因子=1/T日后复权因子, T-1日累计前复权因子=1/(T 日后复权因子 ×T-1 日后复权因子), ... 第一个累计前复权因子=1/最新累计后复权因子  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_adj_factor(symbol='SZSE.000651', start_date="2015-01-01", end_date="2022-09-01")
        print(df)
        

  * Output: 
        
        symbol  trade_date  adj_factor_bwd  adj_factor_bwd_acc  adj_factor_fwd  adj_factor_fwd_acc
        0     SZSE.000651  2015-01-05             1.0           49.169743        0.313892            3.185809
        1     SZSE.000651  2015-01-06             1.0           49.169743        0.313892            3.185809
        2     SZSE.000651  2015-01-07             1.0           49.169743        0.313892            3.185809
        3     SZSE.000651  2015-01-08             1.0           49.169743        0.313892            3.185809
        4     SZSE.000651  2015-01-09             1.0           49.169743        0.313892            3.185809
        ...           ...         ...             ...                 ...             ...                 ...
        1862  SZSE.000651  2022-08-26             1.0          148.340670        0.946983            1.055984
        1863  SZSE.000651  2022-08-29             1.0          148.340670        0.946983            1.055984
        1864  SZSE.000651  2022-08-30             1.0          148.340670        0.946983            1.055984
        1865  SZSE.000651  2022-08-31             1.0          148.340670        0.946983            1.055984
        1866  SZSE.000651  2022-09-01             1.0          148.340670        0.946983            1.055984
        
        [1867 rows x 6 columns]
        

* * *

###  stock_basic \- 股票基础信息 ¶
    
    
    stock_basic(symbol=None, name=None, market=None, list_status='L', exchange=None, is_hs=None, fields='symbol,name,area,industry,market,list_date', df=True)
    

获取基础信息数据，包括股票代码、名称、上市日期、退市日期等

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  股票代码，例如（SHSE.600000, SZSE.000001） |  `None`  
`name` |  `str` |  名称 |  `None`  
`market` |  `str` |  市场类别 （主板/创业板/科创板/CDR/北交所） |  `None`  
`list_status` |  `str` |  上市状态 L上市 D退市 P暂停上市，默认是L |  `'L'`  
`exchange` |  `str` |  交易所代码 (SHSE上交所 SZSE深交所 BSE北交所) |  `None`  
`is_hs` |  `str` |  是否沪深港通标的，N否 H沪股通 S深股通 |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `'symbol,name,area,industry,market,list_date'`  
`df` |  `bool` |  是否按DataFrame格式返回 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`name` |  `str` |  股票名称  
`area` |  `str` |  地域  
`industry` |  `str` |  所属行业  
`fullname` |  `str` |  股票全称  
`enname` |  `str` |  英文全称  
`cnspell` |  `str` |  拼音缩写  
`market` |  `str` |  市场类型（主板/创业板/科创板/CDR）  
`exchange` |  `str` |  交易所代码  
`curr_type` |  `str` |  交易货币  
`list_status` |  `str` |  上市状态 L上市 D退市 P暂停上市  
`list_date` |  `str` |  上市日期  
`delist_date` |  `str` |  退市日期  
`is_hs` |  `str` |  是否沪深港通标的，N否 H沪股通 S深股通  
`act_name` |  `str` |  实控人名称  
`act_ent_type` |  `str` |  实控人企业性质  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.stock_basic(symbol='SHSE.600000,SZSE.000001')
    print(data)
    

输出: 
    
    
        area industry   list_date market  name       symbol
    0   上海       银行  1999-11-10     主板  浦发银行  SHSE.600000
    1   深圳       银行  1991-04-03     主板  平安银行  SZSE.000001
    

###  eod \- 每日行情数据 ¶
    
    
    eod(symbols=None, trade_date=None, start_date=None, end_date=None, fields=tdf.eod, df=True)
    

获取A股所有股票的日线数据.

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-12-19 ~ Now | 每个交易日 | 6:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`trade_date` |  `str | datetime | timestamp` |  交易日期，%Y-%m-%d 格式，默认None |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始交易日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束交易日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `eod`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`trade_date` |  `str` |  交易日期  
`open` |  `float` |  当日开盘价  
`high` |  `float` |  当日最高价  
`low` |  `float` |  当日最低价  
`close` |  `float` |  当日收盘价  
`pre_close` |  `float` |  昨收价  
`change` |  `float` |  涨跌额  
`pct_chg` |  `float` |  涨跌幅 【基于除权后的昨收计算的涨跌幅：（今收-除权昨收）/除权昨收 】  
`vol` |  `int` |  当日总成交量  
`amount` |  `float` |  当日总成交金额  
`adj_factor` |  `float` |  复权因子  
`trading` |  `str` |  停牌状态, 1-正常交易  
`up_limit` |  `float` |  涨停价  
`down_limit` |  `float` |  跌停价  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.eod(trade_date='2025-01-13')
    print(data)
    

输出: 
    
    
               symbol  trade_date   open   high    low  close  pre_close  change  pct_chg       vol       amount  adj_factor trading  up_limit  down_limit
    0     SZSE.000001  2025-01-13  11.25  11.26  11.08  11.20      11.30   -0.10  -0.8850  93496618  1044904.416    127.7841     1.0     12.43       10.17
    1     SZSE.000002  2025-01-13   6.60   6.77   6.55   6.76       6.69    0.07   1.0463  91114692   611005.036    181.7040     1.0      7.36        6.02
    2     SZSE.000004  2025-01-13  12.39  12.51  11.87  12.47      12.51   -0.04  -0.3197   6998700    86099.245      4.0640     1.0     13.76       11.26
    3     SZSE.000006  2025-01-13   6.55   6.68   6.31   6.63       6.72   -0.09  -1.3393  23184873   151139.935     39.7400     1.0      7.39        6.05
    4     SZSE.000007  2025-01-13   6.69   6.83   6.58   6.82       6.77    0.05   0.7386   3044967    20435.487      8.2840     1.0      7.45        6.09
    ...           ...         ...    ...    ...    ...    ...        ...     ...      ...       ...          ...         ...     ...       ...         ...
    5368  BJSE.920106  2025-01-13  54.30  55.39  53.30  55.20      55.02    0.18   0.3272    635777    34499.800      1.0000     1.0     71.52       38.52
    5369  BJSE.920111  2025-01-13  23.48  24.82  23.48  24.00      24.53   -0.53  -2.1606   2586509    62280.117      1.0000     1.0     31.88       17.18
    5370  BJSE.920116  2025-01-13  50.33  56.80  49.50  52.48      48.96    3.52   7.1895   9433427   497026.547      1.0000     1.0     63.64       34.28
    5371  BJSE.920118  2025-01-13  23.78  24.35  23.45  23.55      24.36   -0.81  -3.3251    265980     6325.260      1.0000     1.0     31.66       17.06
    5372  BJSE.920128  2025-01-13  28.90  28.90  27.70  27.76      28.95   -1.19  -4.1105   1184158    33306.575      1.0000     1.0     37.63       20.27
    
    [5373 rows x 15 columns]
    

###  block_trade \- 大宗交易 ¶
    
    
    block_trade(symbol=None, trade_date=None, start_date=None, end_date=None, fields='symbol,trade_date,price,vol,amount,buyer,seller', df=True)
    

查询大宗交易

数据范围 | 更新频率 | 更新时间  
---|---|---  
2002-03-19 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  股票代码(股票代码和日期至少输入一个参数)，例如（SHSE.600000, SZSE.000001） |  `None`  
`trade_date` |  `str` |  交易日期（格式：YYYYMMDD，下同） |  `None`  
`start_date` |  `str` |  开始日期 |  `None`  
`end_date` |  `str` |  结束日期 |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `'symbol,trade_date,price,vol,amount,buyer,seller'`  
`df` |  `bool` |  是否按DataFrame格式返回 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码,例如（SHSE.600000, SZSE.000001）  
`trade_date` |  `str` |  交易日历  
`price` |  `float` |  成交价  
`vol` |  `float` |  成交量（万股）  
`amount` |  `float` |  成交金额  
`buyer` |  `str` |  买方营业部  
`seller` |  `str` |  卖方营业部  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.block_trade(trade_date='2023-12-18')
    print(data)
    

输出: 
    
    
        amount                 buyer   price                    seller  trade_date       symbol    vol
    0  7360.00  红塔证券股份有限公司北京丰科路证券营业部   20.00    国泰君安证券股份有限公司杭州延安路证券营业部  2023-12-18  SHSE.605319  368.0
    1   208.70  中泰证券股份有限公司栖霞霞光路证券营业部   20.87      中泰证券股份有限公司栖霞霞光路证券营业部  2023-12-18  SHSE.605589   10.0
    2  1629.50      申万宏源证券有限公司证券投资总部  325.90  中信建投证券股份有限公司上海市徐家汇路证券营业部  2023-12-18  SHSE.688111    5.0
    3   202.54          华泰证券股份有限公司总部    8.51           中信证券股份有限公司上海分公司  2023-12-18  SHSE.600021   23.8
    

###  forecast \- 获取业绩预告数据 ¶
    
    
    forecast(*, symbol=None, ann_date=None, start_date=None, end_date=None, period=None, type=None, fields=tdf.forecast, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 7:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`ann_date` |  `str | datetime | timestamp` |  公告日期，%Y-%m-%d 格式，默认None |  `None`  
`start_date` |  `str | datetime | timestamp` |  公告开始日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  公告结束日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`period` |  `str | datetime | timestamp` |  报告期，%Y-%m-%d 格式，默认None，取季度最后一天的日期，如：   
第一季度 - 2023-03-31   
第二季度 - 2023-06-30   
第三季度 - 2023-09-30   
年报 - 2023-12-31 |  `None`  
`type` |  `str` |  业绩预告类型，如：   
预增 / 预减 / 扭亏 / 首亏 / 续亏 / 续盈 / 略增 / 略减 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `forecast`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`ann_date` |  `str` |  公告日期  
`end_date` |  `str` |  报告期  
`type` |  `str` |  业绩预告类型，如：   
预增 / 预减 / 扭亏 / 首亏 / 续亏 / 续盈 / 略增 / 略减  
`p_change_min` |  `float` |  预告净利润变动幅度下限（%）  
`p_change_max` |  `float` |  预告净利润变动幅度上限（%）  
`net_profit_min` |  `float` |  预告净利润下限（万元）  
`net_profit_max` |  `float` |  预告净利润上限（万元）  
`last_parent_net` |  `float` |  上年同期归属母公司净利润  
`first_ann_date` |  `str` |  首次公告日  
`summary` |  `str` |  业绩预告摘要  
`change_reason` |  `str` |  业绩变动原因  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        df = ait0.ts.forecast(symbol="SHSE.600318", start_date="2024-01-30", end_date="2024-01-30")
        print(df)
        

  * Output: 
        
        symbol    ann_date    end_date type  p_change_min  p_change_max  net_profit_min  net_profit_max  last_parent_net first_ann_date          summary                                      change_reason  update_flag
        0  SHSE.600318  2024-01-30  2023-12-31   扭亏      118.7701      123.1017            2600            3200        -13851.82     2024-01-30  预计:净利润2600-3200  1、公司加大业务开拓力度，公司整体收入同比增长约8%。2、公司加大
        清收清欠力度，子公司清收效...            0
        

* * *

###  daily_basic \- 获取每日指标 ¶
    
    
    daily_basic(symbols=None, trade_date=None, start_date=None, end_date=None, fields=tdf.daily_basic, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
2000-01-04 ~ Now | 每个交易日 | 5:30pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`trade_date` |  `str | datetime | timestamp` |  交易日期，%Y-%m-%d 格式，默认None |  `None`  
`start_date` |  `str | datetime | timestamp` |  公告开始日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  公告结束日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `daily_basic`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`trade_date` |  `str` |  交易日期  
`close` |  `float` |  当日收盘价  
`turnover_rate` |  `float` |  换手率（%）  
`turnover_rate_f` |  `float` |  换手率（自由流通股）  
`volume_ratio` |  `float` |  量比  
`pe` |  `float` |  市盈率（总市值/净利润， 亏损的PE为空）  
`pe_ttm` |  `float` |  市盈率（TTM，亏损的PE为空）  
`pb` |  `float` |  市净率（总市值/净资产）  
`ps` |  `float` |  市销率  
`ps_ttm` |  `float` |  市销率（TTM）  
`dv_ratio` |  `float` |  股息率 （%）  
`dv_ttm` |  `float` |  股息率（TTM）（%）  
`total_share` |  `float` |  总股本 （万股）  
`float_share` |  `float` |  流通股本 （万股）  
`free_share` |  `float` |  自由流通股本 （万）  
`total_mv` |  `float` |  总市值（万元）  
`circ_mv` |  `float` |  流通市值（万元）  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.ts.daily_basic(symbols='SHSE_600000', start_date="2024-02-28", end_date="2024-02-28")
        print(df)
        

  * Output: 
        
        symbol  trade_date  close  turnover_rate  turnover_rate_f  volume_ratio      pe  pe_ttm      pb      ps  ps_ttm  dv_ratio  dv_ttm   total_share   float_share   free_share      total_mv       circ_mv
        0  SHSE.600000  2024-02-28    7.1         0.1221           0.3759          0.91  4.0726  5.3857  0.3456  1.1049  1.1724     4.507   4.507  2.935218e+06  2.935218e+06  953172.3091  2.084005e+07  2.084005e+07
        

* * *

###  stk_surv \- 机构调研表 ¶
    
    
    stk_surv(symbols, surv_date=None, start_date=None, end_date=None, fields=tdf.stk_surv, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
- | 每个交易日 | 5:10pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  可转债代码，可输入多个2021-08-05 ~ Now   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SHSE.110060,SZSE.123129'   
采用 list 格式时，多个ETF代码示例：['SHSE.110060', 'SZSE.123129'] |  _必需_  
`surv_date` |  `str | datetime | timestamp` |  调研日期，%Y-%m-%d 格式，默认None |  `None`  
`start_date` |  `str | datetime | timestamp` |  调研开始日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  调研结束日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_surv`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`name` |  `str` |  标的名称  
`surv_date` |  `str` |  调研日期  
`fund_visitors` |  `str` |  机构参与人员  
`rece_place` |  `str` |  接待地点  
`rece_mode` |  `str` |  接待方式  
`rece_org` |  `str` |  接待的公司  
`org_type` |  `str` |  接待公司类型  
`comp_rece` |  `str` |  上市公司接待人员  
`content` |  `str` |  调研内容  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        df = ait0.ts.stk_surv(symbols="SHSE.600010,SZSE.300168", start_date="2020-01-01", fields="symbol,surv_date")
        print(df)
        

  * Output: 
        
        symbol   surv_date
        0    SHSE.600010  2023-03-15
        1    SHSE.600010  2023-03-15
        2    SHSE.600010  2023-03-15
        3    SHSE.600010  2023-03-15
        4    SHSE.600010  2023-03-15
        ..           ...         ...
        295  SZSE.300168  2024-05-10
        296  SZSE.300168  2024-05-10
        297  SZSE.300168  2024-05-10
        298  SZSE.300168  2024-05-10
        299  SZSE.300168  2024-05-10
        

* * *

###  broker_recommend \- 券商每月荐股 ¶
    
    
    broker_recommend(start_date=None, end_date=None, fields=tdf.broker_recommend, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
- | 每月3日 | 6:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`start_date` |  `str | datetime | timestamp` |  调研开始日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  调研结束日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `broker_recommend`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`month` |  `str` |  所属月份，%Y-%m  
`broker` |  `str` |  推荐券商  
`symbol` |  `str` |  标的代码  
`name` |  `str` |  标的名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        df = ait0.ts.broker_recommend(start_date="2024-01-01")
        print(df)
        

  * Output: 
        
        month broker  name       symbol
        0    2024-01   东兴证券  贵州茅台  SHSE.600519
        1    2024-01   东兴证券  江苏银行  SHSE.600919
        2    2024-01   东兴证券   喜临门  SHSE.603008
        3    2024-01   东兴证券   新坐标  SHSE.603040
        4    2024-01   东兴证券  清越科技  SHSE.688496
        ..       ...    ...   ...          ...
        914  2024-05   财通证券  沪电股份  SZSE.002463
        915  2024-05   财通证券  福瑞股份  SZSE.300049
        916  2024-05   财通证券  华图山鼎  SZSE.300492
        917  2024-05   财通证券  宁德时代  SZSE.300750
        918  2024-05   财通证券  协创数据  SZSE.300857
        

* * *

## 股东股本信息¶

###  stk_get_shareholder_num \- 查询股东户数 ¶
    
    
    stk_get_shareholder_num(symbol, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.stk_get_shareholder_num, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_shareholder_num`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`trade_date` |  `str` |  交易日期  
开始时间至结束时间的交易日期  
`adj_factor_bwd` |  `float` |  当日后复权因子  
T日后复权因子 = T-1日的收盘价 / T日昨收价  
`adj_factor_bwd_acc` |  `float` |  当日累计后复权因子  
T日累计后复权因子=T日后复权因子 × T-1日累计后复权因子, ... 第一个累计后复权因子=第一个后复权因子  
`adj_factor_fwd` |  `float` |  当日前复权因子  
T日前复权因子=T日累计后复权因子/复权基准日累计后复权因子  
`adj_factor_fwd_acc` |  `float` |  当日累计前复权因子  
T 日累计前复权因子=1/T日后复权因子, T-1日累计前复权因子=1/(T 日后复权因子 ×T-1 日后复权因子), ... 第一个累计前复权因子=1/最新累计后复权因子  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_adj_factor(symbol='SZSE.000651', start_date="2015-01-01", end_date="2022-09-01")
        print(df)
        

  * Output: 
        
        symbol  trade_date  adj_factor_bwd  adj_factor_bwd_acc  adj_factor_fwd  adj_factor_fwd_acc
        0     SZSE.000651  2015-01-05             1.0           49.169743        0.313892            3.185809
        1     SZSE.000651  2015-01-06             1.0           49.169743        0.313892            3.185809
        2     SZSE.000651  2015-01-07             1.0           49.169743        0.313892            3.185809
        3     SZSE.000651  2015-01-08             1.0           49.169743        0.313892            3.185809
        4     SZSE.000651  2015-01-09             1.0           49.169743        0.313892            3.185809
        ...           ...         ...             ...                 ...             ...                 ...
        1862  SZSE.000651  2022-08-26             1.0          148.340670        0.946983            1.055984
        1863  SZSE.000651  2022-08-29             1.0          148.340670        0.946983            1.055984
        1864  SZSE.000651  2022-08-30             1.0          148.340670        0.946983            1.055984
        1865  SZSE.000651  2022-08-31             1.0          148.340670        0.946983            1.055984
        1866  SZSE.000651  2022-09-01             1.0          148.340670        0.946983            1.055984
        
        [1867 rows x 6 columns]
        

* * *

###  stk_get_top_shareholder \- 查询十大股东 ¶
    
    
    stk_get_top_shareholder(symbol, *, start_date=None, end_date=None, pivot_date=None, tradable_holder=False, fields=gdf.stk_get_top_shareholder, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`tradable_holder` |  `bool` |  是否流通股东  
False-十大股东（默认）  
True-十大流通股东 默认False表示十大股东 |  `False`  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_top_shareholder`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`sec_name` |  `str` |  股票名称  
symbol对应的股票名称  
`pub_date` |  `str` |  公告日期  
`expiry_date` |  `str` |  截止日期  
`holder_name` |  `str` |  股东名称  
`holder_rank` |  `int` |  股东序号 - 名次  
`holder_type` |  `str` |  股东类型  
`holder_attr` |  `str` |  股东性质  
十大流通股东不返回  
`share_type` |  `str` |  股份类型  
股份性质  
`share_num` |  `float` |  持股数量  
持有数量（股）  
`share_ratio1` |  `float` |  持股比例 1  
持股占总股本比例（%）  
`share_ratio2` |  `float` |  持股比例 2  
持股占已上市流通股比例（%），仅十大流通股东才返回  
`share_pledge` |  `float` |  质押股份数量  
股权质押涉及股数（股）  
`share_freeze` |  `float` |  冻结股份数量  
股权冻结涉及股数（股）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_top_shareholder(symbol='SHSE.600000', start_date="2023-04-01", end_date="2023-04-20", tradable_holder=False)
        print(df)
        

  * Output: 
        
        symbol sec_name    pub_date expiry_date         holder_name  holder_rank holder_type holder_attr share_type   share_num  share_ratio1  share_ratio2  share_pledge  share_freeze
        0  SHSE.600000     浦发银行  2023-04-19  2022-12-31       上海上国投资产管理有限公司            5          其它         国有股       流通A股  1395571025          4.75             0             0             0
        1  SHSE.600000     浦发银行  2023-04-19  2022-12-31        上海国鑫投资发展有限公司            8        投资公司         国有股       流通A股   945568990          3.22             0             0             0
        2  SHSE.600000     浦发银行  2023-04-19  2022-12-31          上海国际集团有限公司            1          其它         国有股       流通A股  6331322671         21.57             0             0             0
        3  SHSE.600000     浦发银行  2023-04-19  2022-12-31      中国移动通信集团广东有限公司            2          其它         国有股       流通A股  5334892824         18.18             0             0             0
        4  SHSE.600000     浦发银行  2023-04-19  2022-12-31        中国证券金融股份有限公司            7          其它         国有股       流通A股  1179108780          4.02             0             0             0
        5  SHSE.600000     浦发银行  2023-04-19  2022-12-31      中央汇金资产管理有限责任公司           10          其它         国有股       流通A股   387174708          1.32             0             0             0
        6  SHSE.600000     浦发银行  2023-04-19  2022-12-31  富德生命人寿保险股份有限公司-万能H            6        保险产品       境内法人股       流通A股  1270428648          4.33             0             0             0
        7  SHSE.600000     浦发银行  2023-04-19  2022-12-31   富德生命人寿保险股份有限公司-传统            3        保险产品       境内法人股       流通A股  2779437274          9.47             0             0             0
        8  SHSE.600000     浦发银行  2023-04-19  2022-12-31  富德生命人寿保险股份有限公司-资本金            4        保险产品       境内法人股       流通A股  1763232325          6.01             0             0             0
        9  SHSE.600000     浦发银行  2023-04-19  2022-12-31          香港中央结算有限公司            9          其它       境外法人股       流通A股   656749892          2.24             0             0             0
        

* * *

###  stk_get_share_change \- 查询股本变动 ¶
    
    
    stk_get_share_change(symbol, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.stk_get_share_change, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `stk_get_share_change`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`company_name` |  `str` |  公司名称  
symbol对应的公司名称  
`pub_date` |  `str` |  发布日期  
`chg_date` |  `str` |  股本变动日期  
`chg_reason` |  `str` |  股本变动原因  
`chg_event` |  `str` |  股本变动事件  
`share_total` |  `float` |  总股本 未流通股份+已流通股份，单位：股  
`share_total_nlf` |  `float` |  未流通股份，单位：股  
`share_prom` |  `float` |  一、发起人股份  
国有发起人股 + 发起社会法人股 + 其他发起人股份，单位：股  
`share_prom_state` |  `float` |  1.国有发起人股  
国家持股+国有法人股，单位：股  
`share_state` |  `float` |  （1）国家股，单位：股  
`share_state_lp` |  `float` |  （2）国有法人股，单位：股  
`share_prom_soc` |  `float` |  2.发起社会法人股  
境内社会法人股+境外法人股，单位：股  
`share_dc_lp` |  `float` |  （1）境内社会法人股，单位：股  
`share_os_lp` |  `float` |  （2）境外法人股，单位：股  
`share_prom_other` |  `float` |  3.其他发起人股份  
单位：股  
`share_rs` |  `float` |  二、募集人股份  
募集国家股+募集境内法人股+募集境外法人股，单位：股  
`share_rs_state` |  `float` |  1.募集国家股  
单位：股  
`share_rs_dc_lp` |  `float` |  2.募集境内法人股  
募集境内国有法人股+募集境内社会法人股，单位：股  
`share_rs_state_lp` |  `float` |  （1）募集境内国有法人股，单位：股  
`share_rs_soc_lp` |  `float` |  （2）募集境内社会法人股，单位：股  
`share_rs_os_lp` |  `float` |  3.募集境外法人股  
单位：股  
`share_emp_nlf` |  `float` |  三、内部职工股  
单位：股  
`share_pfd_nlf` |  `float` |  四、优先股  
单位：股  
`share_oth_nlf` |  `float` |  五、其他未流通股份  
单位：股  
`share_circ` |  `float` |  流通股份  
单位：股，无限售条件股份+有限售条件股份，实际流通股份可用share_ttl_unl（无限售条件股份）  
`share_ttl_unl` |  `float` |  无限售条件股份  
人民币普通股（A 股）+ 境内上市外资股（B 股）+ 境外上市外资股（H 股）+ 其他已流通股份，单位：股  
`share_a_unl` |  `float` |  1.人民币普通股（A 股）  
单位：股  
`share_b_unl` |  `float` |  2.境内上市外资股（B 股）  
单位：股  
`share_h_unl` |  `float` |  3.境外上市外资股（H 股）  
单位：股  
`share_oth_unl` |  `float` |  4.其他已流通股份  
单位：股  
`share_ttl_ltd` |  `float` |  有限售条件股份，单位：股  
`share_gen_ltd` |  `float` |  一、一般有限售条件股份  
限售国家持股 + 限售国有法人持股 + 限售其他内资持股 + 限售外资持股 + 锁定股份 + 高管持股，单位：股  
`share_state_ltd` |  `float` |  1.限售国家持股  
单位：股  
`share_state_lp_ltd` |  `float` |  2.限售国有法人持股  
单位：股  
`share_oth_dc_ltd` |  `float` |  3.限售其他内资持股  
限售境内非国有法人持股+限售境内自然人持股，单位：股  
`share_nst_dc_lp_ltd` |  `float` |  （1）限售境内非国有法人持股，单位：股  
`share_dc_np_ltd` |  `float` |  （2）限售境内自然人持股，单位：股  
`share_forn_ltd` |  `float` |  4.限售外资持股  
限售境外法人持股+限售境外自然人持股，单位：股  
`share_os_lp_ltd` |  `float` |  （1）限售境外法人持股，单位：股  
`share_os_np_ltd` |  `float` |  （2）限售境外自然人持股，单位：股  
`share_lk_ltd` |  `float` |  5.锁定股份  
单位：股  
`share_gm_ltd` |  `float` |  6.高管持股(原始披露)  
单位：股  
`share_plc_lp_ltd` |  `float` |  二、配售法人持股  
战略投资者配售股份 + 一般法人投资者配售 + 证券投资基金配售股份，单位：股  
`share_plc_si_ltd` |  `float` |  1.战略投资者配售股份  
单位：股  
`share_plc_lp_gen_ltd` |  `float` |  2.一般法人投资者配售股份  
单位：股  
`share_plc_fnd_ltd` |  `float` |  3.证券投资基金配售股份  
单位：股  
`share_a_ltd` |  `float` |  限售流通 A 股  
单位：股  
`share_b_ltd` |  `float` |  限售流通 B 股  
单位：股  
`share_h_ltd` |  `float` |  限售流通 H 股  
单位：股  
`share_oth_ltd` |  `float` |  其他限售股份  
单位：股  
`share_list_date` |  `str` |  变动股份上市日 %Y-%m-%d 格式  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_share_change(symbol='SHSE.605090', start_date="2020-01-01", end_date="2022-10-01", df=False)
        print(df)
        

  * Output: 
        
        [{'symbol': 'SHSE.605090',
          'company_name': '江西九丰能源股份有限公司',
          'pub_date': '2021-05-24',
          'chg_date': '2021-05-13',
          'chg_reason': '首发A股上市',
          'chg_event': '发行融资',
          'share_total': 442969866,
          'share_total_nlf': 0,
          'share_prom': 0,
          'share_prom_state': 0,
          'share_state': 0,
          'share_state_lp': 0,
          'share_prom_soc': 0,
          'share_dc_lp': 0,
          'share_os_lp': 0,
          'share_prom_other': 0,
          'share_rs': 0,
          'share_rs_state': 0,
          'share_rs_dc_lp': 0,
          'share_rs_state_lp': 0,
          'share_rs_soc_lp': 0,
          'share_rs_os_lp': 0,
          'share_emp_nlf': 0,
          'share_pfd_nlf': 0,
          'share_oth_nlf': 0,
          'share_circ': 442969866,
          'share_ttl_unl': 82969866,
          'share_a_unl': 82969866,
          'share_b_unl': 0,
          'share_h_unl': 0,
          'share_oth_unl': 0,
          'share_ttl_ltd': 360000000,
          'share_gen_ltd': 360000000,
          'share_state_ltd': 0,
          'share_state_lp_ltd': 0,
          'share_oth_dc_ltd': 319670222,
          'share_nst_dc_lp_ltd': 215911310,
          'share_dc_np_ltd': 103758912,
          'share_forn_ltd': 40329778,
          'share_os_lp_ltd': 40329778,
          'share_os_np_ltd': 0,
          'share_lk_ltd': 0,
          'share_gm_ltd': 103758912,
          'share_plc_lp_ltd': 0,
          'share_plc_si_ltd': 0,
          'share_plc_lp_gen_ltd': 0,
          'share_plc_fnd_ltd': 0,
          'share_a_ltd': 360000000,
          'share_b_ltd': 0,
          'share_h_ltd': 0,
          'share_oth_ltd': 0,
          'share_list_date': '2021-05-25'},
         {'symbol': 'SHSE.605090',
          'company_name': '江西九丰能源股份有限公司',
          'pub_date': '2022-05-12',
          'chg_date': '2022-05-18',
          'chg_reason': '转增股上市',
          'chg_event': '分红派息',
          'share_total': 620157812,
          'share_total_nlf': 0,
          'share_prom': 0,
          'share_prom_state': 0,
          'share_state': 0,
          'share_state_lp': 0,
          'share_prom_soc': 0,
          'share_dc_lp': 0,
          'share_os_lp': 0,
          'share_prom_other': 0,
          'share_rs': 0,
          'share_rs_state': 0,
          'share_rs_dc_lp': 0,
          'share_rs_state_lp': 0,
          'share_rs_soc_lp': 0,
          'share_rs_os_lp': 0,
          'share_emp_nlf': 0,
          'share_pfd_nlf': 0,
          'share_oth_nlf': 0,
          'share_circ': 620157812,
          'share_ttl_unl': 116157812,
          'share_a_unl': 116157812,
          'share_b_unl': 0,
          'share_h_unl': 0,
          'share_oth_unl': 0,
          'share_ttl_ltd': 504000000,
          'share_gen_ltd': 504000000,
          'share_state_ltd': 0,
          'share_state_lp_ltd': 0,
          'share_oth_dc_ltd': 447538311,
          'share_nst_dc_lp_ltd': 302275834,
          'share_dc_np_ltd': 145262477,
          'share_forn_ltd': 56461689,
          'share_os_lp_ltd': 56461689,
          'share_os_np_ltd': 0,
          'share_lk_ltd': 0,
          'share_gm_ltd': 0,
          'share_plc_lp_ltd': 0,
          'share_plc_si_ltd': 0,
          'share_plc_lp_gen_ltd': 0,
          'share_plc_fnd_ltd': 0,
          'share_a_ltd': 504000000,
          'share_b_ltd': 0,
          'share_h_ltd': 0,
          'share_oth_ltd': 0,
          'share_list_date': '2022-05-19'},
         {'symbol': 'SHSE.605090',
          'company_name': '江西九丰能源股份有限公司',
          'pub_date': '2022-05-25',
          'chg_date': '2022-05-30',
          'chg_reason': '首发限售股份上市',
          'chg_event': '限售股解禁',
          'share_total': 620157812,
          'share_total_nlf': 0,
          'share_prom': 0,
          'share_prom_state': 0,
          'share_state': 0,
          'share_state_lp': 0,
          'share_prom_soc': 0,
          'share_dc_lp': 0,
          'share_os_lp': 0,
          'share_prom_other': 0,
          'share_rs': 0,
          'share_rs_state': 0,
          'share_rs_dc_lp': 0,
          'share_rs_state_lp': 0,
          'share_rs_soc_lp': 0,
          'share_rs_os_lp': 0,
          'share_emp_nlf': 0,
          'share_pfd_nlf': 0,
          'share_oth_nlf': 0,
          'share_circ': 620157812,
          'share_ttl_unl': 252807819,
          'share_a_unl': 252807819,
          'share_b_unl': 0,
          'share_h_unl': 0,
          'share_oth_unl': 0,
          'share_ttl_ltd': 367349993,
          'share_gen_ltd': 367349993,
          'share_state_ltd': 0,
          'share_state_lp_ltd': 0,
          'share_oth_dc_ltd': 367349993,
          'share_nst_dc_lp_ltd': 222087516,
          'share_dc_np_ltd': 145262477,
          'share_forn_ltd': 0,
          'share_os_lp_ltd': 0,
          'share_os_np_ltd': 0,
          'share_lk_ltd': 0,
          'share_gm_ltd': 0,
          'share_plc_lp_ltd': 0,
          'share_plc_si_ltd': 0,
          'share_plc_lp_gen_ltd': 0,
          'share_plc_fnd_ltd': 0,
          'share_a_ltd': 367349993,
          'share_b_ltd': 0,
          'share_h_ltd': 0,
          'share_oth_ltd': 0,
          'share_list_date': '2022-05-30'}]
        

* * *

## 沪深港股通¶

###  hk_hold \- 沪深港股通持股明细 ¶
    
    
    hk_hold(code=None, symbol=None, trade_date=None, start_date=None, end_date=None, exchange=None, fields=None, df=True)
    

获取沪股通、深股通每日前十大成交详细数据

数据范围 | 更新频率 | 更新时间  
---|---|---  
2014-11-17 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`code` |  `str` |  交易所代码 |  `None`  
`symbol` |  `str` |  股票代码，例如（SHSE.600000, SZSE.000001）（二选一） |  `None`  
`trade_date` |  `str` |  交易日期，%Y-%m-%d（二选一） |  `None`  
`start_date` |  `str` |  开始日期，%Y-%m-%d |  `None`  
`end_date` |  `str` |  结束日期，%Y-%m-%d |  `None`  
`exchange` |  `str` |  类型：SH沪股通（北向）SZ深股通（北向）HK港股通（南向持股） |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `None`  
`df` |  `bool` |  是否按DataFrame格式返回' |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`code` |  `str` |  原始代码  
`trade_date` |  `str` |  交易日期  
`symbol` |  `str` |  股票代码  
`name` |  `str` |  股票名称  
`vol` |  `int` |  持股数量(股)  
`ratio` |  `float` |  持股占比（%），占已发行股份百分比  
`exchange` |  `str` |  类型：SH沪股通SZ深股通HK港股通  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.hk_hold(trade_date='2023-12-01')
    print(data)
    

输出: 
    
    
           code    creation_datetime exchange  ...  trade_date       symbol         vol
    0         1  2024-01-31 06:35:45       HK  ...  2023-12-01  HKSE.00001.    54649045
    1         2  2024-01-31 06:35:45       HK  ...  2023-12-01  HKSE.00002.     8441678
    2         3  2024-01-31 06:35:45       HK  ...  2023-12-01  HKSE.00003.    60808435
    3         4  2024-01-31 06:35:45       HK  ...  2023-12-01  HKSE.00004.     5439950
    4         5  2024-01-31 06:35:45       HK  ...  2023-12-01  HKSE.00005.  1786279792
    ...     ...                  ...      ...  ...         ...          ...         ...
    3962  78525  2024-01-31 06:35:44       SZ  ...  2023-12-01  SZSE.301525      222846
    3963  78528  2024-01-31 06:35:44       SZ  ...  2023-12-01  SZSE.301528       20645
    3964  78550  2024-01-31 06:35:44       SZ  ...  2023-12-01  SZSE.301550      675285
    3965  78558  2024-01-31 06:35:44       SZ  ...  2023-12-01  SZSE.301558     1891358
    3966  78559  2024-01-31 06:35:44       SZ  ...  2023-12-01  SZSE.301559      906182
    
    [3967 rows x 10 columns]
    

###  hsgt_top10 \- 沪深股通十大成交股 ¶
    
    
    hsgt_top10(symbol=None, trade_date=None, start_date=None, end_date=None, market_type=None, fields=None, df=True)
    

获取沪股通、深股通每日前十大成交详细数据

数据范围 | 更新频率 | 更新时间  
---|---|---  
2014-11-17 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  股票代码，例如（SHSE.600000, SZSE.000001）（二选一） |  `None`  
`trade_date` |  `str` |  交易日期，%Y-%m-%d（二选一） |  `None`  
`start_date` |  `str` |  开始日期，%Y-%m-%d |  `None`  
`end_date` |  `str` |  结束日期，%Y-%m-%d |  `None`  
`market_type` |  `str` |  市场类型（1：沪市 3：深市） |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `None`  
`df` |  `bool` |  是否按DataFrame格式返回 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期  
`symbol` |  `str` |  股票代码  
`name` |  `str` |  股票名称  
`close` |  `float` |  收盘价  
`change` |  `float` |  涨跌额  
`rank` |  `int` |  资金排名  
`market_type` |  `str` |  市场类型（1：沪市 3：深市）  
`amount` |  `float` |  成交金额（元）  
`net_amount` |  `float` |  净成交金额（元）  
`buy` |  `float` |  买入金额（元）  
`sell` |  `float` |  卖出金额（元）  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.hsgt_top10(trade_date='2024-01-10', market_type='1')
    print(data)
    

输出: 
    
    
           amount        buy  change  ...       sell  trade_date       symbol
    0  1235360536  516886967  0.0305  ...  718473569  2024-01-10  SHSE.600519
    1   594468021  193824827 -0.8496  ...  400643194  2024-01-10  SHSE.600900
    2   860363587  332407745 -0.0450  ...  527955842  2024-01-10  SHSE.601012
    3   738772192  371344296  3.6936  ...  367427896  2024-01-10  SHSE.601127
    4   314723982  159557362 -0.2688  ...  155166620  2024-01-10  SHSE.601288
    5   424626232  183635399 -1.4591  ...  240990833  2024-01-10  SHSE.601318
    6   393426839  170119818 -0.6148  ...  223307021  2024-01-10  SHSE.601398
    7   711045919  321487593  1.8449  ...  389558326  2024-01-10  SHSE.601888
    8   322236619  154084529 -3.7075  ...  168152090  2024-01-10  SHSE.601919
    9   617239514  413244012  0.3264  ...  203995502  2024-01-10  SHSE.603259
    
    [10 rows x 14 columns]
    

## 融资融券¶

###  margin \- 融资融券交易汇总 ¶
    
    
    margin(trade_date=None, exchange_id=None, start_date=None, end_date=None, fields=None, df=True)
    

获取融资融券每日交易汇总数据

数据范围 | 更新频率 | 更新时间  
---|---|---  
2010-03-31 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_date` |  `str` |  交易日期，%Y-%m-%d |  `None`  
`start_date` |  `str` |  开始日期，%Y-%m-%d |  `None`  
`end_date` |  `str` |  结束日期，%Y-%m-%d |  `None`  
`exchange_id` |  `str` |  交易所代码 (SHSE上交所 SZSE深交所 BSE北交所) |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `None`  
`df` |  `bool` |  是否按DataFrame格式返回' |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期  
`exchange_id` |  `str` |  交易所代码（SHSE上交所 SZSE深交所 BSE北交所）  
`rzye` |  `float` |  融资余额(元)  
`rzmre` |  `float` |  融资买入额(元)  
`rzche` |  `float` |  融资偿还额(元)  
`rqye` |  `float` |  融券余额(元)  
`rqmcl` |  `float` |  融券卖出量(股,份,手)  
`rzrqye` |  `float` |  融资融券余额(元)  
`rqyl` |  `float` |  融券余量(股,份,手)  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.margin(trade_date='2023-12-08')
    print(data)
    

输出: 
    
    
         creation_datetime exchange_id   id  ...        rzrqye          rzye  trade_date
    0  2024-01-31 10:29:28         BSE  257  ...     946347087     940736053  2023-12-08
    1  2024-01-31 10:29:27        SHSE  255  ...  883159110572  834523805754  2023-12-08
    2  2024-01-31 10:29:27        SZSE  256  ...  783798277222  756544736642  2023-12-08
    
    [3 rows x 12 columns]
    

###  margin_detail \- 融资融券交易明细 ¶
    
    
    margin_detail(trade_date=None, symbol=None, start_date=None, end_date=None, fields=None, df=True)
    

获取沪深两市每日融资融券明细

数据范围 | 更新频率 | 更新时间  
---|---|---  
2010-03-31 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_date` |  `str` |  交易日期，%Y-%m-%d |  `None`  
`start_date` |  `str` |  开始日期，%Y-%m-%d |  `None`  
`end_date` |  `str` |  结束日期，%Y-%m-%d |  `None`  
`symbol` |  `str` |  股票代码，例如（SHSE.600000, SZSE.000001） |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `None`  
`df` |  `bool` |  是否按DataFrame格式返回' |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期  
`symbol` |  `str` |  股票代码，例如（SHSE.600000, SZSE.000001）  
`name` |  `str` |  股票名称 （20190910后有数据）  
`rzye` |  `float` |  融资余额(元)  
`rqye` |  `float` |  融券余额(元)  
`rzmre` |  `float` |  融资买入额(元)  
`rqyl` |  `float` |  融券余量(股,份,手)  
`rzche` |  `float` |  融资偿还额(元)  
`rqchl` |  `float` |  融券偿还量(股)  
`rqmcl` |  `float` |  融券卖出量(股,份,手)  
`rzrqye` |  `float` |  融资融券余额(元)  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.margin_detail(symbol='SHSE_601226', trade_date='2023-12-01')
    print(data)
    

输出: 
    
    
         creation_datetime   id  ...  trade_date       symbol
    0  2024-01-31 10:29:39  821  ...  2023-12-01  SHSE.601226
    
    [1 rows x 14 columns]
    

###  margin_target \- 融资融券标的 ¶
    
    
    margin_target(symbol=None, is_new=None, mg_type=None, fields=None, df=True)
    

获取全市场融资融券标的

数据范围 | 更新频率 | 更新时间  
---|---|---  
2010-02-12 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  股票代码，例如（SHSE.600000, SZSE.000001） |  `None`  
`is_new` |  `str` |  是否最新 |  `None`  
`mg_type` |  `str` |  标的类型：B买入标的 S卖出标的 |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `None`  
`df` |  `bool` |  是否按DataFrame格式返回' |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`mg_type` |  `str` |  标的类型：B买入标的 S卖出标的  
`is_new` |  `str` |  最新标记：Y是 N否  
`in_date` |  `str` |  纳入日期  
`out_date` |  `str` |  剔除日期  
`ann_date` |  `str` |  公布日期  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.margin_target(symbol='SHSE.605305')
    print(data)
    

输出: 
    
    
         ann_date    creation_datetime  ...  out_date       symbol
    0  2022-10-24  2024-01-31 06:29:30  ...      None  SHSE.605305
    1  2022-10-24  2024-01-31 06:29:30  ...      None  SHSE.605305
    
    [2 rows x 9 columns]
    

## 资金流向¶

###  moneyflow \- 个股资金流向 ¶
    
    
    moneyflow(symbol=None, trade_date=None, start_date=None, end_date=None, fields='symbol,trade_date,buy_sm_vol,buy_sm_amount,sell_sm_vol,sell_sm_amount,buy_md_vol,buy_md_amount,sell_md_vol,sell_md_amount,buy_lg_vol,buy_lg_amount,sell_lg_vol,sell_lg_amount,buy_elg_vol,buy_elg_amount,sell_elg_vol,sell_elg_amount,net_mf_vol,net_mf_amount', df=True)
    

获取沪深A股票资金流向数据，分析大单小单成交情况，用于判别资金动向，数据开始于2010年。

数据范围 | 更新频率 | 更新时间  
---|---|---  
2007-01-04 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  股票代码(股票和时间参数至少输入一个),例如（SHSE.600000, SZSE.000001） |  `None`  
`trade_date` |  `str` |  交易日期 |  `None`  
`start_date` |  `str` |  开始日期 |  `None`  
`end_date` |  `str` |  结束日期 |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `'symbol,trade_date,buy_sm_vol,buy_sm_amount,sell_sm_vol,sell_sm_amount,buy_md_vol,buy_md_amount,sell_md_vol,sell_md_amount,buy_lg_vol,buy_lg_amount,sell_lg_vol,sell_lg_amount,buy_elg_vol,buy_elg_amount,sell_elg_vol,sell_elg_amount,net_mf_vol,net_mf_amount'`  
`df` |  `bool` |  是否按DataFrame格式返回 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码,例如（SHSE.600000, SZSE.000001）  
`trade_date` |  `str` |  交易日期  
`buy_sm_vol` |  `int` |  小单买入量（手）  
`buy_sm_amount` |  `float` |  小单买入金额（万元）  
`sell_sm_vol` |  `int` |  小单卖出量（手）  
`sell_sm_amount` |  `float` |  小单卖出金额（万元）  
`buy_md_vol` |  `int` |  中单买入量（手）  
`buy_md_amount` |  `float` |  中单买入金额（万元）  
`sell_md_vol` |  `int` |  中单卖出量（手）  
`sell_md_amount` |  `float` |  中单卖出金额（万元）  
`buy_lg_vol` |  `int` |  大单买入量（手）  
`buy_lg_amount` |  `float` |  大单买入金额（万元）  
`sell_lg_vol` |  `int` |  大单卖出量（手）  
`sell_lg_amount` |  `float` |  大单卖出金额（万元）  
`buy_elg_vol` |  `int` |  特大单买入量（手）  
`buy_elg_amount` |  `float` |  特大单买入金额（万元）  
`sell_elg_vol` |  `int` |  特大单卖出量（手）  
`sell_elg_amount` |  `float` |  特大单卖出金额（万元）  
`net_mf_vol` |  `int` |  净流入量（手）  
`net_mf_amount` |  `float` |  净流入额（万元）  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.moneyflow(symbol='SHSE.600000')
    print(data)
    

输出: 
    
    
        buy_elg_amount  buy_elg_vol  buy_lg_amount  buy_lg_vol  buy_md_amount  ...  sell_md_vol  sell_sm_amount  sell_sm_vol  trade_date       symbol
    0           647.93         9430        3486.46       50814        6826.78  ...       103597         6939.65       101095  2023-12-01   SHSE.600000
    1           804.63        11788        3523.17       51556        3582.05  ...        53826         6260.59        91615  2023-12-04   SHSE.600000
    2          1298.20        19241        6022.59       89162        7285.81  ...       110355        10364.25       153513  2023-12-05   SHSE.600000
    3          2066.69        31188        5973.81       90116        8700.83  ...       124020        12607.25       190249  2023-12-06   SHSE.600000
    4           591.74         8989        2973.19       45127        6400.79  ...        87582         9371.75       142268  2023-12-07   SHSE.600000
    5          1996.95        29965        3331.85       50090        6846.71  ...       101299         8208.04       123374  2023-12-08   SHSE.600000
    

###  moneyflow_hsgt \- 沪深港通资金流向 ¶
    
    
    moneyflow_hsgt(trade_date=None, start_date=None, end_date=None, fields='trade_date,ggt_ss,ggt_sz,hgt,north_money,south_money', df=True)
    

获取沪股通、深股通、港股通每日资金流向数据。

数据范围 | 更新频率 | 更新时间  
---|---|---  
2014-11-17 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_date` |  `str` |  交易日期(二选一) |  `None`  
`start_date` |  `str` |  开始日期(二选一) |  `None`  
`end_date` |  `str` |  结束日期 |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `'trade_date,ggt_ss,ggt_sz,hgt,north_money,south_money'`  
`df` |  `bool` |  是否按DataFrame格式返回 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期  
`ggt_ss` |  `float` |  港股通（上海）  
`ggt_sz` |  `float` |  港股通（深圳）  
`hgt` |  `float` |  沪股通（百万元）  
`sgt` |  `float` |  深股通（百万元）  
`north_money` |  `float` |  北向资金（百万元）  
`south_money` |  `float` |  南向资金（百万元）  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.moneyflow_hsgt(trade_date='2023-12-21')
    print(data)
    

输出: 
    
    
      ggt_ss  ggt_sz    hgt  north_money  south_money  trade_date
    0  1461.49  976.01  803.1      1202.82       2437.5  2023-12-21
    

## 质押回购¶

###  pledge_stat \- 获取股票质押统计数据 ¶
    
    
    pledge_stat(*, symbol=None, end_date=None, fields=tdf.pledge_stat, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 7:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`end_date` |  `str | datetime | timestamp` |  截止日期，%Y-%m-%d 格式，默认None |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `pledge_stat`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`end_date` |  `str` |  截止日期  
`pledge_count` |  `int` |  质押次数  
`unrest_pledge` |  `float` |  无限售股质押数量（万）  
`rest_pledge` |  `float` |  限售股份质押数量（万）  
`total_share` |  `float` |  总股本  
`pledge_ratio` |  `float` |  质押比例  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        df = ait0.ts.pledge_stat(symbol="SHSE.600004", end_date="2014-08-22")
        print(df)
        

  * Output: 
        
        symbol    end_date  pledge_count  unrest_pledge  rest_pledge  total_share  pledge_ratio
        0  SHSE.600004  2014-07-25             8          38.10            0       115000          0.03
        1  SHSE.600004  2014-08-01             1           1.50            0       115000          0.00
        2  SHSE.600004  2014-08-08             1           1.50            0       115000          0.00
        3  SHSE.600004  2014-08-15             2           4.56            0       115000          0.00
        4  SHSE.600004  2014-08-22             1           1.50            0       115000          0.00
        

* * *

###  repurchase \- 获取上市公司回购股票数据 ¶
    
    
    repurchase(*, ann_date=None, start_date=None, end_date=None, fields=tdf.repurchase, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 7:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`ann_date` |  `str | datetime | timestamp` |  公告日期，%Y-%m-%d 格式，默认None |  `None`  
`start_date` |  `str | datetime | timestamp` |  公告开始日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  公告结束日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `repurchase`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`ann_date` |  `str` |  公告日期  
`end_date` |  `str` |  公告日期  
`proc` |  `str` |  进度  
`exp_date` |  `str` |  过期日期  
`vol` |  `float` |  回购数量  
`amount` |  `float` |  回购金额  
`high_limit` |  `float` |  回购最高价  
`low_limit` |  `float` |  回购最低价  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        df = ait0.ts.repurchase(ann_date="2024-01-04")
        print(df)
        

  * Output: 
        
        symbol    ann_date    end_date proc exp_date       vol        amount  high_limit  low_limit
        0  SHSE.600116  2024-01-04  2023-12-31   实施     None  16084191  1.255435e+08        8.04       7.45
        1  SHSE.600337  2024-01-04  2023-12-31   实施     None   6591700  1.724630e+07        2.77       2.50
        2  SHSE.600388  2024-01-04  2023-12-29   实施     None   4493000  5.928768e+07       13.99      11.77
        

* * *

###  stk_holdertrade \- 获取上市公司增减持数据 ¶
    
    
    stk_holdertrade(*, symbol=None, ann_date=None, start_date=None, end_date=None, trade_type=None, holder_type=None, fields=tdf.stk_holdertrade, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 7:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`ann_date` |  `str | datetime | timestamp` |  公告日期，%Y-%m-%d 格式，默认None |  `None`  
`start_date` |  `str | datetime | timestamp` |  公告开始日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  公告结束日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`trade_type` |  `str | list` |  交易类型：   
IN - 增持   
DE - 减持 |  `None`  
`holder_type` |  `str | list` |  股东类型：   
C - 公司   
P - 个人   
G - 高管 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_holdertrade`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`ann_date` |  `str` |  公告日期  
`holder_name` |  `str` |  股东名称  
`holder_type` |  `str` |  股东类型：   
C - 公司   
P - 个人   
G - 高管  
`in_de` |  `str | list` |  交易类型：   
IN - 增持   
DE - 减持  
`change_vol` |  `float` |  变动数量  
`change_ratio` |  `float` |  占流通比例（%）  
`after_share` |  `float` |  变动后持股  
`after_ratio` |  `float` |  变动后占流通比例（%）  
`avg_price` |  `float` |  平均价格  
`total_share` |  `float` |  持股总数  
`begin_date` |  `str` |  增减持开始日期  
`close_date` |  `str` |  增减持结束日期  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        df = ait0.ts.stk_holdertrade(symbol=["SHSE.600137"], start_date="2023-12-25", end_date="2024-01-18")
        print(df)
        

  * Output: 
        
        symbol    ann_date holder_name holder_type in_de  change_vol  change_ratio  after_share  after_ratio avg_price  total_share  begin_date  close_date
        0  SHSE.600137  2024-01-04  西藏巨浪科技有限公司           C    DE      972200             1     18316688      18.8409      None     18316688  2023-12-21  2024-01-02
        1  SHSE.600137  2024-01-13  西藏巨浪科技有限公司           C    DE      972200             1     17344488      17.8409      None     17344488  2024-01-08  2024-01-12
        2  SHSE.600137  2024-01-18  西藏巨浪科技有限公司           C    DE      972200             1     16372288      16.8409      None     16372288  2024-01-17  2024-01-17
        

* * *

###  share_float \- 获取限售股解禁 ¶
    
    
    share_float(*, symbol=None, ann_date=None, float_date=None, start_date=None, end_date=None, fields=tdf.share_float, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 7:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`ann_date` |  `str | datetime | timestamp` |  公告日期，%Y-%m-%d 格式，默认None |  `None`  
`float_date` |  `str | datetime | timestamp` |  解禁日期，%Y-%m-%d 格式，默认None |  `None`  
`start_date` |  `str | datetime | timestamp` |  解禁开始日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`end_date` |  `str | datetime | timestamp` |  解禁结束日期，%Y-%m-%d 格式，默认None取当天数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `share_float`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`ann_date` |  `str` |  公告日期  
`float_date` |  `str` |  解禁日期  
`float_share` |  `float` |  流通股份(股)  
`float_ratio` |  `float` |  流通股份占总股本比率  
`holder_name` |  `str` |  股东名称  
`share_type` |  `str` |  股份类型  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        df = ait0.ts.share_float(symbol=["SHSE.688084"], start_date="2023-12-01", end_date="2023-12-08")
        print(df)
        

  * Output: 
        
        symbol    ann_date  float_date  float_share  float_ratio           holder_name share_type
        0  SHSE.688084  2022-12-07  2023-12-08       892910       1.1802  北京融杰上景管理咨询合伙企业(有限合伙)      首发原始股
        1  SHSE.688084  2023-12-01  2023-12-08       892910       1.1802  北京融杰上景管理咨询合伙企业(有限合伙)      首发原始股
        

* * *

## 龙虎榜¶

###  top_inst \- 龙虎榜机构成交明细 ¶
    
    
    top_inst(trade_date, symbol=None, fields='trade_date,symbol,exalter,side,buy,buy_rate,sell,sell_rate,net_buy,reason', df=True)
    

龙虎榜机构成交明细

数据范围 | 更新频率 | 更新时间  
---|---|---  
2012-01-04 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_date` |  `str` |  交易日期 |  _必需_  
`symbol` |  `str` |  股票代码,例如（SHSE.600000, SZSE.000001） |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `'trade_date,symbol,exalter,side,buy,buy_rate,sell,sell_rate,net_buy,reason'`  
`df` |  `bool` |  是否按DataFrame格式返回 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期  
`symbol` |  `str` |  股票代码,例如（SHSE.600000, SZSE.000001）  
`exalter` |  `str` |  营业部名称  
`side` |  `str` |  买卖类型0：买入金额最大的前5名， 1：卖出金额最大的前5名  
`buy` |  `float` |  买入额（元）  
`buy_rate` |  `float` |  买入占总成交比例  
`sell` |  `float` |  卖出额（元）  
`sell_rate` |  `float` |  卖出占总成交比例  
`net_buy` |  `float` |  净成交额（元）  
`reason` |  `str` |  上榜理由  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.top_inst(trade_date='2023-12-01',symbol='SHSE.600178')
    print(data)
    

输出: 
    
    
        buy buy_rate                   exalter   net_buy                     reason      sell  sell_rate side  trade_date       symbol
    0  None     None  东方财富证券股份有限公司拉萨团结路第一证券营业部 -18299806  有价格涨跌幅限制的日价格振幅达到15%的前五只证券  18299806       1.02    1  2023-12-01  SHSE.600178
    

###  top_list \- 龙虎榜每日交易明细 ¶
    
    
    top_list(trade_date, symbol=None, fields='trade_date,symbol,name,close,pct_change,turnover_rate,amount,l_sell,l_buy,l_amount,net_amount,net_rate,amount_rate,float_values,reason', df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
2005-01-19 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_date` |  `str` |  交易日期 |  _必需_  
`symbol` |  `str` |  股票代码,例如（SHSE.600000, SZSE.000001） |  `None`  
`fields` |  `str` |  返回字段，半角逗号分隔 |  `'trade_date,symbol,name,close,pct_change,turnover_rate,amount,l_sell,l_buy,l_amount,net_amount,net_rate,amount_rate,float_values,reason'`  
`df` |  `bool` |  是否按DataFrame格式返回 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期  
`symbol` |  `str` |  股票代码,例如（SHSE.600000, SZSE.000001）  
`name` |  `str` |  名称  
`close` |  `float` |  收盘价  
`pct_change` |  `float` |  涨跌幅  
`turnover_rate` |  `float` |  换手率  
`amount` |  `float` |  总成交额  
`l_sell` |  `float` |  龙虎榜卖出额  
`l_buy` |  `float` |  龙虎榜买入额  
`l_amount` |  `float` |  龙虎榜成交额  
`net_amount` |  `float` |  龙虎榜净买入额  
`net_rate` |  `float` |  龙虎榜净买额占比  
`amount_rate` |  `float` |  龙虎榜成交额占比  
`float_values` |  `float` |  当日流通市值  
`reason` |  `str` |  上榜理由  
  
**示例：**

输入: 
    
    
    from ait0 import *
    data = ts.top_list(trade_date='2023-12-01',symbol='SHSE.600178')
    print(data)
    

输出: 
    
    
        amount  amount_rate  close  float_values      l_amount  ...  pct_change                     reason  trade_date       symbol  turnover_rate
    0  1800016855        15.01   15.2    7023616000  2.701943e+08  ...      9.9855  有价格涨跌幅限制的日价格振幅达到15%的前五只证券  2023-12-01  SHSE.600178           28.7
    

## 预测数据¶

###  stk_forecast_esp \- 获取不同周期的预测每股收益 ¶
    
    
    stk_forecast_esp(*, symbol=None, start_date=None, end_date=None, fields=idf.fore_eps, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
股票 | 每个交易日 | 6:30pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  输入标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用list格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `fore_eps`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  合约代码  
`trade_date` |  `str` |  交易日期  
`fore_eps_fy1_stock` |  `float` |  当前财政年度的预测每股收益。  
`fore_eps_in12m_stock` |  `float` |  从当前时点起未来12个月的预测每股收益。  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.ifind.stk_forecast_esp(start_date="2024-05-16", end_date="2024-05-16")
        print(df)
        

Output: 
        
        symbol  trade_date  fore_eps_fy1_stock  fore_eps_in12m_stock
        0     SHSE.600000  2024-05-16              1.1680              1.190356
        1     SHSE.600004  2024-05-16              0.4859              0.536760
        2     SHSE.600007  2024-05-16              1.3017              1.331508
        3     SHSE.600009  2024-05-16              1.1551              1.344308
        4     SHSE.600010  2024-05-16              0.0200              0.026222
        ...           ...         ...                 ...                   ...
        2782  SZSE.301548  2024-05-16              2.3400              2.587781
        2783  SZSE.301550  2024-05-16              1.8600              1.994137
        2784  SZSE.301559  2024-05-16              1.1800              1.332767
        2785  SZSE.301567  2024-05-16              2.5100              2.979479
        2786  SZSE.301589  2024-05-16             17.8003             20.659616
        

* * *

###  stk_forecast_beats \- 获取每股收益超预期 ¶
    
    
    stk_forecast_beats(*, symbol=None, start_date=None, end_date=None, cycle=None, fields=idf.over_fore, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
股票 | 每个交易日 | 6:30pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  输入标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用list格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`cycle` |  `int | list` |  综合值周期   
30: 30天   
90: 90天   
180: 180天 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `over_fore`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  合约代码  
`year` |  `str` |  所属年份  
`cycle` |  `int` |  综合值周期  
`eps_over_fore_stock` |  `float` |  每股收益超预期  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.ifind.stk_forecast_beats(start_date="2023-01-01", end_date="2024-01-01", cycle="30")
        print(df)
        

Output: 
        
        symbol  year  cycle  eps_over_fore_stock
        0    SHSE.600011  2023     30              -0.6800
        1    SHSE.600025  2023     30              -0.0500
        2    SHSE.600026  2023     30              -0.0627
        3    SHSE.600027  2023     30              -0.1750
        4    SHSE.600028  2023     30              -0.2150
        ..           ...   ...    ...                  ...
        690  SZSE.301398  2023     30              -0.0100
        691  SZSE.301413  2023     30               0.2000
        692  SZSE.301498  2023     30               0.0950
        693  SZSE.301509  2023     30               0.6600
        694  SZSE.301567  2023     30               0.0400
        

* * *

###  stk_org_info \- 获取机构信息 ¶
    
    
    stk_org_info(*, org_id=None, fields=idf.org_info, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
- | - | -  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`org_id` |  `int | list` |  机构ID |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `org_info`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`id` |  `int` |  机构ID  
`name` |  `str` |  机构名称  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.ifind.stk_org_info()
        print(df)
        

Output: 
        
        id           name
        0    2301  J.P摩根证券亚洲有限公司
        1    2059     万联证券有限责任公司
        2    2345   上海华信证券有限责任公司
        3    2017     上海证券有限责任公司
        4    2025     世纪证券有限责任公司
        ..    ...            ...
        150  2093     首创证券有限责任公司
        151  2317       高盛亚洲有限公司
        152  2077   高盛高华证券有限责任公司
        153  2339    麦格理资本股份有限公司
        154  2054       齐鲁证券有限公司
        

* * *

###  stk_forecast_org \- 获取机构预测每股收益 ¶
    
    
    stk_forecast_org(*, symbol=None, org_id=None, start_date=None, end_date=None, year=None, fields=idf.org_fore, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
股票 | - | -  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  输入标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用list格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`org_id` |  `int | list` |  机构ID |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`year` |  `int | list` |  所属年份 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `org_fore`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`year` |  `str` |  所属年份  
`symbol` |  `str` |  合约代码  
`trade_date` |  `int` |  交易日期  
`org_id` |  `int` |  机构ID  
`org_fore_eps_stock` |  `float` |  机构预测每股收益  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.ifind.stk_forecast_org(start_date="2024-05-16", end_date="2024-05-16", symbol="SHSE.600048")
        print(df)
        

Output: 
        
        year       symbol  trade_date  org_id  org_fore_eps_stock
        0  2024  SHSE.600048  2024-05-16    2059                1.08
        1  2024  SHSE.600048  2024-05-16    2035                1.72
        2  2024  SHSE.600048  2024-05-16    2037                1.06
        3  2024  SHSE.600048  2024-05-16    2010                1.02
        

* * *

## 经济数据库¶

###  edb \- 获取经济数据库(EDB)-全球经济 ¶
    
    
    edb(*, id=None, start_date=None, end_date=None, fields=idf.edb, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
美国:美元指数(G002600885) | 日频 | 09:00  
美国:国债收益率:2年(G002600770) | 日频 | 09:00  
美国:国债收益率:10年(G002600774) | 日频 | 09:00  
美国:国债收益率:以通胀为标的:10年(G002600783) | 日频 | 09:00  
美元(USD)兑离岸人民币(CNH)(G019845265) | 日频 | 09:00  
花旗经济意外指数:美国(G005326174) | 日频 | 09:00  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`id` |  `int | list` |  指标ID,目前支持见上表 |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `edb`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`time` |  `str` |  报告期  
`id` |  `str` |  指标代码  
`value` |  `str` |  指标值  
`index_name` |  `str` |  指标名  
`rtime` |  `str` |  入库时间  
  
**示例：**

  * Input: 
        
        from ait0
        ait0.config.set_mode(config.MODE_LIVE_REMOTE)
        ait0.set_api_key('xxxxx')
        df = ait0.ifind.edb(id='G002600885', start_date='2024-08-01', end_date='2024-08-27')
        print(df)
        

Output: 
        
        time          id     value index_name                rtime
        0   2024-08-01  G002600885  104.3323    美国:美元指数  2024-08-02 07:13:16
        1   2024-08-02  G002600885  103.2225    美国:美元指数  2024-08-03 07:11:40
        2   2024-08-05  G002600885  102.7209    美国:美元指数  2024-08-06 07:11:54
        3   2024-08-06  G002600885  103.0182    美国:美元指数  2024-08-07 04:09:48
        4   2024-08-07  G002600885  103.1823    美国:美元指数  2024-08-08 07:12:38
        5   2024-08-08  G002600885  103.2235    美国:美元指数  2024-08-09 07:11:46
        6   2024-08-09  G002600885  103.1598    美国:美元指数  2024-08-10 07:13:06
        7   2024-08-12  G002600885  103.1271    美国:美元指数  2024-08-13 07:08:46
        8   2024-08-13  G002600885  102.6327    美国:美元指数  2024-08-14 07:08:31
        9   2024-08-14  G002600885  102.5996    美国:美元指数  2024-08-15 07:08:31
        10  2024-08-15  G002600885  103.0627    美国:美元指数  2024-08-16 07:08:31
        11  2024-08-16  G002600885  102.4129    美国:美元指数  2024-08-17 07:08:30
        12  2024-08-19  G002600885  101.8825    美国:美元指数  2024-08-20 07:08:31
        13  2024-08-20  G002600885  101.3642    美国:美元指数  2024-08-21 07:08:30
        14  2024-08-21  G002600885  101.1717    美国:美元指数  2024-08-22 07:08:31
        15  2024-08-22  G002600885  101.5109    美国:美元指数  2024-08-23 07:08:30
        16  2024-08-23  G002600885  100.6815    美国:美元指数  2024-08-24 07:08:31
        17  2024-08-26  G002600885  100.8796    美国:美元指数  2024-08-27 07:08:30
        

* * *
