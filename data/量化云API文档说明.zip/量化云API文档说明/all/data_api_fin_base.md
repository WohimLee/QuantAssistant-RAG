---
# Converted from: data_api_fin_base\index.html
---

# 财务数据及指标函数¶

##  stk_get_fundamentals_balance \- 查询资产负债表数据 ¶
    
    
    stk_get_fundamentals_balance(*, symbols=None, rpt_type=None, data_type=None, start_date=None, end_date=None, pivot_date=None, fields=gdf.stk_get_fundamentals_balance, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`rpt_type` |  `int` |  报表类型  
按报告期查询可指定以下报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报   
默认None为不限 |  `None`  
`data_type` |  `int` |  数据类型  
在发布原始财务报告以后，上市公司可能会对数据进行修正。   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整   
默认None返回当期合并调整，如果没有调整返回合并原始 |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_get_fundamentals_balance`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
说明

symbols如果为空，则返回全市场数据，限制时间区间为6个月

**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`pub_date` |  `str` |  发布日期   
若数据类型选择合并原始(data_type=101)，则返回原始发布的发布日期   
若数据类型选择合并调整(data_type=102)，则返回调整后最新发布日期   
若数据类型选择母公司原始(data_type=201)，则返回母公司原始发布的发布日期   
若数据类型选择母公司调整(data_type=202)，则返回母公司调整后最新发布日期  
`rpt_date` |  `str` |  报告日期  
报告截止日期，财报统计的最后一天，在指定时间段[开始时间,结束时间]内的报告截止日期  
`rpt_type` |  `int` |  报表类型  
返回数据的报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报  
`data_type` |  `int` |  数据类型  
返回数据的数据类型：   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整  
`fields` |  `list[float]` |  财务字段数据  
指定返回fields字段的数值，支持的字段名请参考：   
**流动资产(资产)**   
cash_bal_cb: 现金及存放中央银行款项（元）   
dpst_ob: 存放同业款项（元）   
mny_cptl: 货币资金（元）   
cust_cred_dpst: 客户信用资金存款（元）   
cust_dpst: 客户资金存款（元）   
pm: 贵金属（元）   
bal_clr: 结算备付金（元）   
cust_rsv: 客户备付金（元）   
ln_to_ob: 拆出资金（元）   
fair_val_fin_ast: 以公允价值计量且其变动计入当期损益的金融资产（元）   
ppay: 预付款项（元）   
fin_out: 融出资金（元）   
trd_fin_ast: 交易性金融资产（元）   
deriv_fin_ast: 衍生金融资产（元）   
note_acct_rcv: 应收票据及应收账款（元）   
note_rcv: 应收票据（元）   
acct_rcv: 应收账款（元）   
acct_rcv_fin: 应收款项融资（元）   
int_rcv: 应收利息（元）   
dvd_rcv: 应收股利（元）   
oth_rcv: 其他应收款（元）   
in_prem_rcv: 应收保费（元）   
rin_acct_rcv: 应收分保账款（元）   
rin_rsv_rcv: 应收分保合同准备金（元）   
rcv_un_prem_rin_rsv: 应收分保未到期责任准备金（元）   
rcv_clm_rin_rsv: 应收分保未决赔偿准备金（元）   
rcv_li_rin_rsv: 应收分保寿险责任准备金（元）   
rcv_lt_hi_rin_rsv: 应收分保长期健康险责任准备金（元）   
ph_plge_ln: 保户质押贷款（元）   
ttl_oth_rcv: 其他应收款合计（元）   
rfd_dpst: 存出保证金（元）   
term_dpst: 定期存款（元）   
pur_resell_fin: 买入返售金融资产（元）   
aval_sale_fin: 可供出售金融资产（元）   
htm_inv: 持有至到期投资（元）   
hold_for_sale: 持有待售资产（元）   
acct_rcv_inv: 应收款项类投资（元）   
invt: 存货（元）   
contr_ast: 合同资产（元）   
ncur_ast_one_y: 一年内到期的非流动资产（元）   
oth_cur_ast: 其他流动资产（元）   
cur_ast_oth_item: 流动资产其他项目（元）   
ttl_cur_ast: 流动资产合计（元）   
**非流动资产(资产)**   
loan_adv: 发放委托贷款及垫款（元）   
cred_inv: 债权投资（元）   
oth_cred_inv: 其他债权投资（元）   
lt_rcv: 长期应收款（元）   
lt_eqy_inv: 长期股权投资（元）   
oth_eqy_inv: 其他权益工具投资（元）   
rfd_cap_guar_dpst: 存出资本保证金（元）   
oth_ncur_fin_ast: 其他非流动金融资产（元）   
amor_cos_fin_ast_ncur: 以摊余成本计量的金融资产（非流动）（元）   
fair_val_oth_inc_ncur: 以公允价值计量且其变动计入其他综合收益的金融资产（非流动）（元）   
inv_prop: 投资性房地产（元）   
fix_ast: 固定资产（元）   
const_prog: 在建工程（元）   
const_matl: 工程物资（元）   
fix_ast_dlpl: 固定资产清理（元）   
cptl_bio_ast: 生产性生物资产（元）   
oil_gas_ast: 油气资产（元）   
rig_ast: 使用权资产（元）   
intg_ast: 无形资产（元）   
trd_seat_fee: 交易席位费（元）   
dev_exp: 开发支出（元）   
gw: 商誉（元）   
lt_ppay_exp: 长期待摊费用（元）   
dfr_tax_ast: 递延所得税资产（元）   
oth_ncur_ast: 其他非流动资产（元）   
ncur_ast_oth_item: 非流动资产其他项目（元）   
ttl_ncur_ast: 非流动资产合计（元）   
oth_ast: 其他资产（元）   
ast_oth_item: 资产其他项目（元）   
ind_acct_ast: 独立账户资产（元）   
ttl_ast: 资产总计（元）   
**流动负债(负债)**   
brw_cb: 向中央银行借款（元）   
dpst_ob_fin_inst: 同业和其他金融机构存放款项（元）   
ln_fm_ob: 拆入资金（元）   
fair_val_fin_liab: 以公允价值计量且其变动计入当期损益的金融负债（元）   
sht_ln: 短期借款（元）   
adv_acct: 预收款项（元）   
contr_liab: 合同负债（元）   
trd_fin_liab: 交易性金融负债（元）   
deriv_fin_liab: 衍生金融负债（元）   
sell_repo_ast: 卖出回购金融资产款（元）   
cust_bnk_dpst: 吸收存款（元）   
dpst_cb_note_pay: 存款证及应付票据（元）   
dpst_cb: 存款证（元）   
acct_rcv_adv: 预收账款（元）   
in_prem_rcv_adv: 预收保费（元）   
fee_pay: 应付手续费及佣金（元）   
note_acct_pay: 应付票据及应付账款（元）   
stlf_pay: 应付短期融资款（元）   
note_pay: 应付票据（元）   
acct_pay: 应付账款（元）   
rin_acct_pay: 应付分保账款（元）   
emp_comp_pay: 应付职工薪酬（元）   
tax_pay: 应交税费（元）   
int_pay: 应付利息（元）   
dvd_pay: 应付股利（元）   
ph_dvd_pay: 应付保单红利（元）   
indem_pay: 应付赔付款（元）   
oth_pay: 其他应付款（元）   
ttl_oth_pay: 其他应付款合计（元）   
ph_dpst_inv: 保户储金及投资款（元）   
in_contr_rsv: 保险合同准备金（元）   
un_prem_rsv: 未到期责任准备金（元）   
clm_rin_rsv: 未决赔款准备金（元）   
li_liab_rsv: 寿险责任准备金（元）   
lt_hi_liab_rsv: 长期健康险责任准备金（元）   
cust_bnk_dpst_fin: 吸收存款及同业存放（元）   
inter_pay: 内部应付款（元）   
agy_secu_trd: 代理买卖证券款（元）   
agy_secu_uw: 代理承销证券款（元）   
sht_bnd_pay: 应付短期债券（元）   
est_cur_liab: 预计流动负债（元）   
liab_hold_for_sale: 持有待售负债（元）   
ncur_liab_one_y: 一年内到期的非流动负债（元）   
oth_cur_liab: 其他流动负债（元）   
cur_liab_oth_item: 流动负债其他项目（元）   
ttl_cur_liab: 流动负债合计（元）   
**非流动负债（负债）**   
lt_ln: 长期借款（元）   
lt_pay: 长期应付款（元）   
leas_liab: 租赁负债dfr_inc: 递延收益（元）   
dfr_tax_liab: 递延所得税负债（元）   
bnd_pay: 应付债券（元）   
bnd_pay_pbd: 其中:永续债（元）   
bnd_pay_pfd: 其中:优先股（元）   
oth_ncur_liab: 其他非流动负债（元）   
spcl_pay: 专项应付款（元）   
ncur_liab_oth_item: 非流动负债其他项目（元）   
lt_emp_comp_pay: 长期应付职工薪酬（元）   
est_liab: 预计负债（元）   
oth_liab: 其他负债（元）   
liab_oth_item: 负债其他项目（元）   
ttl_ncur_liab: 非流动负债合计（元）   
ind_acct_liab: 独立账户负债（元）   
ttl_liab: 负债合计（元）   
**所有者权益(或股东权益)**   
paid_in_cptl: 实收资本（或股本）（元）   
oth_eqy: 其他权益工具（元）   
oth_eqy_pfd: 其中:优先股（元）   
oth_eqy_pbd: 其中:永续债（元）   
oth_eqy_oth: 其中:其他权益工具（元）   
cptl_rsv: 资本公积（元）   
treas_shr: 库存股（元）   
oth_comp_inc: 其他综合收益（元）   
spcl_rsv: 专项储备（元）   
sur_rsv: 盈余公积（元）   
rsv_ord_rsk: 一般风险准备（元）   
trd_risk_rsv: 交易风险准备（元）   
ret_prof: 未分配利润（元）   
sugg_dvd: 建议分派股利（元）   
eqy_pcom_oth_item: 归属于母公司股东权益其他项目（元）   
ttl_eqy_pcom: 归属于母公司股东权益合计（元）   
min_sheqy: 少数股东权益（元）   
sheqy_oth_item: 股东权益其他项目（元）   
ttl_eqy: 股东权益合计（元）   
ttl_liab_eqy: 负债和股东权益合计  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_fundamentals_balance(symbols='SHSE.600000', rpt_type=12, data_type=None, start_date='2022-12-31', end_date='2022-12-31', fields='lt_eqy_inv', df=True)
        print(df)
        

  * Output: 
        
        symbol    pub_date    rpt_date  rpt_type  data_type   lt_eqy_inv
        0  SHSE.600000  2022-10-29  2022-09-30         9        101   2955000000
        1  SHSE.600000  2022-10-29  2022-09-30         9        102   2955000000
        2  SHSE.600000  2022-10-29  2022-09-30         9        201  31939000000
        3  SHSE.600000  2022-10-29  2022-09-30         9        202  31939000000
        

* * *

##  stk_get_fundamentals_cashflow \- 查询现金流量表数据 ¶
    
    
    stk_get_fundamentals_cashflow(*, symbols=None, rpt_type=None, data_type=None, start_date=None, end_date=None, pivot_date=None, fields=gdf.stk_get_fundamentals_cashflow, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`rpt_type` |  `int` |  报表类型  
按报告期查询可指定以下报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报   
默认None为不限 |  `None`  
`data_type` |  `int` |  数据类型  
在发布原始财务报告以后，上市公司可能会对数据进行修正。   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整   
默认None返回当期合并调整，如果没有调整返回合并原始 |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_get_fundamentals_cashflow`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
说明

symbols如果为空，则返回全市场数据，限制时间区间为6个月

**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`pub_date` |  `str` |  发布日期   
若数据类型选择合并原始(data_type=101)，则返回原始发布的发布日期   
若数据类型选择合并调整(data_type=102)，则返回调整后最新发布日期   
若数据类型选择母公司原始(data_type=201)，则返回母公司原始发布的发布日期   
若数据类型选择母公司调整(data_type=202)，则返回母公司调整后最新发布日期  
`rpt_date` |  `str` |  报告日期  
报告截止日期，财报统计的最后一天，在指定时间段[开始时间,结束时间]内的报告截止日期  
`rpt_type` |  `int` |  报表类型  
返回数据的报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报  
`data_type` |  `int` |  数据类型  
返回数据的数据类型：   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整  
`fields` |  `list[float]` |  财务字段数据  
指定返回fields字段的数值，支持的字段名请参考：   
**一、经营活动产生的现金流量**   
cash_rcv_sale: 销售商品、提供劳务收到的现金（元）   
net_incr_cust_dpst_ob: 客户存款和同业存放款项净增加额（元）   
net_incr_cust_dpst: 客户存款净增加额（元）   
net_incr_dpst_ob: 同业及其他金融机构存放款项净增加额（元）   
net_incr_brw_cb: 向中央银行借款净增加额（元）   
net_incr_ln_fm_oth: 向其他金融机构拆入资金净增加额（元）   
cash_rcv_orig_in: 收到原保险合同保费取得的现金（元）   
net_cash_rcv_rin_biz: 收到再保险业务现金净额（元）   
net_incr_ph_dpst_inv: 保户储金及投资款净增加额（元）   
net_decrdpst_cb_ob: 存放中央银行和同业款项及其他金融机构净减少额（元）   
net_decr_cb: 存放中央银行款项净减少额（元）   
net_decr_ob_fin_inst: 存放同业及其他金融机构款项净减少额（元）   
net_cert_dpst: 存款证净额（元）   
net_decr_trd_fin: 交易性金融资产净减少额（元）   
net_incr_trd_liab: 交易性金融负债净增加额（元）   
cash_rcv_int_fee: 收取利息、手续费及佣金的现金（元）   
cash_rcv_int: 其中：收取利息的现金（元）   
cash_rcv_fee: 收取手续费及佣金的现金（元）   
net_incr_lnfm_sell_repo: 拆入资金及卖出回购金融资产款净增加额（元）   
net_incr_ln_fm: 拆入资金净增加额（元）   
net_incr_sell_repo: 卖出回购金融资产款净增加额（元）保险   
net_decr_lnto_pur_resell: 拆出资金及买入返售金融资产净减少额（元）   
net_decr_ln_cptl: 拆出资金净减少额（元）   
net_dect_pur_resell: 买入返售金融资产净减少额（元）   
net_incr_repo: 回购业务资金净增加额（元）   
net_decr_repo: 回购业务资金净减少额（元）   
tax_rbt_rcv: 收到的税费返还（元）   
net_cash_rcv_trd: 收到交易性金融资产现金净额（元）   
cash_rcv_oth_oper: 收到其他与经营活动有关的现金（元）   
net_cash_agy_secu_trd: 代理买卖证券收到的现金净额（元）   
cash_rcv_pur_resell: 买入返售金融资产收到的现金（元）   
net_cash_agy_secu_uw: 代理承销证券收到的现金净额（元）   
cash_rcv_dspl_debt: 处置抵债资产收到的现金（元）   
canc_loan_rcv: 收回的已于以前年度核销的贷款（元）   
cf_in_oper: 经营活动现金流入小计（元）   
cash_pur_gds_svc: 购买商品、接受劳务支付的现金（元）   
net_incr_ln_adv_cust: 客户贷款及垫款净增加额（元）   
net_decr_brw_cb: 向中央银行借款净减少额（元）   
net_incr_dpst_cb_ob: 存放中央银行和同业款项净增加额（元）   
net_incr_cb: 存放中央银行款项净增加额（元）   
net_incr_ob_fin_inst: 存放同业及其他金融机构款项净增加额（元）   
net_decr_dpst_ob: 同业及其他机构存放款减少净额（元）   
net_decr_issu_cert_dpst: 已发行存款证净减少额（元）   
net_incr_lnto_pur_resell: 拆出资金及买入返售金融资产净增加额（元）   
net_incr_ln_to: 拆出资金净增加额（元）   
net_incr_pur_resell: 买入返售金融资产净增加额（元）   
net_decr_lnfm_sell_repo: 拆入资金及卖出回购金融资产款净减少额（元）   
net_decr_ln_fm: 拆入资金净减少额（元）   
net_decr_sell_repo: 卖出回购金融资产净减少额（元）   
net_incr_trd_fin: 交易性金融资产净增加额（元）   
net_decr_trd_liab: 交易性金融负债净减少额（元）   
cash_pay_indem_orig: 支付原保险合同赔付款项的现金（元）   
net_cash_pay_rin_biz: 支付再保险业务现金净额（元）   
cash_pay_int_fee: 支付利息、手续费及佣金的现金（元）   
cash_pay_int: 其中：支付利息的现金（元）   
cash_pay_fee: 支付手续费及佣金的现金（元）   
ph_dvd_pay: 支付保单红利的现金（元）   
net_decr_ph_dpst_inv: 保户储金及投资款净减少额（元）   
cash_pay_emp: 支付给职工以及为职工支付的现金（元）cash_pay_tax: 支付的各项税费（元）   
net_cash_pay_trd: 支付交易性金融资产现金净额（元）   
cash_pay_oth_oper: 支付其他与经营活动有关的现金（元）   
net_incr_dspl_trd_fin: 处置交易性金融资产净增加额（元）   
cash_pay_fin_leas: 购买融资租赁资产支付的现金（元）   
net_decr_agy_secu_pay: 代理买卖证券支付的现金净额（净减少额）（元）   
net_decr_dspl_trd_fin: 处置交易性金融资产的净减少额（元）   
cf_out_oper: 经营活动现金流出小计（元）   
net_cf_oper: 经营活动产生的现金流量净额（元）   
**二、投资活动产生的现金流量：**   
cash_rcv_sale_inv: 收回投资收到的现金（元）   
inv_inc_rcv: 取得投资收益收到的现金（元）   
cash_rcv_dvd_prof: 分得股利或利润所收到的现金（元）   
cash_rcv_dspl_ast: 处置固定资产、无形资产和其他长期资产收回的现金净额（元）   
cash_rcv_dspl_sub_oth: 处置子公司及其他营业单位收到的现金净额（元）   
cash_rcv_oth_inv: 收到其他与投资活动有关的现金（元）   
cf_in_inv: 投资活动现金流入小计（元）   
pur_fix_intg_ast: 购建固定资产、无形资产和其他长期资产支付的现金（元）   
cash_out_dspl_sub_oth: 处置子公司及其他营业单位流出的现金净额（元）   
cash_pay_inv: 投资支付的现金（元）   
net_incr_ph_plge_ln: 保户质押贷款净增加额（元）   
add_cash_pled_dpst: 增加质押和定期存款所支付的现金（元）   
net_incr_plge_ln: 质押贷款净增加额（元）   
net_cash_get_sub: 取得子公司及其他营业单位支付的现金净额（元）   
net_pay_pur_resell: 支付买入返售金融资产现金净额（元）   
cash_pay_oth_inv: 支付其他与投资活动有关的现金（元）   
cf_out_inv: 投资活动现金流出小计（元）net_cf_inv: 投资活动产生的现金流量净额（元）   
**三、筹资活动产生的现金流量：**   
cash_rcv_cptl: 吸收投资收到的现金（元）   
sub_rcv_ms_inv: 其中：子公司吸收少数股东投资收到的现金（元）   
brw_rcv: 取得借款收到的现金（元）   
cash_rcv_bnd_iss: 发行债券收到的现金（元）   
net_cash_rcv_sell_repo: 收到卖出回购金融资产款现金净额（元）   
cash_rcv_oth_fin: 收到其他与筹资活动有关的现金（元）   
issu_cert_dpst: 发行存款证（元）   
cf_in_fin_oth: 筹资活动现金流入其他项目（元）   
cf_in_fin: 筹资活动现金流入小计（元）   
cash_rpay_brw: 偿还债务支付的现金（元）   
cash_pay_bnd_int: 偿付债券利息支付的现金（元）   
cash_pay_dvd_int: 分配股利、利润或偿付利息支付的现金（元）   
sub_pay_dvd_prof: 其中：子公司支付给少数股东的股利、利润（元）   
cash_pay_oth_fin: 支付其他与筹资活动有关的现金（元）   
net_cash_pay_sell_repo: 支付卖出回购金融资产款现金净额（元）   
cf_out_fin: 筹资活动现金流出小计（元）   
net_cf_fin: 筹资活动产生的现金流量净额（元）   
efct_er_chg_cash: 四、汇率变动对现金及现金等价物的影响（元）   
net_incr_cash_eq: 五、现金及现金等价物净增加额（元）   
cash_cash_eq_bgn: 加：期初现金及现金等价物余额（元）   
cash_cash_eq_end: 六、期末现金及现金等价物余额（元）   
**补充资料**   
**将净利润调节为经营活动现金流量：**   
net_prof: 净利润（元）   
ast_impr: 资产减值准备（元）   
accr_prvs_ln_impa: 计提贷款减值准备（元）   
accr_prvs_oth_impa: 计提其他资产减值准备（元）   
accr_prem_rsv: 提取的保险责任准备金（元）   
accr_unearn_prem_rsv: 提取的未到期的责任准备金（元）   
defr_fix_prop: 固定资产和投资性房地产折旧（元）   
depr_oga_cba: 其中（元）元   
amor_intg_ast_lt_exp: 无形资产及长期待摊费用等摊销（元）   
amort_intg_ast: 无形资产摊销（元）   
amort_lt_exp_ppay: 长期待摊费用摊销（元）   
dspl_ast_loss: 处置固定资产、无形资产和其他长期资产的损失（元）   
fair_val_chg_loss: 固定资产报废损失（元）   
fv_chg_loss: 公允价值变动损失（元）   
dfa: 固定资产折旧（元）   
fin_exp: 财务费用（元）   
inv_loss: 投资损失（元）   
exchg_loss: 汇兑损失（元）   
dest_incr: 存款的增加（元）   
loan_decr: 贷款的减少（元）   
cash_pay_bnd_int_iss: 发行债券利息支出（元）   
dfr_tax: 递延所得税（元）   
dfr_tax_ast_decr: 其中（元）   
dfr_tax_liab_incr: 递延所得税负债增加（元）   
invt_decr: 存货的减少（元）   
decr_rcv_oper: 经营性应收项目的减少（元）   
incr_pay_oper: 经营性应付项目的增加（元）   
oth: 其他（元）   
cash_end: 现金的期末余额（元）   
cash_bgn: 减：现金的期初余额（元）   
cash_eq_end: 加（元）元   
cash_eq_bgn: 减（元）元   
cred_impr_loss: 信用减值损失（元）   
est_liab_add: 预计负债的增加（元）   
dr_cnv_cptl: 债务转为资本（元）   
cptl_bnd_expr_one_y: 一年内到期的可转换公司债券（元）   
fin_ls_fix_ast: 融资租入固定资产（元）   
amort_dfr_inc: 递延收益摊销（元）   
depr_inv_prop: 投资性房地产折旧（元）   
trd_fin_decr: 交易性金融资产的减少（元）   
im_net_cf_oper: 间接法（元）   
im_net_incr_cash_eq: 间接法（元）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_fundamentals_cashflow(symbols='SHSE.600000', rpt_type=None, data_type=101, start_date='2022-12-31', end_date='2022-12-31', fields='cash_pay_fee', df=True)
        print(df)
        

  * Output: 
        
        symbol    pub_date    rpt_date  rpt_type  data_type  cash_pay_fee
        0  SHSE.600000  2022-10-29  2021-09-30         9        102    8456000000
        1  SHSE.600000  2022-10-29  2021-09-30         9        202    8382000000
        2  SHSE.600000  2022-10-29  2022-09-30         9        101    7261000000
        3  SHSE.600000  2022-10-29  2022-09-30         9        201    8692000000
        

* * *

##  stk_get_fundamentals_income \- 查询利润表数据 ¶
    
    
    stk_get_fundamentals_income(*, symbols=None, rpt_type=None, data_type=None, start_date=None, end_date=None, pivot_date=None, fields=gdf.stk_get_fundamentals_income, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`rpt_type` |  `int` |  报表类型  
按报告期查询可指定以下报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报   
默认None为不限 |  `None`  
`data_type` |  `int` |  数据类型  
在发布原始财务报告以后，上市公司可能会对数据进行修正。   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整   
默认None返回当期合并调整，如果没有调整返回合并原始 |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_get_fundamentals_income`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
说明

symbols如果为空，则返回全市场数据，限制时间区间为6个月

**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`pub_date` |  `str` |  发布日期   
若数据类型选择合并原始(data_type=101)，则返回原始发布的发布日期   
若数据类型选择合并调整(data_type=102)，则返回调整后最新发布日期   
若数据类型选择母公司原始(data_type=201)，则返回母公司原始发布的发布日期   
若数据类型选择母公司调整(data_type=202)，则返回母公司调整后最新发布日期  
`rpt_date` |  `str` |  报告日期  
报告截止日期，财报统计的最后一天，在指定时间段[开始时间,结束时间]内的报告截止日期  
`rpt_type` |  `int` |  报表类型  
返回数据的报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报  
`data_type` |  `int` |  数据类型  
返回数据的数据类型：   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整  
`fields` |  `list[float]` |  财务字段数据  
指定返回fields字段的数值，支持的字段名请参考：   
ttl_inc_oper: 营业总收入（元）   
inc_oper: 营业收入（元）   
net_inc_int: 利息净收入（元）   
exp_int: 利息支出（元）   
net_inc_fee_comm: 手续费及佣金净收入（元）   
inc_rin_prem: 其中：分保费收入（元）   
net_inc_secu_agy: 其中证券（元）   
inc_fee_comm: 手续费及佣金收入（元）   
in_prem_earn: 已赚保费（元）   
inc_in_biz: 其中保险（元）   
rin_prem_cede: 分出保费（元）   
unear_prem_rsv: 提取未到期责任准备金（元）   
net_inc_uw: 证券承销业务净收入（元）   
net_inc_cust_ast_mgmt: 受托客户资产管理业务净收入（元）   
inc_fx: 汇兑收益（元）   
inc_other_oper: 其他业务收入（元）   
inc_oper_balance: 营业收入平衡项目（元）   
ttl_inc_oper_other: 营业总收入其他项目（元）   
ttl_cost_oper: 营业总成本（元）   
cost_oper: 营业成本（元）   
exp_oper: 营业支出（元）   
biz_tax_sur: 营业税金及附加（元）   
exp_sell: 销售费用（元）   
exp_adm: 管理费用（元）   
exp_rd: 研发费用（元）   
exp_fin: 财务费用（元）   
int_fee: 其中:利息费用（元）   
inc_int: 利息收入（元）   
exp_oper_adm: 业务及管理费（元）   
exp_rin: 减保险（元）   
rfd_prem: 退保金（元）   
comp_pay: 赔付支出（元）   
rin_clm_pay: 减保险（元）   
draw_insur_liab: 提取保险责任准备金（元）   
amor_insur_liab: 减保险（元）   
exp_ph_dvd: 保单红利支出（元）   
exp_fee_comm: 手续费及佣金支出（元）   
other_oper_cost: 其他业务成本（元）   
oper_exp_balance: 营业支出平衡项目（元）   
exp_oper_other: 营业支出其他项目（元）   
ttl_cost_oper_other: 营业总成本其他项目（元）   
**其他经营收益**   
inc_inv: 投资收益（元）   
inv_inv_jv_p: 对联营企业和合营企业的投资收益（元）   
inc_ast_dspl: 资产处置收益（元）   
ast_impr_loss: 资产减值损失(新元 （元）   
cred_impr_loss: 信用减值损失(新元 （元）   
inc_fv_chg: 公允价值变动收益（元）   
inc_other: 其他收益（元）   
oper_prof_balance: 营业利润平衡项目（元）   
oper_prof: 营业利润（元）   
inc_noper: 营业外收入（元）   
exp_noper: 营业外支出（元）   
ttl_prof_balance: 利润总额平衡项目（元）   
oper_prof_other: 营业利润其他项目（元）   
ttl_prof: 利润总额（元）   
inc_tax: 所得税费用（元）   
net_prof: 净利润（元）   
oper_net_prof: 持续经营净利润（元）   
net_prof_pcom: 归属于母公司股东的净利润（元）   
min_int_inc: 少数股东损益（元）   
end_net_prof: 终止经营净利润（元）   
net_prof_other: 净利润其他项目（元）   
eps_base: 基本每股收益（元）   
eps_dil: 稀释每股收益（元）   
other_comp_inc: 其他综合收益（元）   
other_comp_inc_pcom: 归属于母公司股东的其他综合收益（元）   
other_comp_inc_min: 归属于少数股东的其他综合收益（元）   
ttl_comp_inc: 综合收益总额（元）   
ttl_comp_inc_pcom: 归属于母公司所有者的综合收益总额（元）   
ttl_comp_inc_min: 归属于少数股东的综合收益总额（元）   
prof_pre_merge: 被合并方在合并前实现利润（元）   
net_rsv_in_contr: 提取保险合同准备金净额（元）   
net_pay_comp: 赔付支出净额（元）   
net_loss_ncur_ast: 非流动资产处置净损失（元）   
amod_fin_asst_end: 以摊余成本计量的金融资产终止确认收益（元）   
cash_flow_hedging_pl: 现金流量套期损益的有效部分（元）   
cur_trans_diff: 外币财务报表折算差额（元）   
gain_ncur_ast: 非流动资产处置利得（元）   
afs_fv_chg_pl: 可供出售金融资产公允价值变动损益（元）   
oth_eqy_inv_fv_chg: 其他权益工具投资公允价值变动（元）   
oth_debt_inv_fv_chg: 其他债权投资公允价值变动（元）   
oth_debt_inv_cred_impr: 其他债权投资信用减值准备元（元）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_fundamentals_income(symbols='SHSE.600000', rpt_type=6, data_type=None, start_date='2022-12-31', end_date='2022-12-31', fields='inc_oper', df=True)
        print(df)
        

  * Output: 
        
        symbol    pub_date    rpt_date  rpt_type  data_type      inc_oper
        0  SHSE.600000  2022-10-29  2021-09-30         9        102  143484000000
        1  SHSE.600000  2022-10-29  2021-09-30         9        202  135462000000
        2  SHSE.600000  2022-10-29  2022-09-30         9        101  143680000000
        3  SHSE.600000  2022-10-29  2022-09-30         9        201  134741000000
        

* * *

##  stk_get_finance_prime \- 查询财务主要指标数据 ¶
    
    
    stk_get_finance_prime(*, symbols=None, fields=gdf.stk_get_finance_prime, rpt_type=None, data_type=None, start_date=None, end_date=None, pivot_date=None, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`rpt_type` |  `int` |  报表类型  
按报告期查询可指定以下报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报   
默认None为不限 |  `None`  
`data_type` |  `int` |  数据类型  
在发布原始财务报告以后，上市公司可能会对数据进行修正。   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整   
默认None返回当期合并调整，如果没有调整返回合并原始 |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_get_finance_prime`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
说明

symbols如果为空，则返回全市场数据，限制时间区间为6个月

**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`pub_date` |  `str` |  发布日期   
若数据类型选择合并原始(data_type=101)，则返回原始发布的发布日期   
若数据类型选择合并调整(data_type=102)，则返回调整后最新发布日期   
若数据类型选择母公司原始(data_type=201)，则返回母公司原始发布的发布日期   
若数据类型选择母公司调整(data_type=202)，则返回母公司调整后最新发布日期  
`rpt_date` |  `str` |  报告日期  
报告截止日期，财报统计的最后一天，在指定时间段[开始时间,结束时间]内的报告截止日期  
`rpt_type` |  `int` |  报表类型  
返回数据的报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报  
`data_type` |  `int` |  数据类型  
返回数据的数据类型：   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整  
`fields` |  `list[float]` |  财务字段数据  
指定返回fields字段的数值，支持的字段名请参考：   
eps_basic: 基本每股收益（元）   
eps_dil: 稀释每股收益（元）   
eps_basic_cut: 扣除非经常性损益后的基本每股收益（元）   
eps_dil_cut: 扣除非经常性损益后的稀释每股收益（元）   
net_cf_oper_ps: 每股经营活动产生的现金流量净额（元）   
bps_pcom_ps: 归属于母公司股东的每股净资产（元）   
ttl_ast: 总资产（元）   
ttl_liab: 总负债（元）   
share_cptl: 股本（股）   
ttl_inc_oper: 营业总收入（元）   
inc_oper: 营业收入（元）   
oper_prof: 营业利润（元）   
ttl_prof: 利润总额（元）   
ttl_eqy_pcom: 归属于母公司股东的所有者权益（元）   
net_prof_pcom: 归属于母公司股东的净利润（元）   
net_prof_pcom_cut: 扣除非经常性损益后归属于母公司股东的净利润（元）   
roe: 全面摊薄净资产收益率（%）   
roe_weight_avg: 加权平均净资产收益率（%）   
roe_cut: 扣除非经常性损益后的全面摊薄净资产收益率（%）   
roe_weight_avg_cut: 扣除非经常性损益后的加权平均净资产收益率（%）   
net_cf_oper: 经营活动产生的现金流量净额（元）   
eps_yoy: 每股收益同比比例（%）   
inc_oper_yoy: 营业收入同比比例（%）   
ttl_inc_oper_yoy: 营业总收入同比比例（%）   
net_prof_pcom_yoy: 归母净利润同比比例（%）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_finance_prime(symbols='SHSE.600000', fields='eps_basic,eps_dil',rpt_type=None, data_type=None, start_date=None, end_date=None, df=True)
        print(df)
        

  * Output: 
        
        symbol    pub_date    rpt_date  rpt_type  data_type  eps_basic  eps_dil
        0  SHSE.600000  2023-10-28  2022-12-31        12        102        NaN      NaN
        1  SHSE.600000  2023-10-28  2023-09-30         9        101       0.88     0.82
        

* * *

##  stk_get_finance_deriv \- 查询财务衍生指标数据 ¶
    
    
    stk_get_finance_deriv(*, symbols=None, fields=gdf.stk_get_finance_deriv, rpt_type=None, data_type=None, start_date=None, end_date=None, pivot_date=None, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`rpt_type` |  `int` |  报表类型  
按报告期查询可指定以下报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报   
默认None为不限 |  `None`  
`data_type` |  `int` |  数据类型  
在发布原始财务报告以后，上市公司可能会对数据进行修正。   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整   
默认None返回当期合并调整，如果没有调整返回合并原始 |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `stk_get_finance_deriv`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
说明

symbols如果为空，则返回全市场数据，限制时间区间为6个月

**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`pub_date` |  `str` |  发布日期   
若数据类型选择合并原始(data_type=101)，则返回原始发布的发布日期   
若数据类型选择合并调整(data_type=102)，则返回调整后最新发布日期   
若数据类型选择母公司原始(data_type=201)，则返回母公司原始发布的发布日期   
若数据类型选择母公司调整(data_type=202)，则返回母公司调整后最新发布日期  
`rpt_date` |  `str` |  报告日期  
报告截止日期，财报统计的最后一天，在指定时间段[开始时间,结束时间]内的报告截止日期  
`rpt_type` |  `int` |  报表类型  
返回数据的报表类型：   
1 - 一季度报   
6 - 中报   
9 - 前三季报   
12 - 年报  
`data_type` |  `int` |  数据类型  
返回数据的数据类型：   
101-合并原始   
102-合并调整   
201-母公司原始   
202-母公司调整  
`fields` |  `list[float]` |  财务字段数据  
指定返回fields字段的数值，支持的字段名请参考：   
eps_basic: 每股收益EPS(基本)（元）   
eps_dil2: 每股收益EPS(稀释)（元）   
eps_dil: 每股收益EPS(期末股本摊薄)（元）   
eps_basic_cut: 每股收益EPS(扣除/基本)（元）   
eps_dil2_cut: 每股收益EPS(扣除/稀释)（元）   
eps_dil_cut: 每股收益EPS(扣除/期末股本摊薄)（元）   
bps: 每股净资产BPS（元）   
net_cf_oper_ps: 每股经营活动产生的现金流量净额（元）   
ttl_inc_oper_ps: 每股营业总收入（元）   
inc_oper_ps: 每股营业收入（元）   
ebit_ps: 每股息税前利润（元）   
cptl_rsv_ps: 每股资本公积（元）   
sur_rsv_ps: 每股盈余公积（元）   
retain_prof_ps: 每股未分配利润（元）   
retain_inc_ps: 每股留存收益（元）   
net_cf_ps: 每股现金流量净额（元）   
fcff_ps: 每股企业自由现金流量（元）   
fcfe_ps: 每股股东自由现金流量（元）   
ebitda_ps: 每股EBITDA（元）   
roe: 净资产收益率ROE(摊薄)（%）   
roe_weight: 净资产收益率ROE(加权)（%）   
roe_avg: 净资产收益率ROE(平均)（%）   
roe_cut: 净资产收益率ROE(扣除/摊薄)（%）   
roe_weight_cut: 净资产收益率ROE(扣除/加权)（%）   
ocf_toi: 经营性现金净流量/营业总收入   
eps_dil_yoy: 稀释每股收益同比增长率（%）   
net_cf_oper_ps_yoy: 每股经营活动中产生的现金流量净额同比增长率（%）   
ttl_inc_oper_yoy: 营业总收入同比增长率（%）   
inc_oper_yoy: 营业收入同比增长率（%）   
oper_prof_yoy: 营业利润同比增长率（%）   
ttl_prof_yoy: 利润总额同比增长率（%）   
net_prof_pcom_yoy: 归属母公司股东的净利润同比增长率（%）   
net_prof_pcom_cut_yoy: 归属母公司股东的净利润同比增长率(扣除非经常性损益)（%）   
net_cf_oper_yoy: 经营活动产生的现金流量净额同比增长率（%）   
roe_yoy: 净资产收益率同比增长率(摊薄)（%）   
net_asset_yoy: 净资产同比增长率（%）   
ttl_liab_yoy: 总负债同比增长率（%）   
ttl_asset_yoy: 总资产同比增长率（%）   
net_cash_flow_yoy: 现金净流量同比增长率（%）   
bps_gr_begin_year: 每股净资产相对年初增长率（%）   
ttl_asset_gr_begin_year: 资产总计相对年初增长率（%）   
ttl_eqy_pcom_gr_begin_year: 归属母公司的股东权益相对年初增长率（%）   
net_debt_eqy_ev: 净债务/股权价值（%）   
int_debt_eqy_ev: 带息债务/股权价值   
eps_bas_yoy: 基本每股收益同比增长率（%）   
ebit: EBIT(正推法)（元）   
ebitda: EBITDA(正推法)（元）   
ebit_inverse: EBIT(反推法)（元）   
ebitda_inverse: EBITDA(反推法)（元）   
nr_prof_loss: 非经常性损益（元）   
net_prof_cut: 扣除非经常性损益后的净利润（元）   
gross_prof: 毛利润（元）   
oper_net_inc: 经营活动净收益（元）   
val_chg_net_inc: 价值变动净收益（元）   
exp_rd: 研发费用（元）   
ttl_inv_cptl: 全部投入资本（元）   
work_cptl: 营运资本（元）   
net_work_cptl: 净营运资本（元）   
tg_asset: 有形资产（元）   
retain_inc: 留存收益（元）   
int_debt: 带息债务（元）   
net_debt: 净债务（元）   
curr_liab_non_int: 无息流动负债（元）   
ncur_liab_non_int: 无息非流动负债（元）   
fcff: 企业自由现金流量FCFF（元）   
fcfe: 股权自由现金流量FCFE（元）   
cur_depr_amort: 当期计提折旧与摊销（元）   
eqy_mult_dupont: 权益乘数(杜邦分析（元）   
net_prof_pcom_np: 归属母公司股东的净利润/净利润（%）   
net_prof_tp: 净利润/利润总额（%）   
ttl_prof_ebit: 利润总额/息税前利润（%）   
roe_cut_avg: 净资产收益率ROE(扣除/平均)（%）   
roe_add: 净资产收益率ROE(增发条件)（%）   
roe_ann: 净资产收益率ROE(年化)（%）   
roa: 总资产报酬率ROA（%）   
roa_ann: 总资产报酬率ROA(年化)（%）   
jroa: 总资产净利率（%）   
jroa_ann: 总资产净利率(年化)（%）   
roic: 投入资本回报率ROIC（%）   
sale_npm: 销售净利率（%）   
sale_gpm: 销售毛利率（%）   
sale_cost_rate: 销售成本率（%）   
sale_exp_rate: 销售期间费用率（%）   
net_prof_toi: 净利润/营业总收入（%）   
oper_prof_toi: 营业利润/营业总收入（%）   
ebit_toi: 息税前利润/营业总收入（%）   
ttl_cost_oper_toi: 营业总成本/营业总收入（%）   
exp_oper_toi: 营业费用/营业总收入（%）   
exp_admin_toi: 管理费用/营业总收入（%）   
exp_fin_toi: 财务费用/营业总收入（%）   
ast_impr_loss_toi: 资产减值损失/营业总收入（%）   
ebitda_toi: EBITDA/营业总收入（%）   
oper_net_inc_tp: 经营活动净收益/利润总额（%）   
val_chg_net_inc_tp: 价值变动净收益/利润总额（%）   
net_exp_noper_tp: 营业外支出净额/利润总额   
inc_tax_tp: 所得税/利润总额（%）   
net_prof_cut_np: 扣除非经常性损益的净利润/净利润（%）   
eqy_mult: 权益乘数   
curr_ast_ta: 流动资产/总资产（%）   
ncurr_ast_ta: 非流动资产/总资产（%）   
tg_ast_ta: 有形资产/总资产（%）   
ttl_eqy_pcom_tic: 归属母公司股东的权益/全部投入资本（%）   
int_debt_tic: 带息负债/全部投入资本（%）   
curr_liab_tl: 流动负债/负债合计（%）   
ncurr_liab_tl: 非流动负债/负债合计（%）   
ast_liab_rate: 资产负债率（%）   
quick_rate: 速动比率   
curr_rate: 流动比率   
cons_quick_rate: 保守速动比率   
liab_eqy_rate: 产权比率   
ttl_eqy_pcom_tl: 归属母公司股东的权益/负债合计   
ttl_eqy_pcom_debt: 归属母公司股东的权益/带息债务   
tg_ast_tl: 有形资产/负债合计   
tg_ast_int_debt: 有形资产/带息债务   
tg_ast_net_debt: 有形资产/净债务   
ebitda_tl: 息税折旧摊销前利润/负债合计   
net_cf_oper_tl: 经营活动产生的现金流量净额/负债合计   
net_cf_oper_int_debt: 经营活动产生的现金流量净额/带息债务   
net_cf_oper_curr_liab: 经营活动产生的现金流量净额/流动负债   
net_cf_oper_net_liab: 经营活动产生的现金流量净额/净债务   
ebit_int_cover: 已获利息倍数   
long_liab_work_cptl: 长期债务与营运资金比率   
ebitda_int_debt: EBITDA/带息债务（%）   
oper_cycle: 营业周期（天）   
inv_turnover_days: 存货周转天数（天）   
acct_rcv_turnover_days: 应收账款周转天数(含应收票据)（天）   
inv_turnover_rate: 存货周转率（次）   
acct_rcv_turnover_rate: 应收账款周转率(含应收票据)（次）   
curr_ast_turnover_rate: 流动资产周转率（次）   
fix_ast_turnover_rate: 固定资产周转率（次）   
ttl_ast_turnover_rate: 总资产周转率（次）   
cash_rcv_sale_oi: 销售商品提供劳务收到的现金/营业收入（%）   
net_cf_oper_oi: 经营活动产生的现金流量净额/营业收入（%）   
net_cf_oper_oni: 经营活动产生的现金流量净额/经营活动净收益   
cptl_exp_da: 资本支出/折旧摊销（%）   
cash_rate: 现金比率   
acct_pay_turnover_days: 应付账款周转天数(含应付票据)（天）   
acct_pay_turnover_rate: 应付账款周转率(含应付票据)（次）   
net_oper_cycle: 净营业周期（天）   
ttl_cost_oper_yoy: 营业总成本同比增长率（%）   
net_prof_yoy: 净利润同比增长率（%）   
net_cf_oper_np: 经营活动产生的现金流量净额/净利润（%）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_finance_deriv(symbols='SHSE.600000', fields='eps_basic,eps_dil2,eps_dil,eps_basic_cut', rpt_type=9, data_type=None, start_date=None, end_date=None, df=True)
        print(df)
        

  * Output: 
        
        symbol    pub_date    rpt_date  rpt_type  data_type  eps_basic  eps_dil2   eps_dil  eps_basic_cut
        0  SHSE.600000  2023-10-28  2022-09-30         9        102       1.31      1.20  1.378509            NaN
        1  SHSE.600000  2023-10-28  2023-09-30         9        101       0.88      0.82  0.953461           0.79
        2  SHSE.600000  2023-10-28  2023-09-30         9        102       0.88      0.82  0.953461            NaN
        

* * *

##  stk_get_daily_valuation \- 查询估值指标每日数据 ¶
    
    
    stk_get_daily_valuation(symbol, fields, *, start_date=None, end_date=None, pivot_date=None, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`fields` |  `str | list` |  指定需要返回的指标字段 |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`trade_date` |  `str` |  交易日期  
`fields` |  `list[float]` |  指标字段数据  
指定返回fields字段的数值。支持的字段名请参考：   
pe_ttm: 市盈率(TTM)（倍）   
pe_lyr: 市盈率(最新年报LYR)（倍）   
pe_mrq: 市盈率(最新报告期MRQ)（倍）   
pe_1q: 市盈率(当年一季×4)（倍）   
pe_2q: 市盈率(当年中报×2)（倍）   
pe_3q: 市盈率(当年三季×4/3)（倍）   
pe_ttm_cut: 市盈率(TTM) 扣除非经常性损益（倍）   
pe_lyr_cut: 市盈率(最新年报LYR) 扣除非经常性损益（倍）   
pe_mrq_cut: 市盈率(最新报告期MRQ) 扣除非经常性损益（倍）   
pe_1q_cut: 市盈率(当年一季×4) 扣除非经常性损益（倍）   
pe_2q_cut: 市盈率(当年中报×2) 扣除非经常性损益（倍）   
pe_3q_cut: 市盈率(当年三季×4/3) 扣除非经常性损益（倍）   
pb_lyr: 市净率(最新年报LYR)（倍）   
pb_lf: 市净率(最新公告)（倍）   
pb_mrq: 市净率(最新报告期MRQ)（倍）   
pcf_ttm_oper: 市现率(经营现金流,TTM)（倍）   
pcf_ttm_ncf: 市现率(现金净流量,TTM)（倍）   
pcf_lyr_oper: 市现率(经营现金流,最新年报LYR)（倍）   
pcf_lyr_ncf: 市现率(现金净流量,最新年报LYR)（倍）   
ps_ttm: 市销率(TTM)（倍）   
ps_lyr: 市销率(最新年报LYR)（倍）   
ps_mrq: 市销率(最新报告期MRQ)（倍）   
ps_1q: 市销率(当年一季×4)（倍）   
ps_2q: 市销率(当年中报×2)（倍）   
ps_3q: 市销率(当年三季×4/3)（倍）   
peg_lyr: 历史PEG值(当年年报增长率)（倍）   
peg_1q: 历史PEG值(当年1季 _4较上年年报增长率)（倍）  
peg_2q: 历史PEG值(当年中报_2较上年年报增长率)（倍）   
peg_3q: 历史PEG值(当年3季*4/3较上年年报增长率)（倍）   
dy_ttm: 股息率(滚动 12 月TTM)（%）   
dy_lfy: 股息率(上一财年LFY)（%）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_daily_valuation(symbol='SHSE.600000', fields='pe_ttm,pe_lyr,pe_mrq', start_date=None, end_date=None, df=True)
        print(df)
        

  * Output: 
        
        symbol  trade_date  pe_ttm  pe_lyr  pe_mrq
        0  SHSE.600000  2023-12-25  4.9913  3.7744  5.1759
        

* * *

##  stk_get_daily_mktvalue \- 查询市值指标每日数据 ¶
    
    
    stk_get_daily_mktvalue(symbol, fields, *, start_date=None, end_date=None, pivot_date=None, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`fields` |  `str | list` |  指定需要返回的指标字段 |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`trade_date` |  `str` |  交易日期  
`fields` |  `list[float]` |  指标字段数据  
指定返回fields字段的数值。支持的字段名请参考：   
tot_mv: 总市值（元）   
tot_mv_csrc: 总市值(证监会算法)（元）   
a_mv: A股流通市值(含限售股)（元）   
a_mv_ex_ltd: A股流通市值(不含限售股)（元）   
b_mv: B股流通市值(含限售股，折人民币)（元）   
b_mv_ex_ltd: B股流通市值(不含限售股，折人民币)（元）   
ev: 企业价值(含货币资金)(EV1)（元）   
ev_ex_curr: 企业价值(剔除货币资金)(EV2)（元）   
ev_ebitda: 企业倍数（倍）   
equity_value: 股权价值（元）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_daily_mktvalue(symbol='SHSE.600000', fields='tot_mv,tot_mv_csrc,a_mv', start_date=None, end_date=None, df=True)
        print(df)
        

  * Output: 
        
        symbol  trade_date        tot_mv   tot_mv_csrc          a_mv
        0  SHSE.600000  2023-12-25  1.931373e+11  1.931373e+11  1.931373e+11
        

* * *

##  stk_get_daily_basic \- 查询基础指标每日数据 ¶
    
    
    stk_get_daily_basic(symbol, fields, *, start_date=None, end_date=None, pivot_date=None, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`fields` |  `str | list` |  指定需要返回的指标字段 |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  股票代码  
`trade_date` |  `str` |  交易日期  
`fields` |  `list[float]` |  指标字段数据  
指定返回fields字段的数值。支持的字段名请参考：   
tclose: 收盘价（元）   
turnrate: 当日换手率（%）   
ttl_shr: 总股本（股）   
circ_shr: 流通股本（流通股本=无限售条件流通股本+有限售条件流通股本）（股）   
ttl_shr_unl: 无限售条件流通股本(行情软件定义的流通股)（股）   
ttl_shr_ltd: 有限售条件股本（股）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.stk_get_daily_basic(symbol='SHSE.600000', fields='tclose,turnrate,ttl_shr,circ_shr', start_date=None, end_date=None, df=True)
        print(df)
        

  * Output: 
        
        symbol  trade_date  tclose  turnrate      ttl_shr     circ_shr
        0  SHSE.600000  2023-12-25    6.58     0.044  29352176396  29352176396
        

* * *
