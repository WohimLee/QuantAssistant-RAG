---
# Converted from: strategy_structures\index.html
---

# 数据结构¶

##  Security \- 标的对象 ¶

Bases: `object`

**属性：**

名称 | 类型 | 描述  
---|---|---  
`code` |  `str` |  标的代码,格式为交易所代码.标的,如SZSE.000001/SHSE.600000/SHFE.rb2311.  
`display_name` |  `str` |  标的名字.  
`name` |  `str` |  标的名字.  
`start_date` |  `date` |  上市日期.  
`end_date` |  `date` |  退市日期.  
`type` |  `str` |  类型，包含：'stock', 'futures', 'index'.  
`parent` |  `str` |  分级基金的母基金代码,目前未使用.  
`contract_size` |  `int` |  合约乘数.  
`exchange_code` |  `str` |  交易所代码.  
`commodity_no` |  `str` |  品种代码.  
`lot_min` |  `int` |  最小下单数量.  
`lot_step` |  `int` |  下单跳数.  
`tick_size` |  `float` |  价格最小变动单位.  
`currency_no` |  `str` |  币种.  
`trade_n` |  `int` |  交易制度,0 表示 T+0，1 表示 T+1，2 表示 T+2.  
  
##  TickFeeds \- 回测Tick结构 ¶

Bases: `BarFeeds`

**属性：**

名称 | 类型 | 描述  
---|---|---  
`p.symbol` |  `str` |  标的symbol  
`p.name` |  `str` |  DataFeed名称  
`p.dataname` |  `DataFrame` |  数据DataFrame  
`p.period` |  `str` |  周期. 固定为‘tick’  
`datetime` |  `LineBuffer[float | datetime]` |  bar时间戳，使用下标取得浮点格式，或datetime()函数取得datetime.datetime。例如：data.datetime[0] -> 739202.3854166666 或者 data.datetime.datetime(0) -> datetime.datetime(2024, 11, 12, 9, 15)  
`open` |  `LineBuffer[float]` |  当日开盘价, 下标取值， 如data.open[0]  
`high` |  `LineBuffer[float]` |  当日最高价, 下标取值， 如data.high[0]  
`low` |  `LineBuffer[float]` |  当日最低价, 下标取值， 如data.low[0]  
`close` |  `LineBuffer[float]` |  最新价, 下标取值， 如data.close[0]  
`volume` |  `LineBuffer[float]` |  最新成交量, 下标取值， 如data.volume[0]  
`trade_date` |  `LineBuffer[float]` |  交易日(Unix时间戳格式), 下标取值， 如data.trade_date[0]，或转为datetime结构：datetime.datetime.utcfromtimestamp(data.trade_date[0])  
`bid_price` |  `LineBuffer[float]` |  委买价, 下标取值， 如data.bid_price[0]  
`bid_volume` |  `LineBuffer[float]` |  委买量, 下标取值， 如data.bid_volume[0]  
`ask_price` |  `LineBuffer[float]` |  委卖价, 下标取值， 如data.ask_price[0]  
`ask_volume` |  `LineBuffer[float]` |  委卖量, 下标取值， 如data.ask_volume[0]  
`total_volume` |  `LineBuffer[float]` |  当日总成交量, 下标取值， 如data.total_volume[0]  
`position` |  `LineBuffer[float]` |  持仓量, 下标取值， 如data.position[0]  
  
##  BarFeeds \- 回测Bar结构 ¶

Bases: `DataBase`

**属性：**

名称 | 类型 | 描述  
---|---|---  
`p.symbol` |  `str` |  标的symbol  
`p.name` |  `str` |  DataFeed名称  
`p.dataname` |  `DataFrame` |  数据DataFrame  
`p.period` |  `str` |  周期  
`datetime` |  `LineBuffer[float | datetime]` |  bar时间戳，使用下标取得浮点格式，或datetime()函数取得datetime.datetime。例如：data.datetime[0] -> 739202.3854166666 或者 data.datetime.datetime(0) -> datetime.datetime(2024, 11, 12, 9, 15)  
`open` |  `LineBuffer[float]` |  开盘价, 下标取值， 如data.open[0]  
`high` |  `LineBuffer[float]` |  最高价, 下标取值， 如data.high[0]  
`low` |  `LineBuffer[float]` |  最低价, 下标取值， 如data.low[0]  
`close` |  `LineBuffer[float]` |  收盘价, 下标取值， 如data.close[0]  
`volume` |  `LineBuffer[int]` |  成交量, 下标取值， 如data.volume[0]  
`trade_date` |  `LineBuffer[float]` |  交易日(Unix时间戳格式), 下标取值， 如data.trade_date[0]，或转为datetime结构：datetime.datetime.utcfromtimestamp(data.trade_date[0])  
`position` |  `LineBuffer[float]` |  持仓量, 下标取值， 如data.position[0]  
`last_bar` |  `LineBuffer[float]` |  是否为交易日最后的bar. 0-否，1-是, 下标取值， 如data.last_bar[0]  
  
示例: data = ait0.quote.BarFeeds( # 指定股票代码. name='SZSE.000001', # 开始日期. fromdate=datetime.datetime(2021, 6, 1, 0, 0, 0), # 结束日期. todate=datetime.datetime(2022, 6, 1, 16, 0, 0), )
    
    
    # 添加数据流到Cerebro实例中.
    cerebro.adddata(data)
    

##  LiveTickFeeds \- 仿真/实盘Tick结构 ¶

Bases: `LiveBarFeeds`

**属性：**

名称 | 类型 | 描述  
---|---|---  
`p.symbol` |  `str` |  标的symbol  
`p.name` |  `str` |  DataFeed名称  
`p.dataname` |  `DataFrame` |  数据DataFrame  
`p.period` |  `str` |  周期. 固定为‘tick’  
`datetime` |  `LineBuffer[float | datetime]` |  bar时间戳，使用下标取得浮点格式，或datetime()函数取得datetime.datetime。例如：data.datetime[0] -> 739202.3854166666 或者 data.datetime.datetime(0) -> datetime.datetime(2024, 11, 12, 9, 15)  
`open` |  `LineBuffer[float]` |  当日开盘价, 下标取值， 如data.open[0]  
`high` |  `LineBuffer[float]` |  当日最高价, 下标取值， 如data.high[0]  
`low` |  `LineBuffer[float]` |  当日最低价, 下标取值， 如data.low[0]  
`close` |  `LineBuffer[float]` |  最新价, 下标取值， 如data.close[0]  
`volume` |  `LineBuffer[float]` |  最新成交量, 下标取值， 如data.volume[0]  
`trade_date` |  `LineBuffer[float]` |  交易日(Unix时间戳格式), 下标取值， 如data.trade_date[0]，或转为datetime结构：datetime.datetime.utcfromtimestamp(data.trade_date[0])  
`bid_price` |  `LineBuffer[float]` |  委买价, 下标取值， 如data.bid_price[0]  
`bid_volume` |  `LineBuffer[float]` |  委买量, 下标取值， 如data.bid_volume[0]  
`ask_price` |  `LineBuffer[float]` |  委卖价, 下标取值， 如data.ask_price[0]  
`ask_volume` |  `LineBuffer[float]` |  委卖量, 下标取值， 如data.ask_volume[0]  
`total_volume` |  `LineBuffer[float]` |  当日总成交量, 下标取值， 如data.total_volume[0]  
`position` |  `LineBuffer[float]` |  持仓量, 下标取值， 如data.position[0]  
  
##  LiveBarFeeds \- 仿真/实盘Bar结构 ¶

Bases: `DataBase`

**属性：**

名称 | 类型 | 描述  
---|---|---  
`p.symbol` |  `str` |  标的symbol  
`p.name` |  `str` |  DataFeed名称  
`p.dataname` |  `DataFrame` |  数据DataFrame  
`p.period` |  `str` |  周期  
`datetime` |  `LineBuffer[float | datetime]` |  bar时间戳，使用下标取得浮点格式，或datetime()函数取得datetime.datetime。例如：data.datetime[0] -> 739202.3854166666 或者 data.datetime.datetime(0) -> datetime.datetime(2024, 11, 12, 9, 15)  
`open` |  `LineBuffer[float]` |  开盘价, 下标取值， 如data.open[0]  
`high` |  `LineBuffer[float]` |  最高价, 下标取值， 如data.high[0]  
`low` |  `LineBuffer[float]` |  最低价, 下标取值， 如data.low[0]  
`close` |  `LineBuffer[float]` |  收盘价, 下标取值， 如data.close[0]  
`volume` |  `LineBuffer[int]` |  成交量, 下标取值， 如data.volume[0]  
`trade_date` |  `LineBuffer[float]` |  交易日(Unix时间戳格式), 下标取值， 如data.trade_date[0]，或转为datetime结构：datetime.datetime.utcfromtimestamp(data.trade_date[0])  
`position` |  `LineBuffer[float]` |  持仓量, 下标取值， 如data.position[0]  
`last_bar` |  `LineBuffer[float]` |  是否为交易日最后的bar. 0-否，1-是, 下标取值， 如data.last_bar[0]  
  
##  AIOrder \- 委托单据对象 ¶

Bases: `Order`

说明

`AIOrder` 继承自 `backtrader.Order` . [查看更多信息...](https://www.backtrader.com/docu/order/)

**属性：**

名称 | 类型 | 描述  
---|---|---  
`local_order_id` |  `str` |  本地委托编号  
`order_id` |  `str` |  委托单号  
`account_no` |  `str` |  交易账号  
`ordtype` |  `int` |  委托类型 0--Buy, 1--Sell  
`ordmode` |  `int` |  开平方式 1 -- 开仓, 2 -- 平仓, 3 -- 平今, 4 -- 平昨  
`status` |  `int` |  委托状态 0--Created, 1--Submitted, 2--Accepted, 3--Partial, 4--Completed, 5--Canceled, 6--Expired, 7--Margin, 8--Rejected  
`exectype` |  `int` |  Market, Close, Limit, Stop, StopLimit, StopTrail, StopTrailLimit, Historical  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds` |  标的对应的datafeed  
`size` |  `int` |  委托数量  
`price` |  `float` |  委托价格  
`owner` |  `UserStrategy` |  自定义策略对象, 继承自AIStrategy  
`order_style` |  `int` |  委托风格委。 1-按指定量委托，2-按指定价值委托，3-按指定比例委托，4-调仓到目标持仓量，5-调仓到目标持仓额，6-调仓到目标持仓比例  
  
##  AITrade \- 成交对象 ¶

Bases: `Trade`

说明

`AITrade` 继承自 `backtrader.Trade` . [查看更多信息...](https://www.backtrader.com/docu/trade/)

**属性：**

名称 | 类型 | 描述  
---|---|---  
`ref` |  |  唯一的交易标识符  
`status` |  `int` |  交易的状态，可以是 0 -- Created、1 -- Open、 2 -- Closed  
`tradeid` |  `int` |  在创建订单时传递的分组交易ID，默认值为0  
`size` |  `int` |  当前成交的量  
`price` |  `float` |  当前成交价格  
`value` |  `float` |  当前成交额  
`commission` |  `float` |  当前累计的手续费  
`pnl` |  `float` |  当前成交盈亏  
`pnlcomm` |  `float` |  当前成交净盈亏（扣除佣金后的盈亏）  
`isclosed` |  `bool` |  是否关闭（将交易量设为0）  
`isopen` |  `bool` |  是否打开  
`justopened` |  `bool` |  是否刚开始成交  
`baropen` |  `int` |  开始成交时的bar索引  
`dtopen` |  `float` |  交易打开时的浮点编码日期时间。使用方法 open_datetime 获取 Python 的 datetime.datetime 或使用平台提供的 num2date 方法  
`barclose` |  `int` |  成交关闭时的bar索引  
`dtclose` |  `float` |  交易关闭时的浮点编码日期时间。使用方法 close_datetime 获取 Python 的 datetime.datetime 或使用平台提供的 num2date 方法  
`barlen` |  `int` |  交易打开的bar数量  
`historyon` |  `bool` |  是否记录交易历史  
`history` |  `list` |  保存每次“更新”事件的列表，包含更新后的状态和使用的参数。历史记录的第一条是开仓事件，历史记录的最后一条是平仓事件  
  
##  AIPosition \- 持仓对象 ¶

Bases: `Position`

说明

`AIPosition` 继承自 `backtrader.Position`. [查看更多信息...](https://www.backtrader.com/docu/position/)

**属性：**

名称 | 类型 | 描述  
---|---|---  
`pos_type` |  `str` |  持仓方向  
`symbol` |  `str` |  标的代码  
`size` |  `int` |  持仓数量  
`price` |  `float` |  持仓均价  
`adjbase` |  `float` |  结算价格  
`upopened` |  `int` |  开仓量  
`upclosed` |  `int` |  平仓量  
`updt` |  `datetime` |  更新时间  
`yd_size` |  `int` |  昨仓数量  
`cur_size` |  `int` |  今仓数量  
`cur_frozen_size` |  `int` |  今日冻结数量  
`yd_frozen_size` |  `int` |  昨日冻结数量  
`market_value` |  `float` |  市值  
`margin_value` |  `float` |  占用保证金（期货）  
`floating_pl` |  `float` |  浮动盈亏  
`currency` |  `str` |  币种  
`sec_type` |  `str` |  商品类型  
`contract_size` |  `int` |  合约乘数  
`quote_price` |  `float` |  行情价格  
`first_date` |  `str` |  首次建仓交易日  
`last_date` |  `str` |  最后建仓交易日  
`first_date_mills` |  `int` |  首次建仓时间戳(毫秒)  
`last_date_mills` |  `int` |  最后建仓时间戳(毫秒)  
`open_price` |  `float` |  开仓均价  
`open_cost` |  `float` |  开仓成本  
`hold_cost` |  `float` |  持仓成本  
`trade_n` |  `int` |  T+N 交易  
  
###  entry_date \- 获得当前持仓的第一个建仓位置的时间 ¶
    
    
    entry_date()
    

**返回：**

类型 | 描述  
---|---  
`datetime` |  返回日期datetime  
  
###  last_entry_date \- 获得当前持仓的最后一个建仓位置的时间 ¶
    
    
    last_entry_date()
    

**返回：**

类型 | 描述  
---|---  
`datetime` |  返回datetime
