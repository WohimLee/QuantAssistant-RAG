---
# Converted from: strategy_quick_start\index.html
---

# 快速开始¶

## 策略示例¶

  * 示例 1.1 
        
        import ait0
        ...
        

  * 示例 1.2 
        
        import ait0
        ...
        

## 提取数据代码示例¶

  * 示例 2.1 
        
        import ait0
        ...
        

  * 示例 2.2 
        
        import ait0
        ...
        

## 选择回测模式/实时模式运行示例¶

  * 示例 3.1 
        
        import ait0
        ...
        

  * 示例 3.2 
        
        import ait0
        ...
        

