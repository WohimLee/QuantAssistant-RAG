---
# Converted from: data_api_future\index.html
---

# 期货数据函数¶

##  fut_get_continuous_contracts \- 获取连续合约对应的真实合约 ¶
    
    
    fut_get_continuous_contracts(symbol, start_date=None, end_date=None, is_handle=False)
    

说明

暂支持国内期货交易所品种（[国内交易所：`CFFEX`, `SHFE`, `DCE`, `CZCE`, `INE`](../strategy_variables/)）

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  单个合约. |  _必需_  
`start_date` |  `str | date` |  str或datetime.date,开始时间,大于等于from_date的数据 |  `None`  
`end_date` |  `str | date` |  str或datetime.date,结束时间,小于等于to_date的数据 |  `None`  
`is_handle` |  `bool` |  False-返回数据不做处理，True-返回数据，发现是该真实合约最后交易日，返回下一个交易日的真实品种 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  合约  
`trade_date` |  `str` |  交易日  
`csymbol` |  `str` |  主合约  
`cname` |  `str` |  主合约名字  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        df = ait0.fut_get_continuous_contracts(symbol='SHFE.NImain',start_date="2023-11-11", end_date="2023-12-11")
        print(df)
        

  * Output: 
        
        symbol  trade_date      csymbol cname
        0   SHFE.ni2312  2023-11-13  SHFE.nimain  None
        1   SHFE.ni2312  2023-11-14  SHFE.nimain  None
        2   SHFE.ni2312  2023-11-15  SHFE.nimain  None
        3   SHFE.ni2312  2023-11-16  SHFE.nimain  None
        4   SHFE.ni2312  2023-11-17  SHFE.nimain  None
        5   SHFE.ni2312  2023-11-20  SHFE.nimain  None
        6   SHFE.ni2312  2023-11-21  SHFE.nimain  None
        7   SHFE.ni2312  2023-11-22  SHFE.nimain  None
        8   SHFE.ni2312  2023-11-23  SHFE.nimain  None
        9   SHFE.ni2312  2023-11-24  SHFE.nimain  None
        10  SHFE.ni2401  2023-11-27  SHFE.nimain  None
        11  SHFE.ni2401  2023-11-28  SHFE.nimain  None
        12  SHFE.ni2401  2023-11-29  SHFE.nimain  None
        13  SHFE.ni2401  2023-11-30  SHFE.nimain  None
        14  SHFE.ni2401  2023-12-01  SHFE.nimain  None
        15  SHFE.ni2401  2023-12-04  SHFE.nimain  None
        16  SHFE.ni2401  2023-12-05  SHFE.nimain  None
        17  SHFE.ni2401  2023-12-06  SHFE.nimain  None
        18  SHFE.ni2401  2023-12-07  SHFE.nimain  None
        19  SHFE.ni2401  2023-12-08  SHFE.nimain  None
        20  SHFE.ni2401  2023-12-11  SHFE.nimain  None
        

##  fut_get_contract_info \- 查询期货标准品种信息 ¶
    
    
    fut_get_contract_info(product_codes, *, fields=gdf.fut_get_contract_info, df=False)
    

说明

暂支持国内期货交易所品种（[国内交易所：`CFFEX`, `SHFE`, `DCE`, `CZCE`, `INE`](../strategy_variables/)）

| --- | --- | --- | | 交易所披露的期货标准品种 | 每个交易日 | 5:00pm |

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`product_codes` |  `str | list` |  品种代码  
交易品种代码，如：IF，AL   
多个代码可用，采用 str 格式时，多个标的代码必须用英文逗号分割，如：'IF, AL'   
采用 list 格式时，多个标的代码示例：['IF', 'AL'] |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `fut_get_contract_info`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`product_name` |  `str` |  交易品种  
交易品种名称，如：沪深 300 指数，铝  
`product_code` |  `str` |  交易代码  
交易品种代码，如：IF，AL  
`underlying_symbol` |  `str` |  合约标的  
如：SHSE.000300，AL  
`multiplier` |  `int` |  合约乘数  
如：200，5  
`trade_unit` |  `str` |  交易单位  
如：每点人民币 200 元，5 吨/手  
`price_unit` |  `str` |  报价单位  
如：指数点，元（人民币）/吨  
`price_tick` |  `str` |  价格最小变动单位  
如：0.2 点，5 元/吨  
`delivery_month` |  `str` |  合约月份  
如："当月、下月及随后两个季月"，"1 ～ 12 月"  
`trade_time` |  `str` |  交易时间  
如："9:30-11:30，13:00-15:00"， "上午 9:00－11:30 ，下午 1:30－3:00 和交易所规定的其他交易时间"  
`price_range` |  `str` |  涨跌停板幅度  
每日价格最大波动限制，如："上一个交易日结算价的 ±10%"， "上一交易日结算价 ±3%"  
`minimum_margin` |  `str` |  最低交易保证金  
交易所公布的最低保证金比例，如："合约价值的 8%"，"合约价值的 5%"  
`last_trade_date` |  `str` |  最后交易日  
如："合约到期月份的第三个星期五，遇国家法定假日顺延"， "合约月份的 15 日（遇国家法定节假日顺延，春节月份等最后交易日交易所可另行调整并通知）"  
`delivery_date` |  `str` |  交割日  
如："同最后交易日"，"最后交易日后连续三个工作日"  
`delivery_method` |  `str` |  交割方式  
如："现金交割"，"实物交割"  
`exchange_name` |  `str` |  交易所名称  
上市交易所名称，如："中国金融期货交易所"，"上海期货交易所"  
`exchange` |  `str` |  交易所代码  
交易品种名称，如："沪深 300 指数"，"铝"  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fut_get_contract_info(product_codes='IF')
        print(df)
        

  * Output: 
        
        [{'product_name': '沪深300股指期货',
          'product_code': 'IF',
          'underlying_symbol': 'SHSE.000300',
          'multiplier': 300,
          'trade_unit': '每点300元',
          'price_unit': '指数点',
          'price_tick': '0.2点',
          'delivery_month': '当月、下月及随后两个季月',
          'trade_time': '上午9:30-11:30,下午13:00-15:00',
          'price_range': '上一个交易日结算价的±10%',
          'minimum_margin': '合约价值的8%',
          'last_trade_date': '合约到期月份的第三个周五,遇国家法定假日顺延',
          'delivery_date': '同最后交易日',
          'delivery_method': '现金交割',
          'exchange_name': '中国金融期货交易所',
          'exchange': 'CFFEX'}]
        

* * *

##  fut_get_transaction_ranking \- 查询期货每日成交持仓排名 ¶
    
    
    fut_get_transaction_ranking(symbol, *, trade_date=None, indicator=None, fields=gdf.fut_get_transaction_ranking, df=False)
    

说明

暂支持国内期货交易所品种（[国内交易所：`CFFEX`, `SHFE`, `DCE`, `CZCE`, `INE`](../strategy_variables/)）

| --- | --- | --- | | 1990-01-01 ~ Now | 每个交易日 | 10:00pm |

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`trade_date` |  `str | datetime | timestamp` |  交易日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`indicator` |  `str` |  排名指标  
用于排名的依据，可选：  
'volume'-成交量排名（默认""表示成交量排名）  
'long'-持买单量排名  
'short'-持卖单量排名 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `fut_get_transaction_ranking`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  期货合约代码  
查询排名的期货合约代码  
`trade_date` |  `str` |  交易日期，%Y-%m-%d 格式，默认None表示当前时间  
`member_name` |  `str` |  期货公司会员简称  
`indicator_number` |  `int` |  排名指标数值  
单位：手。数值视乎指定的排名指标 indicator，分别为：   
成交量（indicator='volume'时）   
持买单量（indicator='long'时）   
持卖单量（indicator='short'时）  
`indicator_change` |  `int` |  排名指标比上交易日增减  
单位：手  
`ranking` |  `int` |  排名名次  
指标具体排名  
`ranking_change` |  `float` |  排名名次比上交易日增减  
单位：名次  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fut_get_transaction_ranking(symbol='SHFE.ag2212', trade_date="2023-10-10", indicator='volume', df=True)
        print(df)
        

  * Output: 
        
        symbol  trade_date indicator member_name  indicator_number  indicator_change  ranking ranking_change delivery_date delivery_method exchange_name exchange
        0  SHFE.ag2212  2022-12-01    volume        金瑞期货              1056              -168       20           None          None            None          None     None
        

* * *

##  fut_get_warehouse_receipt \- 查询期货仓单数据 ¶
    
    
    fut_get_warehouse_receipt(product_code, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.fut_get_warehouse_receipt, df=True)
    

说明

暂支持国内期货交易所品种（[国内交易所：`CFFEX`, `SHFE`, `DCE`, `CZCE`, `INE`](../strategy_variables/)）

| --- | --- | --- | | 1990-01-01 ~ Now | 每个交易日 | 5:00pm |

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`product_code` |  `str | list` |  品种代码，可输入多个   
采用 str 格式时，多个标的代码必须用英文逗号分割，如：'AL,CJ'   
采用 list 格式时，多个品种代码示例：['AL', 'CJ'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `fut_get_warehouse_receipt`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `str` |  交易日期  
`exchange` |  `str` |  期货交易所代码   
期货品种对应交易所代码，如：CFFEX，SHFE  
`exchange_name` |  `str` |  期货交易所名称   
上市交易所名称，如：中国金融期货交易所，上海期货交易所  
`product_code` |  `str` |  交易代码   
交易品种代码，如：IF，AL  
`product_name` |  `str` |  交易品种   
交易品种名称，如：沪深 300 指数，铝  
`on_warrant` |  `int` |  注册仓单数量  
`warrant_unit` |  `str` |  仓单单位  
`warehouse` |  `str` |  仓库名称  
`future_inventory` |  `int` |  期货库存  
`future_inventory_change` |  `int` |  期货库存增减  
`future_capacity` |  `int` |  可用库容量  
`future_capacity_change` |  `int` |  可用库容量增减  
`inventory_subtotal` |  `int` |  库存小计  
`inventory_subtotal_change` |  `int` |  库存小计增减  
`effective_forecast` |  `int` |  有效预报   
仅支持郑商所品种  
`premium` |  `int` |  升贴水  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fut_get_warehouse_receipt(product_code='AL', start_date="2023-12-20", end_date="2023-12-20")
        print(df)
        

  * Output: 
        
        trade_date exchange exchange_name product_code product_name  on_warrant  ... warehouse_capacity warehouse_capacity_change  inventory_subtotal  inventory_subtotal_change  effective_forecast  premium
        0   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        1   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        2   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        3   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        4   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        5   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        6   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        7   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        8   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        9   2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        10  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        11  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        12  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        13  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        14  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        15  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        16  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        17  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        18  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        19  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        20  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        21  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        22  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        23  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        24  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        25  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        26  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        27  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        28  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        29  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        30  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        31  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        32  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        33  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        34  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        35  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        36  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        37  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        38  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        39  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        40  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        41  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        42  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        43  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        44  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        45  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        46  2023-12-20     SHFE       上海期货交易所           AL            铝       39063  ...                  0                         0                   0                          0                   0        0
        
        [47 rows x 16 columns]
        

* * *
