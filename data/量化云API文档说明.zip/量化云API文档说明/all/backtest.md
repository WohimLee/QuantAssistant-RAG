---
# Converted from: backtest\index.html
---

# 回测¶

## 回测框架运行¶

## 基于权重的回测¶

## 基于股指期货的回测¶

## 基于资金百分比的信号回测¶
