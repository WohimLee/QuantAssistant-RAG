---
# Converted from: data_api_general\index.html
---

# 通用数据函数¶

##  get_symbol_infos \- 查询标的基本信息 ¶
    
    
    get_symbol_infos(sec_type1, *, sec_type2=None, exchanges=None, symbols=None, df=False, fields=gdf.get_symbol_infos)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
股票，基金，债券，期货，期权，指数 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`sec_type1` |  `int` |  指定一种证券大类，只能输入一个. 证券大类sec_type1清单：   
1010: 股票， 1020: 基金， 1030: 债券 ， 1040: 期货， 1050: 期权， 1060: 指数. |  _必需_  
`sec_type2` |  `int` |  指定一种证券细类，只能输入一个. 默认None表示不区分细类，即证券大类下所有细类. 证券细类见sec_type2清单：   
股票   
101001: A 股，101002: B 股，101003: 存托凭证   
基金   
102001:ETF，102002:LOF，102005:FOF   
债券   
103001:可转债，103008:回购   
期货   
104001:股指期货，104003:商品期货，104006:国债期货   
期权   
105001:股票期权，105002:指数期权，105003:商品期权   
指数   
106001:股票指数，106002:基金指数，106003:债券指数，106004:期货指数 |  `None`  
`exchanges` |  `str | list[str]` |  交易所代码，可输入多个。   
采用 str 格式时，多个交易所代码必须用英文逗号分割，如：'SHSE,SZSE'   
采用 list 格式时，多个交易所代码，示例：['SHSE', 'SZSE']   
交易所代码清单：  
SHSE:上海证券交易所，SZSE:深圳证券交易所，CFFEX:中金所，SHFE:上期所，DCE:大商所， CZCE:郑商所，INE:能源中心   
默认None表示所有交易所。 |  `None`  
`symbols` |  `str | list[str]` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`fields` |  `str | list[str]` |  返回字段，默认返回全部 |  `get_symbol_infos`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`sec_type1` |  `int` |  证券品种大类  
1010: 股票，1020: 基金， 1030: 债券，1040: 期货， 1050: 期权，1060: 指数  
`sec_type2` |  `int` |  证券品种细类   
股票  
101001:A 股，101002:B 股，101003:存托凭证   
基金  
102001:ETF，102002:LOF，102005:FOF   
债券  
103001:可转债，103003:国债，103006:企业债，103008:回购   
期货  
104001:股指期货，104003:商品期货，104006:国债期货   
期权  
105001:股票期权，105002:指数期权，105003:商品期权   
指数  
106001:股票指数，106002:基金指数，106003:债券指数，106004:期货指数  
`board` |  `int` |  板块   
A股   
10100101:主板 A 股 10100102:创业板 10100103:科创版 10100104:北交所股票   
ETF  
10200101:股票 ETF 10200102:债券 ETF 10200103:商品 ETF 10200104:跨境 ETF 10200105:货币 ETF   
可转债  
10300101:普通可转债 10300102:可交换债券 10300103:可分离式债券 10300104:定向可转债  
`exchange` |  `str` |  交易所代码   
SHSE:上海证券交易所， SZSE:深圳证券交易所， CFFEX:中金所， SHFE:上期所， DCE:大商所， CZCE:郑商所， INE:上海国际能源交易中心  
`sec_id` |  `str` |  交易所标的代码  
股票,基金,债券,指数的证券代码; 期货,期权的合约代码  
`sec_name` |  `str` |  交易所标的名称  
股票,基金,债券,指数的证券名称; 期货,期权的合约名称  
`sec_abbr` |  `str` |  交易所标的简称  
拼音或英文简称  
`price_tick` |  `float` |  最小变动单位  
交易标的价格最小变动单位  
`trade_n` |  `int` |  交易制度  
0 表示 T+0，1 表示 T+1，2 表示 T+2  
`listed_date` |  `datetime` |  上市日期  
证券/指数的上市日、衍生品合约的挂牌日  
`delisted_date` |  `datetime` |  退市日期  
股票/基金的退市日，期货/期权的到期日(最后交易日)，可转债的赎回登记日  
`underlying_symbol` |  `str` |  标的资产  
期货/期权的合约标的物 symbol，可转债的正股标的 symbol  
`option_type` |  `str` |  行权方式  
期权行权方式，仅期权适用，E:欧式，A:美式  
`option_margin_ratio1` |  `float` |  期权保证金计算系数 1  
计算期权单位保证金的第1个系数，仅期权适用  
`option_margin_ratio2` |  `float` |  期权保证金计算系数 2  
计算期权单位保证金的第2个系数，仅期权适用  
`call_or_put` |  `str` |  合约类型  
期权合约类型，仅期权适用，C:Call(认购或看涨)， P:Put(认沽或看跌)  
`conversion_start_date` |  `datetime` |  可转债开始转股日期  
可转债初始转股价的执行日期，仅可转债适用  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        data = ait0.gm.get_symbol_infos(sec_type1=1010, symbols='SHSE.600008,SZSE.000002')
        print(data)
        

  * Output: 
        
        [{'symbol': 'SHSE.600008',
          'sec_type1': 1010,
          'sec_type2': 101001,
          'board': 10100101,
          'exchange': 'SHSE',
          'sec_id': '600008',
          'sec_name': '首创环保',
          'sec_abbr': 'SCHB',
          'price_tick': 0.01,
          'trade_n': 1,
          'listed_date': '2000-04-27',
          'delisted_date': '2038-01-01',
          'underlying_symbol': None,
          'option_type': None,
          'option_margin_ratio1': 0,
          'option_margin_ratio2': 0,
          'call_or_put': None,
          'conversion_start_date': None},
         {'symbol': 'SZSE.000002',
          'sec_type1': 1010,
          'sec_type2': 101001,
          'board': 10100101,
          'exchange': 'SZSE',
          'sec_id': '000002',
          'sec_name': '万科A',
          'sec_abbr': 'WKA',
          'price_tick': 0.01,
          'trade_n': 1,
          'listed_date': '1991-01-29',
          'delisted_date': '2038-01-01',
          'underlying_symbol': None,
          'option_type': None,
          'option_margin_ratio1': 0,
          'option_margin_ratio2': 0,
          'call_or_put': None,
          'conversion_start_date': None}]
        

* * *

##  get_symbols \- 查询指定交易日多标的交易信息 ¶
    
    
    get_symbols(sec_type1, *, sec_type2=None, exchanges=None, symbols=None, skip_suspended=True, skip_st=True, skip_delist=False, trade_date=None, df=False, fields=gdf.get_symbols)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 9:20am / 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`sec_type1` |  `int` |  指定一种证券大类，只能输入一个。   
证券大类sec_type1清单：   
1010: 股票， 1020: 基金， 1030: 债券 ， 1040: 期货， 1050: 期权， 1060: 指数. |  _必需_  
`sec_type2` |  `int` |  指定一种证券细类，只能输入一个。 默认None表示不区分细类，即证券大类下所有细类。   
证券细类见sec_type2清单：   
股票   
101001: A 股，101002: B 股，101003: 存托凭证   
基金   
102001:ETF，102002:LOF，102005:FOF   
债券   
103001:可转债，103008:回购   
期货   
104001:股指期货，104003:商品期货，104006:国债期货   
期权   
105001:股票期权，105002:指数期权，105003:商品期权   
指数   
106001:股票指数，106002:基金指数，106003:债券指数，106004:期货指数 |  `None`  
`exchanges` |  `str | list` |  交易所代码，可输入多个。   
采用 str 格式时，多个交易所代码必须用英文逗号分割，如：'SHSE,SZSE'   
采用 list 格式时，多个交易所代码，示例：['SHSE', 'SZSE']   
交易所代码清单：  
SHSE:上海证券交易所，SZSE:深圳证券交易所，CFFEX:中金所，SHFE:上期所，DCE:大商所， CZCE:郑商所，INE:能源中心   
默认None表示所有交易所。 |  `None`  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002']  
默认None表示所有标的. |  `None`  
`skip_suspended` |  `bool` |  是否跳过全天停牌，默认True跳过 |  `True`  
`skip_st` |  `bool` |  是否跳过包含 ST 的股票：ST, _ST, SST, S_ ST, 默认True跳过 |  `True`  
`trade_date` |  `str | datetime | timestamp` |  交易日期，%Y-%m-%d 格式，默认None取最新截面(包含退市标的) |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `get_symbols`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `datetime` |  交易日期  
`symbol` |  `str` |  标的代码  
`sec_type1` |  `int` |  证券品种大类  
1010: 股票，1020: 基金， 1030: 债券，1040: 期货， 1050: 期权，1060: 指数  
`sec_type2` |  `int` |  证券品种细类   
股票  
101001:A 股，101002:B 股，101003:存托凭证   
基金  
102001:ETF，102002:LOF，102005:FOF   
债券  
103001:可转债，103003:国债，103006:企业债，103008:回购   
期货  
104001:股指期货，104003:商品期货，104006:国债期货   
期权  
105001:股票期权，105002:指数期权，105003:商品期权   
指数  
106001:股票指数，106002:基金指数，106003:债券指数，106004:期货指数  
`board` |  `int` |  板块   
A股   
10100101:主板 A 股 10100102:创业板 10100103:科创版 10100104:北交所股票   
ETF  
10200101:股票 ETF 10200102:债券 ETF 10200103:商品 ETF 10200104:跨境 ETF 10200105:货币 ETF   
可转债  
10300101:普通可转债 10300102:可交换债券 10300103:可分离式债券 10300104:定向可转债  
`exchange` |  `str` |  交易所代码   
SHSE:上海证券交易所， SZSE:深圳证券交易所， CFFEX:中金所， SHFE:上期所， DCE:大商所， CZCE:郑商所， INE:上海国际能源交易中心  
`sec_id` |  `str` |  交易所标的代码  
股票,基金,债券,指数的证券代码; 期货,期权的合约代码  
`sec_name` |  `str` |  交易所标的名称  
股票,基金,债券,指数的证券名称; 期货,期权的合约名称  
`sec_abbr` |  `str` |  交易所标的简称  
拼音或英文简称  
`price_tick` |  `float` |  最小变动单位  
交易标的价格最小变动单位  
`trade_n` |  `int` |  交易制度  
0 表示 T+0，1 表示 T+1，2 表示 T+2  
`listed_date` |  `datetime` |  上市日期  
证券/指数的上市日、衍生品合约的挂牌日  
`delisted_date` |  `datetime` |  退市日期  
股票/基金的退市日，期货/期权的到期日(最后交易日)，可转债的赎回登记日  
`underlying_symbol` |  `str` |  标的资产  
期货/期权的合约标的物 symbol，可转债的正股标的 symbol  
`option_type` |  `str` |  行权方式  
期权行权方式，仅期权适用，E:欧式，A:美式  
`option_margin_ratio1` |  `float` |  期权保证金计算系数 1  
计算期权单位保证金的第1个系数，仅期权适用  
`option_margin_ratio2` |  `float` |  期权保证金计算系数 2  
计算期权单位保证金的第2个系数，仅期权适用  
`call_or_put` |  `str` |  合约类型  
期权合约类型，仅期权适用，C:Call(认购或看涨)， P:Put(认沽或看跌)  
`conversion_start_date` |  `datetime` |  可转债开始转股日期  
可转债初始转股价的执行日期，仅可转债适用  
`is_adjusted` |  `bool` |  合约调整  
是否调整合约，True:是，False:否（调整后会产生新的新的合约名称、新的行权价格、新的合约乘数）  
`is_suspended` |  `bool` |  是否停牌  
是否停牌，True:是，False:否  
`is_st` |  `bool` |  是否 ST  
是否 ST，True: 是 ST 类（含ST, _ST, SST, S_ ST）, False: 否  
`position` |  `int` |  持仓量  
当日累计持仓量，当日盘后更新  
`settle_price` |  `float` |  结算价  
当日结算价，当日盘后更新  
`pre_settle` |  `float` |  昨结价  
昨日结算价  
`pre_close` |  `float` |  昨收价  
昨日收盘价  
`upper_limit` |  `float` |  涨停价  
当日涨停价（首次公开发行上市的股票上市前 5 日无涨跌停价，返回0）  
`lower_limit` |  `float` |  跌停价  
当日跌停价（首次公开发行上市的股票上市前 5 日无涨跌停价，返回0）  
`turn_rate` |  `float` |  换手率  
当日换手率(%)，当日盘后更新  
`adj_factor` |  `float` |  复权因子  
当日累计后复权因子  
`margin_ratio` |  `float` |  保证金比例  
期货最新保证金比例（交易所标准的最新期货保证金）  
`conversion_price` |  `float` |  转股价  
可转债最新转股价（转股价变动后的最新转股价）  
`exercise_price` |  `float` |  行权价  
期权最新行权价（期权合约调整后的最新行权价）  
`multiplier` |  `int` |  合约乘数  
期货和期权合约最新合约乘数（期权合约调整后的最新合约乘数）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.get_symbols(sec_type1=1010, symbols='SHSE.600008,SZSE.000002', trade_date='2022-01-13')
        print(df)
        

  * Output: 
        
        trade_date       symbol  sec_type1  sec_type2     board exchange  sec_id sec_name sec_abbr  ...  pre_close  upper_limit lower_limit turn_rate  adj_factor margin_ratio  conversion_price  exercise_price multiplier
        0  2022-01-13  SHSE.600008       1010     101001  10100101     SHSE  600008     首创环保     SCHB  ...       3.47         3.82        3.12    1.1215    6.556426            1                 0               0          1
        1  2022-01-13  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      22.05        24.26       19.85    0.9394  173.089740            1                 0               0          1
        
        [2 rows x 34 columns]
        

* * *

##  get_history_symbol \- 查询指定标的多日交易信息 ¶
    
    
    get_history_symbol(symbol, *, start_date=None, end_date=None, df=False, fields=gdf.get_history_symbol)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 9:20am / 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list[str]` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`fields` |  `str | list[str]` |  返回字段，默认返回全部 |  `get_history_symbol`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`trade_date` |  `datetime` |  交易日期  
`symbol` |  `str` |  标的代码  
`sec_type1` |  `int` |  证券品种大类  
1010: 股票，1020: 基金， 1030: 债券，1040: 期货， 1050: 期权，1060: 指数  
`sec_type2` |  `int` |  证券品种细类   
股票  
101001:A 股，101002:B 股，101003:存托凭证   
基金  
102001:ETF，102002:LOF，102005:FOF   
债券  
103001:可转债，103003:国债，103006:企业债，103008:回购   
期货  
104001:股指期货，104003:商品期货，104006:国债期货   
期权  
105001:股票期权，105002:指数期权，105003:商品期权   
指数  
106001:股票指数，106002:基金指数，106003:债券指数，106004:期货指数  
`board` |  `int` |  板块   
A股   
10100101:主板 A 股 10100102:创业板 10100103:科创版 10100104:北交所股票   
ETF  
10200101:股票 ETF 10200102:债券 ETF 10200103:商品 ETF 10200104:跨境 ETF 10200105:货币 ETF   
可转债  
10300101:普通可转债 10300102:可交换债券 10300103:可分离式债券 10300104:定向可转债  
`exchange` |  `str` |  交易所代码   
SHSE:上海证券交易所， SZSE:深圳证券交易所， CFFEX:中金所， SHFE:上期所， DCE:大商所， CZCE:郑商所， INE:上海国际能源交易中心  
`sec_id` |  `str` |  交易所标的代码  
股票,基金,债券,指数的证券代码; 期货,期权的合约代码  
`sec_name` |  `str` |  交易所标的名称  
股票,基金,债券,指数的证券名称; 期货,期权的合约名称  
`sec_abbr` |  `str` |  交易所标的简称  
拼音或英文简称  
`price_tick` |  `float` |  最小变动单位  
交易标的价格最小变动单位  
`trade_n` |  `int` |  交易制度  
0 表示 T+0，1 表示 T+1，2 表示 T+2  
`listed_date` |  `datetime` |  上市日期  
证券/指数的上市日、衍生品合约的挂牌日  
`delisted_date` |  `datetime` |  退市日期  
股票/基金的退市日，期货/期权的到期日(最后交易日)，可转债的赎回登记日  
`underlying_symbol` |  `str` |  标的资产  
期货/期权的合约标的物 symbol，可转债的正股标的 symbol  
`option_type` |  `str` |  行权方式  
期权行权方式，仅期权适用，E:欧式，A:美式  
`option_margin_ratio1` |  `float` |  期权保证金计算系数 1  
计算期权单位保证金的第1个系数，仅期权适用  
`option_margin_ratio2` |  `float` |  期权保证金计算系数 2  
计算期权单位保证金的第2个系数，仅期权适用  
`call_or_put` |  `str` |  合约类型  
期权合约类型，仅期权适用，C:Call(认购或看涨)， P:Put(认沽或看跌)  
`conversion_start_date` |  `datetime` |  可转债开始转股日期  
可转债初始转股价的执行日期，仅可转债适用  
`is_adjusted` |  `bool` |  合约调整  
是否调整合约，True:是，False:否（调整后会产生新的新的合约名称、新的行权价格、新的合约乘数）  
`is_suspended` |  `bool` |  是否停牌  
是否停牌，True:是，False:否  
`is_st` |  `bool` |  是否 ST  
是否 ST，True: 是 ST 类（含ST, _ST, SST, S_ ST）, False: 否  
`position` |  `int` |  持仓量  
当日累计持仓量，当日盘后更新  
`settle_price` |  `float` |  结算价  
当日结算价，当日盘后更新  
`pre_settle` |  `float` |  昨结价  
昨日结算价  
`pre_close` |  `float` |  昨收价  
昨日收盘价  
`upper_limit` |  `float` |  涨停价  
当日涨停价（首次公开发行上市的股票上市前 5 日无涨跌停价，返回0）  
`lower_limit` |  `float` |  跌停价  
当日跌停价（首次公开发行上市的股票上市前 5 日无涨跌停价，返回0）  
`turn_rate` |  `float` |  换手率  
当日换手率(%)，当日盘后更新  
`adj_factor` |  `float` |  复权因子  
当日累计后复权因子  
`margin_ratio` |  `float` |  保证金比例  
期货最新保证金比例（交易所标准的最新期货保证金）  
`conversion_price` |  `float` |  转股价  
可转债最新转股价（转股价变动后的最新转股价）  
`exercise_price` |  `float` |  行权价  
期权最新行权价（期权合约调整后的最新行权价）  
`multiplier` |  `int` |  合约乘数  
期货和期权合约最新合约乘数（期权合约调整后的最新合约乘数）  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.get_history_symbol(symbol='SZSE.000002', start_date='2022-09-01', end_date='2022-09-30', df=True)
        print(df)
        

  * Output: 
        
        trade_date       symbol  sec_type1  sec_type2     board exchange  sec_id sec_name sec_abbr  ...  pre_close  upper_limit lower_limit turn_rate adj_factor margin_ratio  conversion_price  exercise_price multiplier
        0   2022-09-01  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      16.63        18.29       14.97    1.3464   183.8178            1                 0               0          1
        1   2022-09-02  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      16.84        18.52       15.16    0.7171   183.8178            1                 0               0          1
        2   2022-09-05  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      16.80        18.48       15.12    0.9611   183.8178            1                 0               0          1
        3   2022-09-06  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.17        18.89       15.45    1.4801   183.8178            1                 0               0          1
        4   2022-09-07  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.85        19.64       16.07    0.9091   183.8178            1                 0               0          1
        5   2022-09-08  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.52        19.27       15.77    0.7444   183.8178            1                 0               0          1
        6   2022-09-09  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.58        19.34       15.82    1.4531   183.8178            1                 0               0          1
        7   2022-09-13  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      18.15        19.97       16.34    1.0911   183.8178            1                 0               0          1
        8   2022-09-14  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      18.18        20.00       16.36    0.7648   183.8178            1                 0               0          1
        9   2022-09-15  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.91        19.70       16.12    1.5527   183.8178            1                 0               0          1
        10  2022-09-16  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      18.50        20.35       16.65    1.1783   183.8178            1                 0               0          1
        11  2022-09-19  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      18.00        19.80       16.20    0.8524   183.8178            1                 0               0          1
        12  2022-09-20  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      18.18        20.00       16.36    1.0366   183.8178            1                 0               0          1
        13  2022-09-21  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.56        19.32       15.80    0.7559   183.8178            1                 0               0          1
        14  2022-09-22  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.56        19.32       15.80    0.6255   183.8178            1                 0               0          1
        15  2022-09-23  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.49        19.24       15.74    0.6510   183.8178            1                 0               0          1
        16  2022-09-26  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.51        19.26       15.76    0.7214   183.8178            1                 0               0          1
        17  2022-09-27  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.44        19.18       15.70    0.6007   183.8178            1                 0               0          1
        18  2022-09-28  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.60        19.36       15.84    0.6183   183.8178            1                 0               0          1
        19  2022-09-29  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.46        19.21       15.71    0.5527   183.8178            1                 0               0          1
        20  2022-09-30  SZSE.000002       1010     101001  10100101     SZSE  000002      万科A      WKA  ...      17.15        18.87       15.44    0.8859   183.8178            1                 0               0          1
        
        [21 rows x 34 columns]
        

* * *

##  get_trading_dates_by_year \- 查询年度交易日历 ¶
    
    
    get_trading_dates_by_year(exchange, start_year, end_year=None, fields=gdf.get_trading_dates_by_year, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Future | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`exchange` |  `str` |  交易所代码  
只能填写一个交易所代码 交易所代码清单: SHSE:上海证券交易所，SZSE:深圳证券交易所，CFFEX:中金所，SHFE:上期所，DCE:大商所，CZCE:郑商所，INE:上海国际能源交易中心 |  _必需_  
`start_year` |  `int` |  开始年份  
查询交易日历开始年份（含），yyyy 格式 |  _必需_  
`end_year` |  `int` |  结束年份  
查询交易日历结束年份（含），yyyy 格式 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `get_trading_dates_by_year`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`date` |  `str` |  自然日期  
查询年份的自然日日期  
`trade_date` |  `str` |  交易日期  
查询年份的交易日日期，如果所在自然日不是交易日，交易日期为空字符串''  
`next_trade_date` |  `str` |  下一交易日  
交易日对应的下一交易日  
`pre_trade_date` |  `str` |  上一交易日  
交易日对应的上一交易日  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.get_trading_dates_by_year(exchange='SHSE', start_year=2023, end_year=2023, df=True)
        print(df)
        

  * Output: 
        
        date        trade_date      next_trade_date pre_trade_date
        0    2023-01-01        None      2023-01-03     2022-12-30
        1    2023-01-02        None      2023-01-03     2022-12-30
        2    2023-01-03  2023-01-03      2023-01-04     2022-12-30
        3    2023-01-04  2023-01-04      2023-01-05     2023-01-03
        4    2023-01-05  2023-01-05      2023-01-06     2023-01-04
        ..          ...         ...             ...            ...
        360  2023-12-27  2023-12-27      2023-12-28     2023-12-26
        361  2023-12-28  2023-12-28      2023-12-29     2023-12-27
        362  2023-12-29  2023-12-29      2024-01-02     2023-12-28
        363  2023-12-30        None      2024-01-02     2023-12-29
        364  2023-12-31        None      2024-01-02     2023-12-29
        
        [365 rows x 4 columns]
        

* * *

##  get_trading_session \- 查询交易时段 ¶
    
    
    get_trading_session(symbols, df=False, fields=gdf.get_trading_session)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
股票，基金，债券，期货，期权，指数 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  输入标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用list格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `get_trading_session`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`exchange` |  `str` |  交易所代码  
SHSE:上海证券交易所，SZSE:深圳证券交易所，CFFEX:中金所， SHFE:上期所，DCE:大商所，CZCE:郑商所，INE:上海国际能源交易中心  
`time_trading` |  `list[dict]` |  连续竞价时段  
HH:MM 格式，按时间顺序排列，如品种存在夜盘，夜盘时段排最前。   
如[{'start': '09:30'，'end': '11:30'}， {'start': '13:00'， 'end': '14:57'}]  
`pre_trade_date` |  `list[dict]` |  集合竞价时段  
HH:MM 格式，按时间顺序排列，如品种存在夜盘，夜盘时段排最前。   
如[{’start': '09:15'， 'end': '09:25'}，{'start': '14:57'， 'end': '15:00'}]  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        data = ait0.gm.get_trading_session(symbols='SHFE.au2306', df=False)
        print(data)
        

  * Output: 
        
        [{'symbol': 'SHFE.au2306',
          'exchange': 'SHFE',
          'time_trading': '[{"end": "2:30", "start": "21:00"}, {"end": "10:15", "start": "9:00"}, {"end": "11:30", "start": "10:30"}, {"end": "15:00", "start": "13:30"}]',
          'time_callaution': '[{"end": "20:59", "start": "20:55"}, {"end": "8:59", "start": "8:55"}]'}]
        

* * *

##  get_contract_expire_rest_days \- 查询合约到期剩余天数 ¶
    
    
    get_contract_expire_rest_days(symbols, *, start_date=None, end_date=None, pivot_date=None, trade_flag=False, df=False, fields=gdf.get_contract_expire_rest_days)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
基金，债券，期货，期权 | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  输入标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用list格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`trade_flag` |  `bool` |  交易日  
是否需要按交易日计算，默认False按自然日计算，则返回到期剩余自然日天数; 设置为True按交易日计算，则返回到期剩余交易日天数 |  `False`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `get_contract_expire_rest_days`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段. |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`date` |  `str` |  日期  
[开始日期,结束日期]内的自然日期  
`symbol` |  `str` |  合约代码  
`days_to_expire` |  `int` |  到期剩余自然天数  
合约在指定交易时间至合约到期日的剩余自然天数，trade_flag=False  
`trade_days_to_expire` |  `int` |  到期剩余交易日数  
合约在指定交易时间至合约到期日的剩余交易日数，trade_flag=True  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.get_contract_expire_rest_days(symbols='CFFEX.IM2212', start_date='2022-12-12', end_date='2022-12-16', trade_flag=True, df=True)
        print(df)
        

Output: 
        
        date        symbol  trade_days_to_expire
        0  2022-12-12  CFFEX.IM2212                     4
        1  2022-12-13  CFFEX.IM2212                     3
        2  2022-12-14  CFFEX.IM2212                     2
        3  2022-12-15  CFFEX.IM2212                     1
        4  2022-12-16  CFFEX.IM2212                     0
        

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.get_contract_expire_rest_days(symbols='CFFEX.IM2212', start_date='2022-12-12', end_date='2022-12-16', trade_flag=False, df=True)
        print(df)
        

Output: 
        
        date        symbol  days_to_expire
        0  2022-12-12  CFFEX.IM2212               4
        1  2022-12-13  CFFEX.IM2212               3
        2  2022-12-14  CFFEX.IM2212               2
        3  2022-12-15  CFFEX.IM2212               1
        4  2022-12-16  CFFEX.IM2212               0
        

* * *

##  get_history_instruments \- 查询交易标的历史信息数据 ¶
    
    
    get_history_instruments(*, symbols=None, fields=gdf.get_history_instruments, start_date=None, end_date=None, df=False)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 9:20am / 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list` |  标的代码，可输入多个. 采用 str 格式时，多个标的代码必须用英文逗号分割，如：'SHSE.600008,SZSE.000002'采用 list 格式时，多个标的代码示例：['SHSE.600008', 'SZSE.000002'] |  `None`  
`start_date` |  `str | datetime | timestamp` |  开始时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束时间日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`fields` |  `str | list` |  返回字段，默认返回全部 |  `get_history_instruments`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  标的代码  
`trade_date` |  `datetime` |  交易日期  
`sec_level` |  `int` |  1-正常,   
2-ST 股票   
3-*ST 股票   
4-股份转让   
5-处于退市整理期的证券   
6-上市开放基金 LOF   
7-交易型开放式指数基金(ETF)   
8-非交易型开放式基金(暂不交易,仅揭示基金净值及开放申购赎回业务)   
9-仅提供净值揭示服务的开放式基金   
10-仅在协议交易平台挂牌交易的证券   
11-仅在固定收益平台挂牌交易的证券   
12-风险警示产品   
13-退市整理产品   
99-其它  
`is_suspended` |  `bool` |  是否停牌  
是否停牌，True:是，False:否  
`multiplier` |  `int` |  合约乘数  
期货和期权合约最新合约乘数（期权合约调整后的最新合约乘数）  
`margin_ratio` |  `float` |  保证金比例  
期货最新保证金比例（交易所标准的最新期货保证金）  
`settle_price` |  `float` |  结算价  
当日结算价，当日盘后更新  
`pre_settle` |  `float` |  昨结价  
昨日结算价  
`position` |  `int` |  持仓量  
当日累计持仓量，当日盘后更新  
`pre_close` |  `float` |  昨收价  
昨日收盘价  
`upper_limit` |  `float` |  涨停价  
当日涨停价（首次公开发行上市的股票上市前 5 日无涨跌停价，返回0）  
`lower_limit` |  `float` |  跌停价  
当日跌停价（首次公开发行上市的股票上市前 5 日无涨跌停价，返回0）  
`adj_factor` |  `float` |  复权因子  
当日累计后复权因子，仅限基金和股票  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.get_history_instruments(symbols='SZSE.000001,SZSE.000002', start_date='2017-09-19', end_date='2017-09-19', df=True)
        print(df)
        

  * Output: 
        
        symbol  trade_date sec_abbr  sec_id  sec_level sec_name  sec_type  sec_type_ext  board  ... multiplier  margin_ratio settle_price pre_settle position pre_close  upper_limit lower_limit  adj_factor
        0  SZSE.000001  2017-09-19     PAYH  000001          1     平安银行         1             0      1  ...          1             1            0          0        0     11.25        12.38       10.13    144.8209
        1  SZSE.000002  2017-09-19      WKA  000002          1      万科A         1             0      1  ...          1             1            0          0        0     28.04        30.84       25.24    146.0342
        
        [2 rows x 35 columns]
        

* * *
