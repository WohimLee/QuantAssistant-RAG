---
# Converted from: operation\quick_start\index.html
---

# 操作指引

## 一 安装终端¶

### 1.1 python安装¶

推荐使用python3.9.9版本,可在官网下载对应的安装包,[windows版本下载](https://www.python.org/ftp/python/3.9.9/python-3.9.9-amd64.exe)

### 1.2 IDE安装¶

#### 1.2.1 采用vscode安装IDE¶

可在官网下载对应的安装包[windows版本下载](https://code.visualstudio.com/docs/?dv=win)。安装完成后,需要安装python插件,如下图所示；

![Alt text](../image-5.png)

#### 1.2.2 采用pycharm社区版安装IDE¶

可在官网下载对应的安装包[windows版本下载](https://www.jetbrains.com/pycharm/download/?section=windows)

### 1.3 sdk安装¶

#### 1.3.1 创建python虚拟环境¶

这里sdk安装以windows环境下举例: 使用命令python.exe -m venv E:\work\script\ait0-venv,创建虚拟环境

![Alt text](../image-6.png)

使用命令cd /d E:\work\script\ait0-venv,进入虚拟环境的目录 使用命令Scripts\activate,启用虚拟环境

#### 1.3.2 安装投研平台的sdk¶

使用命令 pip install ait0 --no-cache-dir --index-url=https://sdk.1quant.com.cn/simple/ --upgrade,安装sdk

![Alt text](../image-7.png)

验证sdk

![Alt text](../image-8.png)

## 二 快速入门¶

### 2.1 策略框架¶

#### 2.1.1 策略框架¶

基于开源框架backtrader，在backtrader基础上进行扩展,支持回测模式和仿真模式: 1.回测模式支持全市场高精度模拟撮合(支持A股/港股/国内外期货市场),支持tick级别及k线级别的回测 2.仿真模式支持对接实时行情(tick及k线)、对接券商柜台/期货CTP接口

扩展后的架构如下图: 

![Alt text](../image-52.png)

主要扩展类说明:

AICerebro: 自定义引擎,主要是针对各种参数的处理,支持本地及服务器运行模式,支持回测及仿真.

AIStrategy: 自定义策略基类,主要是改写了下单接口及获取持仓的接口,编写策略是需要从这个类继承.

BackTestBroker: 自定义回测broker,主要是对接高精度模拟撮合引擎模块(采用Golang实现).

BarFeeds: 自定义历史k线数据类,从行情系统中获取历史k线数据.

TickFeeds: 自定义历史tick数据类,从行情系统中获取历史tick数据.

LiveStore: 自定义仿真store,主要对接实时行情模块(采用Golang实现)和仿真交易模块(采用Golang实现).

LiveBroker: 自定义仿真broker,主要处理仿真交易的单据/资金/持仓的数据.

LiveBarFeeds: 自定义实时k线数据类,从行情系统中获取实时k线数据.

LiveTickFeeds: 自定义实时tick数据类,从行情系统中获取实时tick数据.

#### 2.1.2 策略结构¶

策略框架主要包括【对象初始化调用】、【订单通知回调】、【成交回调通知】和【策略主要逻辑】以及【运行策略的参数配置】几个部分组成。其中【对象初始化调用】、【订单通知回调】和【成交回调通知】在策略模板中已经提供，非特殊情况不需要做修改。

![Alt text](../image-10.png)

研究员根据各自策略逻辑的不同主要完善【策略逻辑】即【def next(self, datas)]函数中的内容。运行策略的参数配置在主程序cerebro.run函数中，其中包括回测标的【symbols】、回测区间【fromdate-todate】、投资组合token【portfolio】、策略编号【strategy_code】、k线周期【period】、初始资金【initial_cash】、复权方式【adjust】、回测模式【run_mode】、数据滑框最大预取量【prefectch】。

![Alt text](../image-11.png)

### 2.2克隆示例策略¶

在【广场】栏中研究员可以查看和克隆平台示例策略，点击【查看】进入策略详情介绍界面。该界面有各个策略的详情介绍以及策略源代码。点击【克隆策略】后研究员可以在自己的策略研究栏看到从平台上克隆的策略。

![Alt text](../image-12.png) ![Alt text](../image-13.png) ![Alt text](../image-14.png)

策略在平台克隆完成后，可以点击【修改策略】在模板策略基础上对策略进行修改，或者点击【修改参数】修改策略的参数，最后点击【运行回测】，在平台实现策略快速回测。

### 2.3 新建量化策略¶

第一步，点击最上面一栏【策略研究】，进入策略研究界面； 第二步，点击【新增】，弹出新增策略弹框，编辑【策略名称】后，点击【在线编辑策略】，注意这里除了可以直接编写平台提供的策略模板外，还可以通过【导入】，将把本地调试好的策略脚本上传至平台使用； 第三步，这里有一个双均线模板策略，研究员可以自行在此对策略进行研究、开发和优化，完成策略后点击【保存】。

![Alt text](../image-15.png) ![Alt text](../image-16.png)

### 2.4 新建投资组合¶

第一步，点击最上面一栏中的【交易】按钮，进入【交易】界面；

第二步，点击左侧栏【投资组合管理】，进入创建投资组合界面；

第三步，点击【新增】按钮，跳出新增投资组合弹框；

第四步，设置投资组合名称；

第五步，设置完毕后点击【确定】；

![Alt text](../image-18.png)

第六步，创建交易账号

![Alt text](../image-56.png)

第七步，在【投资组合管理】界面中找到刚才创建的投资组合，此处以“双均线策略”为例，点击【组合配置】，跳出投资组合配置弹框。

![Alt text](../image-58.png)

第八步，点击设置栏中的【修改】

![Alt text](../image-61.png)!

第九步，配置交易账户标签页，在交易账户设置栏中找到上面创建的交易账户；

![Alt text](../image-62.png)

第十步，点击【策略设置】，进入策略配置界面，选择之前创建的策略；

![Alt text](../image-54.png)

第十一步，点击【添加】，完成策略添加后会显示参数设置栏，这里可以调整策略的参数；

![Alt text](../image-55.png)

第十二步，点击保存后，在投资组合管理界面就能看到刚才配置的【双均线策略】【test1】，在策略研究回测阶段，可以暂不不需要把策略跟投资组合绑定，但是策略在仿真交易时，需要绑定后才能交易。

![Alt text](../image-26.png) ![Alt text](../image-25.png)

### 2.5 本地回测策略¶

第一步，在【策略研究】界面中的【策略列表】栏中点击【新增】，跳出新增策略弹框后，输入新建策略名称，点击【下载模板并保存】。

![Alt text](../image-27.png) ![Alt text](../image-28.png) ![Alt text](../image-29.png)

第二步，在【交易】界面中的【投资组合管理】页面中选择运行该策略的投资组合（投资组合创建见2.3.2），点击对应投资组合【操作】栏中的【发送密钥】，平台绑定的手机号码会收到密钥短信。

![Alt text](../image-30.png)

第三步，找到本地保存策略的路径，用本地python IDE打开策略脚本，下拉至最下方，找到策略脚本中的【portfolio='', # 設置投資組合的Token,必填,根據需要修改.】，并将刚才收到短信提示密钥添加至策略脚本中。（仅策略在本地运行时，portfolio必填）

![Alt text](../image-31.png)

第四步，本地运行配置好的脚本，策略回测运行完成后，可以在【策略研究】界面下的【策略列表】中查看绩效。

### 2.6 云端回测策略¶

#### 2.6.1 单策略回测¶

第一步，在【策略研究】页面中的【策略列表】界面找到需要回测的策略，点击对应【操作】栏中的【运行回测】会弹出【回测参数设置】弹框，在这里配置回测参数，包括【周期设置】、【回测范围】、【滑点比率】、【回测标的】等，配置完成后点击【确定】。

![Alt text](../image-33.png)

第二步，点击完【确定】，系统会自动转至【回测任务管理】界面，点击回测策略对应栏中的【详情】可以看到回测任务详情，包括【回测实例完成率】和【实际总耗时】等。

![Alt text](../image-34.png) ![Alt text](../image-35.png) ![Alt text](../image-36.png)

#### 2.6.2 参数组优化¶

平台目前支持将策略使用到的多个参数按指定的起止范围，步长形成参数组，再对所有的参数组合进行批量回测。

![Alt text](../image-37.png) ![Alt text](../image-38.png)

### 2.7 查看回测绩效¶

在【策略研究】界面中的【策略列表】中找到需要查看的策略名称，点击对应栏中【历史回测次数】进入该策略的【回测绩效】界面。点击进入后可以看到对应策略所有的回测绩效表现以及每次的回测详情。点击对应回测批次【操作】栏中的【详情】按钮，跳转至该次回测的详情界面。

![Alt text](../image-39.png) ![Alt text](../image-40.png) ![Alt text](../image-41.png) ![Alt text](../image-42.png)

## 三 策略交易¶

前面经过回测研究好的策略，在绑定交易账号后，即可直接在平台无缝衔接仿真交易或实盘交易。

### 3.1 新增交易账号¶

第一步，点击最上面一栏中的【交易】按钮，进入【交易】界面； 第二步，点击左侧栏【交易账号管理】，进入交易账号创建界面；

![Alt text](../image-43.png)

第三步，点击【新增】按钮，跳出【添加交易账号】弹框；

![Alt text](../image-44.png)

第四步，选择账号类型，有两种选择【仿真】账号或【实盘】账号，这里创建的是仿真账户； 第五步，选择账户交易的市场，包括【国内期货】、【国内证券】、【港美股】、【国际期货】； 第六步，选择类型【创建账户】或【绑定已有账户】； 第七步，选择交易服务商【Sim-quant】->【Simulaition】

![Alt text](../image-45.png)

第八步，设置初始资金； 第九步，写该交易账号相关备注，此处方框为选填； 第十步，设置完毕，点击确定；

![Alt text](../image-46.png)

第十一步，设置完毕后，可以在【交易账号管理】界面看到新增的交易账号，在这里可以对账号进行【查看】【删除】和【出入金】操作。完成新增交易账号环节后，进入下一步。

![Alt text](../image-47.png)

### 3.2 策略仿真交易¶

在完成前面2.3，2.4新建策略和新建投资组合后，并将策略绑定投资组合，再在【交易】界面的【投资组合看板】栏中找到需要仿真交易的投资组合名称，在【运行计划】中点击【查看更多】，跳出策略运行状态栏，点击【启动】，策略即可开始进行仿真交易。

![Alt text](../image-48.png) ![Alt text](../image-49.png)

策略的实盘交易流程与仿真交易一致，只是实盘中策略绑定的账号为实盘账号（仿真绑定的为仿真账号）。

### 3.3 查看仿真绩效¶

在【绩效分析】界面中选择【投资组合报表】栏可以看到所有运行仿真策略的绩效表现。在步骤1中的下拉框中找到相应的投资组合，点击进入即可看到该投资组合的仿真绩效。该界面展示了仿真策略的【绩效汇总】表格、【收益分析】曲线、【资产明细】、【成交明细】等内容。

![Alt text](../image-50.png)

### 3.4 查看信号图表¶

平台在【交易】界面中的【信号列表】页面中提供了所有策略仿真的信号列表和信号图表。在步骤1处的下拉框中选择对应的策略，点击即可跳转至相应的信号列表展示页面，方便研究员对比策略信号。

![Alt text](../image-51.png)

## 四 数据接口¶

在【策略研究】界面中选择【API文档】可以查看相关接口文档。

![Alt text](../image-57.png)

### 4.1 行情数据接口¶

#### 4.1.1 通用数据函数¶

filter_stock - 过滤股票

fut_get_continuous_contracts - 获取连续合约对应的真实合约

get_security_info - 获取股票/基金/指数的信息

get_fundamentals - 查询基础数据

get_group_detail - 按照分组查询股票列表 

get_index_constituents - 查询指数成分股信息

get_industry - 查询股票所属行业

get_next_trading_date - 获取指定日期的下一个交易日

get_previous_trading_date - 获取指定日期的上一个交易日

get_trade_days - 获取指定日期范围内的所有交易日

get_current_trade_date - 根据标的查询当前交易日

stk_get_fundamentals_balance_batch - 批量查询资产负债表数据

get_margin_rate - 获取合约对应的保证金率

get_commission - 获取合约对应的手续费

get_currency_rate - 获取汇率

get_exchange_info - 获取交易所列表

get_china_future_main - 获取国内期货主力合约信息

get_foreign_future_main - 获取国际期货主力合约信息

#### 4.1.2 行情数据函数¶

get_limit_price - 获取历史的涨跌停/昨收/结算价,仅支持国内股票和期货,结算价针对期货

query_current_day_bar - 查询指定合约的当前交易日的日线数据

history_data_stream - 获取全市场的历史行情数 

query_running_bar - 获取指定周期的最新k线数据

### 4.2 基本面数据¶

#### 4.2.1 通用数据¶

get_symbol_infos - 查询标的基本信息

get_symbols - 查询指定交易日多标的交易信息

get_history_symbol - 查询指定标的多日交易信息 

get_trading_dates_by_year - 查询年度交易日历

get_trading_session - 查询交易时段

get_contract_expire_rest_days - 查询合约到期剩余天数

get_history_instruments - 查询交易标的历史信息数据

#### 4.2.2 股票数据¶

##### 4.2.2.1 基本信息¶

stk_get_index_constituents - 查询指数成分股

stk_get_industry_constituents - 查询行业成分股

stk_get_symbol_industry - 查询股票的所属行业

stk_get_sector_category - 查询板块分类

stk_get_sector_constituents - 查询板块成分股

kpl_get_sector_category - 查询KPL板块列表

kpl_get_sector_constituents - 查询KPL板块成分股 

stk_get_symbol_sector - 查询股票的所属板块

stk_get_dividend - 查询股票分红送股信息

stk_get_ration - 查询股票配股信息

stk_get_adj_factor - 查询股票的复权因子

stock_basic - 股票基础信息

eod - 每日行情数据

block_trade - 大宗交易

forecast - 获取业绩预告数据

daily_basic - 获取每日指标

stk_surv - 机构调研表

broker_recommend - 券商每月荐股

##### 4.2.2.2 股东股本信息¶

stk_get_shareholder_num - 查询股东户数

stk_get_top_shareholder - 查询十大股东

stk_get_share_change - 查询股本变动

##### 4.2.2.3 沪深港股通¶

hk_hold - 沪深港股通持股明细

hsgt_top10 - 沪深股通十大成交股

##### 4.2.2.4 融资融券¶

margin - 融资融券交易汇总

margin_detail - 融资融券交易明细

margin_target - 融资融券标的

##### 4.2.2.5 资金流向¶

moneyflow - 个股资金流向

moneyflow_hsgt - 沪深港通资金流向

##### 4.2.2.6 质押回购¶

pledge_stat - 获取股票质押统计数据

repurchase - 获取上市公司回购股票数据

stk_holdertrade - 获取上市公司增减持数据 

share_float - 获取限售股解禁

##### 4.2.2.7 龙虎榜¶

top_inst - 龙虎榜机构成交明细

top_inst - 龙虎榜机构成交明细

##### 4.2.2.8 预测数据¶

stk_forecast_esp - 获取不同周期的预测每股收益

stk_forecast_beats - 获取每股收益超预期

stk_org_info - 获取机构信息

stk_forecast_org - 获取机构预测每股收益

##### 4.2.2.9 经济数据库¶

edb - 获取经济数据库(EDB)-全球经济

#### 4.2.3 期货数据¶

fut_get_continuous_contracts - 获取连续合约对应的真实合约

fut_get_contract_info - 查询期货标准品种信息

fut_get_transaction_ranking - 查询期货每日成交持仓排名

fut_get_warehouse_receipt - 查询期货仓单数据

#### 4.2.4 基金数据¶

fnd_get_etf_constituents - 查询 ETF 最新成分股

fnd_get_portfolio - 查询基金资产组合

fnd_get_net_value - 查询基金净值数据

fnd_get_adj_factor - 查询基金复权因子

fnd_get_dividend - 查询基金分红信息

fnd_get_split - 查询基金拆分折算信息

#### 4.2.5 可转债数据¶

bnd_get_conversion_price - 查询可转债转股价变动信息

bnd_get_call_info - 查询可转债赎回信息

bnd_get_put_info - 查询可转债回售信息

bnd_get_amount_change - 查询可转债剩余规模变动

#### 4.2.6财务数据¶

stk_get_fundamentals_balance - 查询资产负债表数据

stk_get_fundamentals_cashflow - 查询现金流量表数据

stk_get_fundamentals_income - 查询利润表数据

stk_get_finance_prime - 查询财务主要指标数据

stk_get_finance_deriv - 查询财务衍生指标数据

stk_get_daily_valuation - 查询估值指标每日数据

stk_get_daily_mktvalue - 查询市值指标每日数据

stk_get_daily_basic - 查询基础指标每日数据

### 4.3 因子接口¶

set_factor_values - 设置因子值

set_factor_performance - 设置因子绩效 

set_factor_values_by_freq - 设置降频因子值

set_factor_values_by_freq - 设置降频因子值

get_all_factors - 获取所有因子的信息

get_factor_values - 获取质量因子、基础因子、情绪因子、成长因子、风险因子、量价因子等因子数据 

## 五 软件及下载地址¶

1、python windows版下载路径：<https://www.python.org/ftp/python/3.9.9/python-3.9.9-amd64.exe>

2、vscode windows版下载路径：<https://code.visualstudio.com/docs/?dv=win>

3、pycharm社区版 windows版下载路径：<https://www.jetbrains.com/pycharm/download/?section=windows>
