---
# Converted from: factor_api\index.html
---

# 期货数据函数¶

##  set_factor_values \- 设置因子值 ¶
    
    
    set_factor_values(factor_code, values)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`factor_code` |  `str` |  因子代码. |  _必需_  
`values` |  `DataFrame` |  pandas.Dataframe（index是日期字符串，column是股票代码，value是因子值） |  _必需_  
  
##  set_factor_performance \- 设置因子绩效 ¶
    
    
    set_factor_performance(datas)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`datas` |  `DataFrame` |  pandas.Dataframe（index是日期字符串，column是股票代码，value是因子值）. |  _必需_  
  
##  set_factor_values_by_freq \- 设置降频因子值. ¶
    
    
    set_factor_values_by_freq(code, datas)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`code` |  `str` |  因子代码. |  _必需_  
`datas` |  `DataFrame` |  pandas.Dataframe（index是日期字符串，column是股票代码，value是因子值）. |  _必需_  
  
##  get_all_factors \- 获取所有因子的信息 ¶
    
    
    get_all_factors()
    

**返回：**

名称 | 类型 | 描述  
---|---|---  
`factor` |  `str` |  因子代码  
`factor_intro` |  `str` |  因子名称  
`category` |  `int` |  因子分类  
`category_intro` |  `str` |  分类说明  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        data = ait0.get_all_factors()
        print(data)
        

  * Output: 
        
        factor                 factor_intro  category          0        OrderAmtQ99CrossPart_001     OrderAmtQ99CrossPart_001         5
        1        OrderAmtQ99CrossPart_002     OrderAmtQ99CrossPart_002         5
        2      TransBar0101_AmtQ80Bar_001   TransBar0101_AmtQ80Bar_001         5
        3      TransBar0101_AmtQ80Bar_003   TransBar0101_AmtQ80Bar_003         5
        4      TransBar0101_AmtQ80Bar_002   TransBar0101_AmtQ80Bar_002         5
        ...                           ...                          ...       ...
        1400                      lenthdk                      lenthdk         5
        1401    lenthdk_3_standardization    lenthdk_3_standardization         5
        1402    lenthdk_5_standardization    lenthdk_5_standardization         5
        1403                    lenthrate                    lenthrate         5
        1404  lenthrate_3_standardization  lenthrate_3_standardization         5
        
             category_intro
        0              技术因子
        1              技术因子
        2              技术因子
        3              技术因子
        4              技术因子
        ...             ...
        1400           技术因子
        1401           技术因子
        1402           技术因子
        1403           技术因子
        1404           技术因子
        
        [1405 rows x 4 columns]
        

##  get_factor_values \- 获取质量因子、基础因子、情绪因子、成长因子、风险因子、量价因子等因子数据 ¶
    
    
    get_factor_values(securities, factors, start_date=None, end_date=None, count=None, df=False)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`securities` |  `str | list` |  股票池，股票（使用,分割）或一个股票列表,如SZSE.000001;为None时表示查询所有股票 |  _必需_  
`factors` |  `str` |  因子名称，因子（使用,分割）或一个因子列表,为None时表示查询所有因子 |  _必需_  
`start_date` |  `str | datetime | date` |  开始日期，字符串或 datetime或date 对象，与 coun t参数二选一 |  `None`  
`end_date` |  `str | datetime | date` |  结束日期， 字符串或 datetime或date 对象，可以与 start_date 或 count 配合使用 |  `None`  
`count` |  `int` |  截止 end_date 之前交易日的数量（含 end_date 当日），与 start_date 参数二选一 |  `None`  
`df` |  `bool` |  是否返回pandas.Dataframe对象，默认返回dict |  `False`  
  
**返回：**

类型 | 描述  
---|---  
`dict` |  dict：key是因子名称，value是pandas.Dataframe（index是日期，column是股票代码，value是因子值）  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        datas = ait0.get_factor_values(securities='SZSE.000090,SZSE.000155',
                factors='sale_expense_to_operating_revenue',
                start_date='2023-07-10',
                end_date='2023-07-10',
                df=True)
        print(datas)
        

  * Output: 
        
        {'sale_expense_to_operating_revenue':             SZSE.000090  SZSE.000155
        trade_date
        2023-07-10     0.007745     0.001434}
        

