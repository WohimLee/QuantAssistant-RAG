---
# Converted from: strategy_architecture\index.html
---

# 策略程序架构¶

## 概述¶

  * 基于开源框架[backtrader](https://backtrader.com/)

  * 在`backtrader`基础上进行扩展,支持回测模式和仿真模式

    * 回测模式支持全市场高精度模拟撮合(支持A股/港股/国内外期货市场),支持tick级别及k线级别的回测
    * 仿真模式支持对接实时行情(tick及k线)、对接券商柜台/期货CTP接口
  * 扩展后的架构如下图: ![架构图](../img/backtrader_sdk.png)

  * 主要扩展类说明:

    * `AICerebro`: 自定义引擎,主要是针对各种参数的处理,支持本地及服务器运行模式,支持回测及仿真.
    * `AIStrategy`: 自定义策略基类,主要是改写了下单接口及获取持仓的接口,编写策略是需要从这个类继承.
    * `BackTestBroker`: 自定义回测broker,主要是对接高精度模拟撮合引擎模块(采用Golang实现).
    * `BarFeeds`: 自定义历史k线数据类,从行情系统中获取历史k线数据.
    * `TickFeeds`: 自定义历史tick数据类,从行情系统中获取历史tick数据.
    * `LiveStore`: 自定义仿真store,主要对接实时行情模块(采用Golang实现)和仿真交易模块(采用Golang实现).
    * `LiveBroker`: 自定义仿真broker,主要处理仿真交易的单据/资金/持仓的数据.
    * `LiveBarFeeds`: 自定义实时k线数据类,从行情系统中获取实时k线数据.
    * `LiveTickFeeds`: 自定义实时tick数据类,从行情系统中获取实时tick数据.

## 基本流程¶

  1. 创建用户策略类，例如class `MyStrategy`，继承自`AIStrategy`
  2. 示例化一个`AICerebro`对象
  3. 将用户策略类添加到`AICerebro`对象
  4. 配置`AICerebro`对象的其他特性
  5. 执行`AICerebro`对象的`run()`方法启动

## 策略示例¶
    
    
    import datetime
    import uuid
    import backtrader as bt
    from ait0 import strategy, config
    
    
    class MyStrategy(strategy.AIStrategy):
        # 对象初始化时调用,datas继承自bt.Strategy
        def __init__(self):
            self.order = {}
    
        # 订单通知回调
        def notify_order(self, order):
            if order.status in [order.Submitted, order.Accepted]:
                # 状态是已提交/已接收时,直接返回
                return
    
            if order.status in [order.Completed]:
                # 状态是已完成
                if order.isbuy():
                    print('BUY EXECTED, Size: %d, Price: %.2f, Cost: %.2f, Comm: %.2f' %
                          (order.executed.size, order.executed.price, order.executed.value, order.executed.comm))
                elif order.issell():
                    print('SELL EXECUTED, Size: %d, Price: %.2f, Cose: %.2f, Comm: %.2f' %
                          (order.executed.size, order.executed.price, order.executed.value, order.executed.comm))
            elif order.status in [order.Canceled, order.Margin, order.Rejected]:
                print('Order Canceled/Margin/Rejected')
    
        # 成交回调通知.
        def notify_trade(self, trade):
            # 过滤掉开仓的成交.
            if not trade.isclosed:
                return
            print()
    
        def next(self, datas):
            for data in datas:
                order_buy = self.buy(data, size=100, price=data.close[0])
                print("Order buy s", order_buy.status)
    
                order_sell = self.sell(data, size=100, price=data.close[0])
                print("Order sell", order_sell)
    
        def stop(self):
            self.log('Ending Value %.2f' % (self.broker.getvalue()))
    
    
    if __name__ == '__main__':
        # 设置配置参数
        config.set_mode(config.MODE_LIVE_REMOTE)
        # 创建Cerebro实例.
        cerebro = strategy.AICerebro()
        # 添加策略
        cerebro.addstrategy(MyStrategy)
        # 设置下单手数,每次都是100股.
        cerebro.addsizer(bt.sizers.FixedSize, stake=100)
        # 生成随机批次号
        running_code = str(uuid.uuid4())
    
        # 运行策略.
        result = cerebro.run(
            symbols=['SZSE.000333'],  # 设置回测的标的,必填.
            fromdate=datetime.datetime(2023, 3, 30, 8, 0, 0),  # 设置回测的开始时间,必填.
            todate=datetime.datetime(2023, 4, 3, 16, 0, 0),  # 设置回测的结束时间,必填.
            portfolio="HcZ8czvX9pcvLGs",  # 设置投资组合的Token,必填.
            running_code=running_code,  # 设置批次号,可选填.
            strategy_code="AT2408081335200001",  # 设置策略代码,必填.
            period="1d",  # k线周期,默认值为60s即1分钟线,回测1分钟线时可不填.
            initial_cash=500000,  # 设置回测初始资金.
            adjust=1,  # 前复权,默认值为不复权.
            run_mode=2,  # 回测模式,默认值为2,回测时可不填.
        )
    
