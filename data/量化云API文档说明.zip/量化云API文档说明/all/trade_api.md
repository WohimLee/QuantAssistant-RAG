---
# Converted from: trade_api\index.html
---

# 独立交易接口¶

##  Trade \- 独立交易接口类 ¶

Bases: `object`

###  __init__ \- 对象初始化接口 ¶
    
    
    __init__(**kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`**kwargs` |  `dict` |  选填参数，项见 Other Args（其他参数） |  `{}`  
  
**其他参数：**

名称 | 类型 | 描述  
---|---|---  
`account_no` |  `str` |  交易账号  
`strategy_code` |  `str` |  策略编号  
`portfolio` |  `str` |  投资组合token  
`basket_name` |  `str` |  篮子名称  
`last_price_ratio` |  `float` |  最新价时的比率。默认值: 1.0  
`url` |  `str` |  服务器地址。默认值: 'https://ait0-go.1quant.com'  
`quote_url` |  `str` |  行情服务地址。默认值: 'https://ait0-gateway.1quant.com'  
`quote_grpc_addr` |  `str` |  行情服务地址。默认值: 'ait0-query.1quant.com:1443'  
  
###  adjust_qty \- 根据规则调整股数. ¶
    
    
    adjust_qty(row)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`row` |  `DataFrame` |  行数据. |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`int` |  股数  
  
###  batch_order_req \- 根据股票及数量批量下单. ¶
    
    
    batch_order_req(params, price_type=PriceType_Opposite)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`params` |  `dict` |  key-合约，value-数量. |  _必需_  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
  
**返回：**

类型 | 描述  
---|---  
`int` |  股数  
  
###  build_order_req \- 构建委托请求  `staticmethod` ¶
    
    
    build_order_req(symbol, buy_or_sell, volume, open_close_mode, td, trigger_time)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  委托标的代码 |  _必需_  
`buy_or_sell` |  `int` |  买卖方向 |  _必需_  
`volume` |  `int` |  委托数量 |  _必需_  
`open_close_mode` |  `int` |  开平方式 |  _必需_  
`td` |  `str` |  交易日 |  _必需_  
`trigger_time` |  `int` |  委托时间戳 |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`dict` |  委托请求  
  
###  cancel_orders \- 撤销委托 ¶
    
    
    cancel_orders(side=None, filter_fun=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`side` |  `int` |  委托方向, 66-买, 83-卖。默认全部 |  `None`  
`filter_fun` |  `func` |  过滤规则 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[str]` |  委托单号  
  
###  get_fund \- 获取账号资金信息 ¶
    
    
    get_fund()
    

**返回：**

类型 | 描述  
---|---  
`DataFrame` |  账号资金信息  
  
###  get_history_orders \- 获取历史委托 ¶
    
    
    get_history_orders(start_date, end_date=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`start_date` |  `str | datetime` |  开始日期 |  _必需_  
`end_date` |  `str | datetime` |  [选填]结束日期 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`DataFrame` |  委托列表  
  
###  get_history_trades \- 获取历史成交 ¶
    
    
    get_history_trades(start_date, end_date=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`start_date` |  `str | datetime` |  开始日期 |  _必需_  
`end_date` |  `str | datetime` |  [选填]结束日期 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`DataFrame` |  成交列表  
  
###  get_orders \- 获取今日委托 ¶
    
    
    get_orders()
    

**返回：**

类型 | 描述  
---|---  
`DataFrame` |  今日委托列表  
  
###  get_trades \- 获取今日成交 ¶
    
    
    get_trades()
    

**返回：**

类型 | 描述  
---|---  
`DataFrame` |  今日成交列表  
  
###  get_unfinished_orders \- 获取未成委托 ¶
    
    
    get_unfinished_orders(side=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`side` |  `int` |  委托方向, 66-买, 83-卖。默认全部 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`DataFrame` |  未成委托列表  
  
###  open_order \- 对剩余买单继续以指定价类型追单 ¶
    
    
    open_order(except_orders, price_type=PriceType_Opposite)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`except_orders` |  `DataFrame` |  目标仓位 |  _必需_  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  order_half \- 根据目标权重调仓 ¶
    
    
    order_half(except_orders, price_type=PriceType_Opposite)
    

说明

仅针对A股.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`except_orders` |  `DataFrame` |  字段symbol/qty |  _必需_  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  order_req \- 委托请求 ¶
    
    
    order_req(orders, price_type=PriceType_Opposite)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`orders` |  `(DataFrame, list[dict])` |  委托请求列表 |  _必需_  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  order_target_volume \- 根据目标仓位调仓 ¶
    
    
    order_target_volume(params)
    

说明

仅限支持中金所股指期货.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`params` |  `dict` |  字典,key为合约,value为目标仓位(0-表示没有仓位,正数-表示多仓,负数-表示空仓) |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  order_target_weight \- 根据目标权重调仓 ¶
    
    
    order_target_weight(params, price_type=PriceType_Opposite)
    

说明

仅针对A股.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`params` |  `dict` |  字典,key为合约,value为权重 |  _必需_  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  preload_order_target_volume \- 根据目标仓位获取调仓结果 ¶
    
    
    preload_order_target_volume(params)
    

说明

仅限支持中金所股指期货.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`params` |  `dict` |  字典,key为合约,value为净头寸仓位(0-表示没有仓位,正数-表示多仓,负数-表示空仓) |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`list` |  委托单据  
  
###  preload_order_target_weight \- 根据目标权重获取调仓结果 ¶
    
    
    preload_order_target_weight(params)
    

说明

仅针对A股.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`params` |  `dict` |  字典,key为合约,value为权重 |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`DataFrame` |  每支股票的下单数量,正数为买,负数为卖.  
  
###  query_last_price \- 获取指定symbol的最新价 ¶
    
    
    query_last_price(symbols)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `list[str]` |  symbol列表 |  _必需_  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`prices` |  `dict` |  最新价数据字典  
`not_exist_symbols` |  `list[str]` |  未查到的symbol列表  
  
###  reorder_close \- 针对未成卖单进行追单的处理 ¶
    
    
    reorder_close(except_orders, price_type=PriceType_Opposite)
    

说明

先撤单，再继续按买一价追.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`except_orders` |  `DataFrame` |  目标仓位 |  _必需_  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  reorder_open \- 针对未成买单进行追单的处理 ¶
    
    
    reorder_open(except_orders, price_type=PriceType_Opposite)
    

说明

委托价格不等于当前买一价的先撤,再继续以买一价追.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`except_orders` |  `DataFrame` |  目标仓位 |  _必需_  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  reorder_stock \- 对未成单进行追单的处理 ¶
    
    
    reorder_stock(except_orders, side=ShortPosition, price_type=PriceType_Opposite, cancel_filter_fun=None)
    

说明

先撤单,再继续按指定价格类型追

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`except_orders` |  `DataFrame` |  目标仓位 |  _必需_  
`side` |  `int` |  买方向还是卖方向. 66-买, 83-卖 |  `ShortPosition`  
`price_type` |  `int` |  价格类型,1-对手价,2-买一价,3-市价,4-最新价*ratio. |  `PriceType_Opposite`  
`cancel_filter_fun` |  `func` |  撤单规则. |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
###  reorder_target_volume \- 根据目标仓位进行追单 ¶
    
    
    reorder_target_volume(params)
    

说明

仅限支持中金所股指期货.

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`params` |  `dict` |  字典,key为合约,value为目标仓位(0-表示没有仓位,正数-表示多仓,负数-表示空仓) |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`bool` |  是否成功。true-成功,不需要继续追,false-还需要继续追.
