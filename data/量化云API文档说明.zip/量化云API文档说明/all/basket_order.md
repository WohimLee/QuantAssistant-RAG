---
# Converted from: basket_order\index.html
---

# 篮子单接口¶

##  basket_order_req \- 篮子下单接口 ¶
    
    
    basket_order_req(orders, **kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`orders` |  `DataFrame | list` |  下单的具体信息(包括如下列,symbol|volume|side|price|weight),side:1买,2卖. |  _必需_  
`**kwargs` |  `dict` |  篮子单需要用到的参数,详见Other Args: |  `{}`  
  
**其他参数：**

名称 | 类型 | 描述  
---|---|---  
`basketName` |  `str` |  篮子单名称,必填.  
`portfolio` |  `str` |  投资组合密钥,必填.  
`strategyCode` |  `str` |  策略编号,必填.  
`accountNo` |  `str` |  交易账号,必填.  
`basketType` |  `int` |  篮子类型,1-下单,2-调仓,必填.  
`algoType` |  `int` |  算法类型,1-普通下单,2-TWap,3-VWap,必填.  
`orderType` |  `int` |  委托类型,1-按资金权重,2-按委托数量,必填.  
`fundType` |  `int` |  资金类型;1-总资产,2-可用资金,3-自定义,选填,orderType委托类型为1时有效.  
`customAmount` |  `float` |  自定义资金,选填,fundType资金类型为3时有效.  
`fundRatio` |  `float` |  资金使用比例,选填,fundType资金类型为1和2时有效.  
`priceType` |  `int` |  委托价格类型;1-指定价,2-最新价,3-对手价,4-排队价;algoType算法类型为1时有效.  
`execStartTime` |  `str` |  篮子单开始执行时间,格式为yyyy-mm-dd hh:mi:ss  
`execEndTime` |  `str` |  篮子单结束执行时间,格式为yyyy-mm-dd hh:mi:ss,algoType算法类型为2和3时有效.  
`params` |  `str` |  算法参数.  
  
**示例：**

  * Input: 
        
        import ait0
        
        # 设置运行模式.
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        
        # 普通下单示例数据.
        orders = [{'symbol': 'SZSE.000001', 'volume': 300, 'side': 1}, {'symbol': 'SHSE.600000', 'volume': 500, 'side': 1}]
        
        # 篮子单参数.
        params = {
            'basketName': '测试直接下单py',
            'portfolio': 'QTATLb1hp6M2AA3',
            'strategyCode': 'AT2407051919240001',
            'accountNo': '6688b4cc-b9b8-11ed-977d-00163e022aa6',
            'basketType': 1,
            'algoType': 1,
            'orderType': 2,
            'execStartTime': '2024-01-19 13:34:00',
            'priceType': 2,
        }
        
        # 普通下单,到时间会直接全部一次性全部下完.
        ait0.signal.basket_order_req(orders, **params)
        
        # TWap下单示例数据(按权重).
        orders = [{'symbol': 'SZSE.000001', 'weight': 0.3, 'side': 1}, {'symbol': 'SHSE.600000', 'weight': 0.7, 'side': 1}]
        
        # 算法参数,下单时间间隔60s.
        al_p = json.dumps({'timeInterval': 60})
        
        # 篮子单参数.
        params = {
            'basketName': '测试直接下单py',
            'portfolio': 'QTATLb1hp6M2AA3',
            'strategyCode': 'AT2407051919240001',
            'accountNo': '6688b4cc-b9b8-11ed-977d-00163e022aa6',
            'basketType': 2,  # 调仓
            'algoType': 2,  # 算法采用TWap
            'orderType': 1,  # 按资金权重
            'fundType': 1,  # 按总资金.
            'fundRatio': 0.985,  # 资金使用比例.
            'params': al_p,  # 下单时间间隔60s,不填默认值就为60s.
            'execStartTime': '2024-01-19 13:34:00',  # 篮子单执行开始时间.
            'execEndTime': '2024-01-19 13:38:10',  # 篮子单执行结束时间.
        }
        
        # TWap下单时会先下卖单(采用买一价),30s后下买单(使用买一价),支持撤单追单,5s未成交的会撤单,然后追单(使用对手价).
        ait0.signal.basket_order_req(orders, **params)
        
        # VWap下单示例数据(按权重).
        orders = [{'symbol': 'SZSE.000001', 'weight': 0.3, 'side': 1}, {'symbol': 'SHSE.600000', 'weight': 0.7, 'side': 1}]
        
        # 算法参数,按照最近22天的历史行情数据计算成交量权重.
        al_p = json.dumps({'days': 22})
        
        # 篮子单参数.
        params = {
            'basketName': '测试直接下单py',
            'portfolio': 'QTATLb1hp6M2AA3',
            'strategyCode': 'AT2407051919240001',
            'accountNo': '6688b4cc-b9b8-11ed-977d-00163e022aa6',
            'basketType': 2,  # 调仓
            'algoType': 3,  # 算法采用VWap
            'orderType': 1,  # 按资金权重
            'fundType': 1,  # 按总资金.
            'fundRatio': 0.985,  # 资金使用比例.
            'params': al_p,  # 不填默认值就为22天.
            'execStartTime': '2024-01-19 13:34:00',  # 篮子单执行开始时间.
            'execEndTime': '2024-01-19 13:38:10',  # 篮子单执行结束时间.
        }
        
        # VWap下单时会先下卖单(市价),30s后下买单(市价),不支持撤单追单.
        ait0.signal.basket_order_req(orders, **params)
        

