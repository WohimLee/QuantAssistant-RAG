---
# Converted from: data_api_fund\index.html
---

# 基金数据函数¶

##  fnd_get_etf_constituents \- 查询 ETF 最新成分股 ¶
    
    
    fnd_get_etf_constituents(etf, *, fields=gdf.fnd_get_etf_constituents, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
2024-01-02 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`etf` |  `str | list` |  ETF代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SZSE.159919,SZSE.159973'   
采用 list 格式时，多个ETF代码示例：['SZSE.159919', 'SZSE.159973'] |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `fnd_get_etf_constituents`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`etf` |  `str` |  ETF代码  
`etf_name` |  `str` |  ETF名称  
`trade_date` |  `str` |  交易日期  
`symbol` |  `str` |  成分股代码  
`amount` |  `str` |  股票数量  
T日内容中最小申购赎回单位所对应的各成分股数量  
`cash_subs_type` |  `str` |  现金替代标志  
基金管理人对于每一只成分股使用现金替代情况的态度   
1-禁止   
2-允许   
3-必须   
4-退补  
`cash_subs_sum` |  `float` |  固定替代金额  
单位：人民币元  
`cash_premium_rate` |  `float` |  现金替代溢价比例  
单位：%  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fnd_get_etf_constituents(etf='SHSE.510050')
        print(df)
        

  * Output: 
        
        etf   etf_name  trade_date       symbol  amount cash_subs_type  cash_subs_sum  cash_premium_rate
        0    SHSE.510050  华夏上证50ETF  2023-11-17  SHSE.600010    7500             允许            0.0                 10
        1    SHSE.510050  华夏上证50ETF  2023-11-17  SHSE.600028    6400             允许            0.0                 10
        2    SHSE.510050  华夏上证50ETF  2023-11-17  SHSE.600030    3300             允许            0.0                 10
        3    SHSE.510050  华夏上证50ETF  2023-11-17  SHSE.600031    2000             允许            0.0                 10
        4    SHSE.510050  华夏上证50ETF  2023-11-17  SHSE.600036    4100             允许            0.0                 10
        ..           ...        ...         ...          ...     ...            ...            ...                ...
        395  SHSE.510050  华夏上证50ETF  2023-12-19  SHSE.603986     200             允许            0.0                 10
        396  SHSE.510050  华夏上证50ETF  2023-12-19  SHSE.688041     309             允许            0.0                 10
        397  SHSE.510050  华夏上证50ETF  2023-12-19  SHSE.688111      76             必须        24768.4                  0
        398  SHSE.510050  华夏上证50ETF  2023-12-19  SHSE.688599     365             允许            0.0                 10
        399  SHSE.510050  华夏上证50ETF  2023-12-19  SHSE.688981     654             允许            0.0                 10
        
        [400 rows x 8 columns]
        

* * *

##  fnd_get_portfolio \- 查询基金资产组合 ¶
    
    
    fnd_get_portfolio(fund, report_type, portfolio_type, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.fnd_get_portfolio, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`fund` |  `str | list` |  基金代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SZSE.161133,SHSE.501000'   
采用 list 格式时，多个ETF代码示例：['SZSE.161133', 'SHSE.501000'] |  _必需_  
`report_type` |  `int` |  报表类别  
公布持仓所在的报表类别，必填，可选：   
1:第一季度   
2:第二季度   
3:第三季报   
4:第四季度   
6:中报   
9:前三季报   
12:年报 |  _必需_  
`portfolio_type` |  `str` |  投资组合类型，必填，可选以下其中一种组合：   
'stk' - 股票投资组合   
'bnd' - 债券投资组合   
'fnd' - 基金投资组合 |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `fnd_get_portfolio`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`fund` |  `str` |  基金代码   
查询股票资产组合的基金代码  
`fund_name` |  `str` |  基金名称  
`pub_date` |  `str` |  公告日期   
在指定时间段内的公告日期，%Y-%m-%d 格式  
`period_end` |  `str` |  报告期   
持仓截止日期，%Y-%m-%d 格式  
`symbol` |  `str` |  标的代码  
`sec_name` |  `str` |  标的名称  
`hold_share` |  `float` |  持仓股数  
`hold_value` |  `float` |  持仓市值  
`nv_rate` |  `float` |  占净值比例  
单位：%  
`ttl_share_rate` |  `float` |  占总股本比例  
单位：%  
仅portfolio_type='stk'返回  
`clrc_share_rate` |  `float` |  占流通股比例  
单位：%  
仅portfolio_type='stk'返回  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fnd_get_portfolio(fund='SHSE.510300', start_date='2022-01-01', end_date='2022-10-01', report_type=1, portfolio_type='stk')
        print(df)
        

  * Output: 
        
        fund     fund_name    pub_date  period_end       symbol sec_name portfolio_type  report_type  hold_share    hold_value  nv_rate  ttl_share_rate  circ_share_rate
        0   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.600036     招商银行            stk            1    28571902  1.337165e+09     2.99        3.061763         0.138504
        1   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.600519     贵州茅台            stk            1     1442369  2.479432e+09     5.54        5.677261         0.114820
        2   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.600900     长江电力            stk            1    26244732  5.773841e+08     1.29        1.322061         0.115403
        3   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.601012     隆基股份            stk            1     9970298  7.197558e+08     1.61        1.648055         0.184197
        4   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.601166     兴业银行            stk            1    33444277  6.912932e+08     1.55        1.582883         0.170501
        5   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.601318     中国平安            stk            1    24995695  1.211041e+09     2.71        2.772973         0.230744
        6   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.603259     药明康德            stk            1     4715124  5.298856e+08     1.18        1.213302         0.185108
        7   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.688223     晶科能源            stk            1      213000  2.161950e+06     0.00        0.004950         0.016117
        8   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.688234     天岳先进            stk            1        6759  3.445062e+05     0.00        0.000789         0.020022
        9   SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SHSE.688282     理工导航            stk            1        3185  1.511920e+05     0.00        0.000346         0.016205
        10  SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SZSE.000333     美的集团            stk            1    11271415  6.424707e+08     1.44        1.471092         0.164837
        11  SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SZSE.000858      五粮液            stk            1     4471969  6.934235e+08     1.55        1.587761         0.115212
        12  SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SZSE.300750     宁德时代            stk            1     3210571  1.644776e+09     3.68        3.766112         0.157485
        13  SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SZSE.301088     戎美股份            stk            1        7036  1.343382e+05     0.00        0.000308         0.013428
        14  SHSE.510300  华泰柏瑞沪深300ETF  2022-04-22  2022-03-31  SZSE.301102     兆讯传媒            stk            1        6414  1.994678e+05     0.00        0.000457         0.014861
        

* * *

##  fnd_get_net_value \- 查询基金净值数据 ¶
    
    
    fnd_get_net_value(fund, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.fnd_get_net_value, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
2004-10-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`fund` |  `str | list` |  基金代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SZSE.161133,SHSE.501000'   
采用 list 格式时，多个ETF代码示例：['SZSE.161133', 'SHSE.501000'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `fnd_get_net_value`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`fund` |  `str` |  基金代码   
查询股票资产组合的基金代码  
`trade_date` |  `str` |  交易日期   
指定时间段内的交易日期，%Y-%m-%d 格式  
`unit_nv` |  `float` |  单位净值  
T日单位净值是每个基金份额截至T日的净值（也是申赎的价格）  
`unit_nv_accu` |  `float` |  累计单位净值   
T日累计净值是指，在基金成立之初投资该基金1元钱，在现金分红方式下，截至T日账户的净值  
`unit_nv_adj` |  `float` |  复权单位净值   
T日复权净值是指，在基金成立之初投资该基金1元钱，在分红再投资方式下，截至T日账户的净值  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fnd_get_net_value(fund='SHSE.510300')
        print(df)
        

  * Output: 
        
        fund  trade_date  unit_nv  unit_nv_accu  unit_nv_adj
        0  SHSE.510300  2023-12-26    3.393        1.4812     1.487895
        

* * *

##  fnd_get_adj_factor \- 查询基金复权因子 ¶
    
    
    fnd_get_adj_factor(fund, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.fnd_get_adj_factor, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
2004-12-20 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`fund` |  `str | list` |  基金代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SZSE.161133,SHSE.501000'   
采用 list 格式时，多个ETF代码示例：['SZSE.161133', 'SHSE.501000'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `fnd_get_adj_factor`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`fund` |  `str` |  基金代码   
查询股票资产组合的基金代码  
`trade_date` |  `str` |  交易日期   
指定时间段内的交易日期，%Y-%m-%d 格式  
`adj_factor_bwd_acc` |  `float` |  当日累计后复权因子  
  
除权日，T 日累计后复权因子=(T-1 日单位净值/(T-1 日单位净值-本次单位分红))×T-1 日累计后复权因子 × 折算比例 其余情况，T 日累计后复权因子=T-1 日累计后复权因子  
`adj_factor_fwd` |  `float` |  当日前复权因子   
T日前复权因子=T日累计后复权因子/复权基准日累计后复权因子  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fnd_get_adj_factor(fund='SZSE.161725', start_date="2021-12-01", end_date="2022-01-01")
        print(df)
        

  * Output: 
        
        fund  trade_date  adj_factor_bwd_acc  adj_factor_fwd
        0   SZSE.161725  2021-12-01            1.009701        0.948523
        1   SZSE.161725  2021-12-02            1.009701        0.948523
        2   SZSE.161725  2021-12-03            1.009701        0.948523
        3   SZSE.161725  2021-12-06            1.009701        0.948523
        4   SZSE.161725  2021-12-07            1.009701        0.948523
        5   SZSE.161725  2021-12-08            1.009701        0.948523
        6   SZSE.161725  2021-12-09            1.009701        0.948523
        7   SZSE.161725  2021-12-10            1.029430        0.967057
        8   SZSE.161725  2021-12-13            1.029430        0.967057
        9   SZSE.161725  2021-12-14            1.029430        0.967057
        10  SZSE.161725  2021-12-15            1.029430        0.967057
        11  SZSE.161725  2021-12-16            1.029430        0.967057
        12  SZSE.161725  2021-12-17            1.029430        0.967057
        13  SZSE.161725  2021-12-20            1.029430        0.967057
        14  SZSE.161725  2021-12-21            1.029430        0.967057
        15  SZSE.161725  2021-12-22            1.029430        0.967057
        16  SZSE.161725  2021-12-23            1.029430        0.967057
        17  SZSE.161725  2021-12-24            1.029430        0.967057
        18  SZSE.161725  2021-12-27            1.029430        0.967057
        19  SZSE.161725  2021-12-28            1.029430        0.967057
        20  SZSE.161725  2021-12-29            1.029430        0.967057
        21  SZSE.161725  2021-12-30            1.029430        0.967057
        22  SZSE.161725  2021-12-31            1.029430        0.967057
        

* * *

##  fnd_get_dividend \- 查询基金分红信息 ¶
    
    
    fnd_get_dividend(fund, start_date, end_date, *, fields=gdf.fnd_get_dividend, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
2004-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`fund` |  `str | list` |  基金代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SZSE.161133,SHSE.501000'   
采用 list 格式时，多个ETF代码示例：['SZSE.161133', 'SHSE.501000'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `fnd_get_dividend`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`fund` |  `str` |  基金代码   
查询股票资产组合的基金代码  
`pub_date` |  `str` |  公告日期   
%Y-%m-%d 格式  
`event_progress` |  `str` |  方案进度   
正式，预案  
`dvd_ratio` |  `float` |  派息比例  
10:X，每 10 份税前分红  
`dvd_base_date` |  `str` |  分配收益基准日  
%Y-%m-%d 格式  
`rt_reg_date` |  `str` |  权益登记日  
%Y-%m-%d 格式  
`ex_act_date` |  `str` |  实际除息日  
%Y-%m-%d 格式  
`ex_dvd_date` |  `str` |  场内除息日  
%Y-%m-%d 格式  
`pay_dvd_date` |  `str` |  场内红利发放日  
%Y-%m-%d 格式  
`trans_dvd_date` |  `str` |  场内红利款账户划出日  
%Y-%m-%d 格式  
`reinvest_cfm_date` |  `str` |  红利再投资确定日  
%Y-%m-%d 格式  
`ri_shr_arr_date` |  `str` |  红利再投资份额到账日  
%Y-%m-%d 格式  
`ri_shr_rdm_date` |  `str` |  红利再投资赎回起始日  
%Y-%m-%d 格式  
`earn_distr` |  `float` |  可分配收益  
单位：元  
`cash_pay` |  `float` |  本期实际红利发放  
单位：元  
`base_unit_nv` |  `float` |  基准日基金份额净值  
单位：元  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fnd_get_dividend(fund='SZSE.161725', start_date="2000-01-01", end_date="2022-09-07")
        print(df)
        

  * Output: 
        
        fund    pub_date event_progress  dvd_ratio dvd_base_date rt_reg_date ex_act_date ex_dvd_date pay_dvd_date trans_dvd_date reinvest_cfm_date ri_shr_arr_date ri_shr_rdm_date    earn_distr  cash_pay  base_unit_nv
        0  SZSE.161725  2021-09-02             正式       0.12    2021-08-27  2021-09-07  2021-09-07  2021-09-08   2021-09-09     2021-09-09        2021-09-07      2021-09-08      2021-09-09  3.757369e+10         0        1.1893
        1  SZSE.161725  2021-12-07             正式       0.28    2021-12-02  2021-12-09  2021-12-09  2021-12-10   2021-12-13     2021-12-13        2021-12-09      2021-12-10      2021-12-13  3.354882e+10         0        1.3696
        2  SZSE.161725  2021-12-29             正式       0.45    2021-12-24  2021-12-31  2021-12-31  2022-01-04   2022-01-05     2022-01-05        2021-12-31      2022-01-04      2022-01-05  3.072297e+10         0        1.4178
        

* * *

##  fnd_get_split \- 查询基金拆分折算信息 ¶
    
    
    fnd_get_split(fund, start_date, end_date, *, fields=gdf.fnd_get_split, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
2004-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`fund` |  `str | list` |  基金代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SZSE.161133,SHSE.501000'   
采用 list 格式时，多个ETF代码示例：['SZSE.161133', 'SHSE.501000'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  _必需_  
`fields` |  `str | list` |  指定需要返回的字段 |  `fnd_get_split`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`fund` |  `str` |  基金代码   
查询股票资产组合的基金代码  
`pub_date` |  `str` |  公告日期   
%Y-%m-%d 格式  
`split_type` |  `str` |  拆分折算类型   
折算，拆分，特殊折算  
`split_ratio` |  `float` |  拆分折算比例  
10:X  
`base_date` |  `str` |  拆分折算基准日  
%Y-%m-%d 格式  
`ex_date` |  `str` |  拆分折算场内除权日  
%Y-%m-%d 格式  
`share_change_reg_date` |  `str` |  基金份额变更登记日  
%Y-%m-%d 格式  
`nv_split_pub_date` |  `str` |  基金披露净值拆分折算日  
%Y-%m-%d 格式  
`rt_reg_date` |  `str` |  权益登记日  
%Y-%m-%d 格式  
`ex_date_close` |  `str` |  场内除权日(收盘价)  
%Y-%m-%d 格式  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.fnd_get_split(fund='SZSE.161725', start_date="2000-01-01", end_date="2022-09-07")
        print(df)
        

  * Output: 
        
        fund    pub_date split_type  split_ratio   base_date     ex_date share_change_reg_date nv_split_pub_date rt_reg_date ex_date_close
        0  SZSE.161725  2015-12-17         折算    10.180127  2015-12-15  2015-12-17            2015-12-16        2015-12-15        None    2015-12-17
        1  SZSE.161725  2016-12-19         折算    10.230030  2016-12-15  2016-12-19            2016-12-16        2016-12-15        None    2016-12-19
        2  SZSE.161725  2017-09-28         折算    14.942028  2017-09-26  2017-09-28            2017-09-27        2017-09-26        None    2017-09-28
        3  SZSE.161725  2017-12-19         折算    10.044539  2017-12-15  2017-12-19            2017-12-18        2017-12-15        None    2017-12-19
        4  SZSE.161725  2018-12-19         折算    10.254705  2018-12-17  2018-12-19            2018-12-18        2018-12-17        None    2018-12-19
        5  SZSE.161725  2019-07-04         折算    15.568621  2019-07-02  2019-07-04            2019-07-03        2019-07-02        None    2019-07-04
        6  SZSE.161725  2019-12-18         折算    10.106689  2019-12-16  2019-12-18            2019-12-17        2019-12-16        None    2019-12-18
        7  SZSE.161725  2020-08-28         折算    14.981733  2020-08-26  2020-08-28            2020-08-27        2020-08-26        None    2020-08-28
        8  SZSE.161725  2020-12-17         折算    10.054441  2020-12-15  2020-12-17            2020-12-16        2020-12-15        None    2020-12-17
        

* * *
