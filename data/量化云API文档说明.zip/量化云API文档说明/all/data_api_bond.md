---
# Converted from: data_api_bond\index.html
---

# 可转债数据函数¶

##  bnd_get_conversion_price \- 查询可转债转股价变动信息 ¶
    
    
    bnd_get_conversion_price(symbol, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.bnd_get_conversion_price, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  可转债代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SHSE.110060,SZSE.123129'   
采用 list 格式时，多个ETF代码示例：['SHSE.110060', 'SZSE.123129'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `bnd_get_conversion_price`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  可转债代码  
`pub_date` |  `str` |  公告日期   
%Y-%m-%d 格式  
`effective_date` |  `str` |  转股价格生效日期   
%Y-%m-%d 格式  
`execution_date` |  `str` |  执行日期   
%Y-%m-%d 格式  
`conversion_price` |  `float` |  转股价格   
单位：元  
`conversion_rate` |  `float` |  转股比例   
单位：%  
`conversion_volume` |  `float` |  本期转股数   
单位：股  
`conversion_amount_total` |  `float` |  累计转股金额   
单位：万元，累计转债已经转为股票的金额，累计每次转股金额  
`bond_float_amount_remain` |  `float` |  债券流通余额   
单位：万元  
`event_type` |  `str` |  事件类型   
初始转股价，调整转股价，修正转股价  
`change_reason` |  `str` |  转股价变动原因   
发行，股权激励，股权分置，触发修正条款，其它变动原因，换股吸收合并，配股，增发，上市，派息，送股，转增股，修正  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.bnd_get_conversion_price(symbol='SZSE.123015')
        print(df)
        

  * Output: 
        
        symbol    pub_date effective_date execution_date  conversion_price  conversion_rate  conversion_volume  conversion_amount_total  bond_float_amount_remain event_type change_reason
        0  SZSE.123015  2023-05-08     2023-05-09     2023-05-09              0.84         119.0476                  0                        0                         0      修正转股价     修正,触发修正条款
        

* * *

##  bnd_get_call_info \- 查询可转债赎回信息 ¶
    
    
    bnd_get_call_info(symbol, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.bnd_get_call_info, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  可转债代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SHSE.110060,SZSE.123129'   
采用 list 格式时，多个ETF代码示例：['SHSE.110060', 'SZSE.123129'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `bnd_get_call_info`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  可转债代码  
`pub_date` |  `str` |  赎回公告日   
%Y-%m-%d格式  
`call_date` |  `str` |  赎回日 - 发行人行权日（实际）   
%Y-%m-%d格式  
`record_date` |  `str` |  赎回登记日 - 理论登记日   
%Y-%m-%d格式  
`cash_date` |  `str` |  赎回资金到账日 - 投资者赎回款到账日   
%Y-%m-%d格式  
`call_type` |  `str` |  赎回类型   
部分赎回，全部赎回  
`call_reason` |  `str` |  赎回原因   
满足赎回条件，强制赎回，到期赎回  
`call_price` |  `float` |  赎回价格   
单位：元/张，每百元面值赎回价格，即债券面值加当期应计利息（含税）  
`interest_included` |  `bool` |  是否包含利息   
False-不包含，True-包含  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.bnd_get_call_info(symbol='SHSE.110041')
        print(df)
        

  * Output: 
        
        symbol    pub_date   call_date record_date cash_date call_type call_reason  call_price  interest_included
        0  SHSE.110041  2021-09-30  2021-11-05  2021-11-04      None      全部赎回        强制赎回     101.307                  1
        

* * *

##  bnd_get_put_info \- 查询可转债回售信息 ¶
    
    
    bnd_get_put_info(symbol, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.bnd_get_put_info, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  可转债代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SHSE.110060,SZSE.123129'   
采用 list 格式时，多个ETF代码示例：['SHSE.110060', 'SZSE.123129'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `bnd_get_put_info`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  可转债代码  
`pub_date` |  `str` |  赎回公告日   
%Y-%m-%d格式  
`put_start_date` |  `str` |  赎回日 - 投资者行权起始日   
%Y-%m-%d格式  
`put_end_date` |  `str` |  赎回登记日 - 投资者行权截止日   
%Y-%m-%d格式  
`cash_date` |  `str` |  赎回资金到账日 - 投资者赎回款到账日   
%Y-%m-%d格式  
`put_reason` |  `str` |  回售原因   
满足回售条款，满足附加回售条款  
`put_price` |  `float` |  回售价格   
单位：元/张，每百元面值回售价格（元），即债券面值加当期应计利息（含税）  
`interest_included` |  `bool` |  是否包含利息   
False-不包含，True-包含  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.bnd_get_put_info(symbol='SZSE.128015')
        print(df)
        

  * Output: 
        
        symbol    pub_date put_start_date put_end_date   cash_date put_reason  put_price  interest_included
        0  SZSE.128015  2022-06-09     2022-06-16   2022-06-22  2022-06-29     满足回售条款    100.039                  1
        

* * *

##  bnd_get_amount_change \- 查询可转债剩余规模变动 ¶
    
    
    bnd_get_amount_change(symbol, *, start_date=None, end_date=None, pivot_date=None, fields=gdf.bnd_get_amount_change, df=True)
    

数据范围 | 更新频率 | 更新时间  
---|---|---  
1990-01-01 ~ Now | 每个交易日 | 5:00pm  
  
**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str | list` |  可转债代码，可输入多个   
采用 str 格式时，多个ETF代码必须用英文逗号分割，如：'SHSE.110060,SZSE.123129'   
采用 list 格式时，多个ETF代码示例：['SHSE.110060', 'SZSE.123129'] |  _必需_  
`start_date` |  `str | datetime | timestamp` |  开始日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`end_date` |  `str | datetime | timestamp` |  结束日期，%Y-%m-%d 格式，默认None表示当前时间 |  `None`  
`pivot_date` |  `str | datetime | timestamp` |  基准日期，%Y-%m-%d 格式，默认None，用来指定某一日期向前查询最近一条数据 |  `None`  
`fields` |  `str | list` |  指定需要返回的字段 |  `bnd_get_amount_change`  
`df` |  `bool` |  是否返回 dataframe 格式，默认False返回字典格式，返回 list[dict]，列表每项的 dict 的 key 值为 fields 字段 |  `True`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  可转债代码  
`pub_date` |  `str` |  赎回公告日   
%Y-%m-%d格式  
`change_date` |  `str` |  变动日期   
%Y-%m-%d格式  
`change_type` |  `str` |  变动类型   
首发，增发，转股，赎回，回售(注销)，到期  
`change_amount` |  `float` |  本次变动金额   
单位：万元  
`remain_amount` |  `float` |  剩余金额 - 变动后金额   
单位：万元  
  
**示例：**

  * Input: 
        
        from ait0 import api, config
        config.set_mode(config.MODE_LIVE_REMOTE)
        df = ait0.gm.bnd_get_amount_change(symbol='SZSE.123015')
        print(df)
        

  * Output: 
        
        symbol    pub_date change_date change_type  change_amount  remain_amount
        0  SZSE.123015  2023-07-03  2023-06-30          转股            0.2        9999.48
        

* * *
