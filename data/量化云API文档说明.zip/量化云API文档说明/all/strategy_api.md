---
# Converted from: strategy_api\index.html
---

# 策略API介绍¶

## 基本接口¶

###  addstrategy \- 添加策略 ¶
    
    
    addstrategy(strategy, *args, **kwargs)
    

说明

目前只支持添加一个策略。

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`strategy` |  `AIStrategy` |  用户策略类，继承自AIStrategy |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`int` |  已添加的策略数量  
  
**示例：**
    
    
    from ait0.strategy.strategy import AIStrategy
    from ait0.strategy.cerebro import AICerebro
    
    class MyStrategy(AIStrategy):
        def next(self, datas):
            for data in datas:
                print(data.p.symbol)
    
    cerebro = AICerebro()
    cerebro.addstrategy(MyStrategy)
    

###  add_parameter \- 添加参数 ¶
    
    
    add_parameter(key, value, name='')
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`key` |  `str` |  参数的键 |  _必需_  
`value` |  `any` |  参数的值 |  _必需_  
`name` |  `str` |  参数名称 |  `''`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
**示例：**
    
    
    from ait0.strategy.cerebro import AICerebro
    
    cerebro = AICerebro()
    cerebro.add_parameter(key='Long', value=[26], name='MACD_Long')
    cerebro.add_parameter(key='Short', value=[26], name='MACD_Short')
    

###  addgroup \- 添加票池 ¶
    
    
    addgroup(group, *args, **kwargs)
    

说明

目前只支持添加一个票池。

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`group` |  `Group` |  票池类,继承自Group. |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
**示例：**
    
    
    from ait0 import strategy
    from ait0.strategy.cerebro import AICerebro
    
    cerebro = AICerebro()
    kwargs = {'exchanges': 'HKEX'}
    cerebro = strategy.AICerebro()
    cerebro.addgroup(ait0.strategy.ExchangeGroup, **kwargs)
    

###  run \- 运行策略 ¶
    
    
    run(**kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`**kwargs` |  `dict` |  参数集合，见 `其他参数` 列表 |  `{}`  
  
**其他参数：**

名称 | 类型 | 描述  
---|---|---  
`portfolio` |  `str` |  `必填` 投资组合的密钥,密钥由投资组合管理员负责管理.  
`strategy_code` |  `str` |  `必填` 策略编号,需现在平台创建对应的策略.  
`running_code` |  `str` |  `选填` 默认空 批次号. 建议使用 str(uuid.uuid4())  
`adjust` |  `int` |  `选填` 默认0 - config.ADJUST_NONE, 行情复权方式,0-不复权,1-前复权,2-后复权.默认前复权,脚本控制  
`period` |  `str` |  `选填` 默认'60s'，支持多个周期,以逗号分隔. 支持'tick', '60s','300s','900s','1800s','3600s','1d',从系统参数中获取.  
`symbols` |  `str` |  `选填` 标的,多个以逗号分隔,脚本控制.  
`exchanges` |  `str` |  `选填` 交易所, 多个以逗号分隔, 脚本控制.  
`indexes` |  `str` |  `选填` 指数代码, 多个以逗号分隔, 脚本控制.  
`group_code` |  `str` |  `选填` 票池代码,票池的唯一标识,若有值会把票池推送到服务.  
`fromdate` |  `str | datetime` |  `回测` `选填`开始时间,datetime对象, 从系统参数中获取.  
`todate` |  `str | datetime` |  `回测` `必填` 结束时间,datetime对象, 从系统参数中获取.  
`count` |  `int` |  `回测` `选填` 样本数,与fromdate只能二选一, 从系统参数中获取.  
`exchange_trade_date` |  `str` |  `选填` 默认'SHSE'，查询指定交易所的交易日历.  
`padding` |  `int` |  `选填` 默认1 - 填充, 1-默认对行情数据进行填充, 0-不填充.  
`run_step` |  `int` |  `选填` 默认None, 运行模式, 1-只运行选股部分, 2-只运行策略逻辑部分.  
`initial_cash` |  `float` |  `回测` `必填` 回测金额.  
`accounts` |  `str` |  `仿真实盘` `必填` 账号,多个账号以逗号分隔.  
`match_mode` |  `int` |  `选填` 默认0, 0-正常撮合, 1-指定价成交(若未指定价格则按照当前bar的收盘价成交,若有指定价格要满足当前bar的OHLC)  
`run_mode` |  `int` |  `选填` 默认2, 策略运行模式, 1-表示仿真/实盘(enum.RunMode_Live), 2-表示回测(enum.RunMode_BackTest).  
`close_mode` |  `int` |  `选填` 默认0，平仓模式, 0-先建先平, 1-优先平今, 2-优先平昨. 由脚本控制.  
`vwap_price_type` |  `int` |  `选填` 默认None, vwap价格模式  
`prefetch` |  `int` |  `选填` 默认0，行情预取条数，若需要在策略里使用`getdatas(data, count, fields=None)`[接口](./#ait0.strategy.AIStrategy.getdatas)，则需要prefetch>=count  
`wait_group` |  `bool` |  `选填` 默认False, 是否等待同一频率的bar同时到齐（只支持bar频率），默认False  
`wait_group_timeout` |  `int` |  `选填` 默认10，等待超时时间（秒），只有wait_group=True时生效，默认10秒  
`debug_log` |  `int` |  `选填` 默认0，0-不打印，1-打印调试日志  
`strategy_id` |  `int` |  `系统调用` 策略id.  
`portfolio_id` |  `int` |  `系统调用` 投资组合的ID.  
`running_id` |  `int` |  `系统调用` `选填`，默认0, 批次号ID.  
`param_id` |  `int` |  `系统调用` 策略对应的运行参数ID.  
`quote_addr` |  `str` |  `系统调用` 行情grpc查询服务地址.  
`quote_http_addr` |  `str` |  `系统调用` 行情http网关服务地址.  
`quote_ws_addr` |  `str` |  `系统调用` 行情websocket网关服务地址.  
`bt_addr` |  `str` |  `系统调用` grpc回测服务地址  
`trade_addr` |  `str` |  `系统调用` trade网关服务地址  
`trade_ws_addr` |  `str` |  `系统调用` trade推送服务地址  
`serv_addr` |  `str` |  `系统调用` 网关服务地址  
`sys_param` |  `str` |  `系统调用` 系统运行参数.  
`run_param` |  `str` |  `系统调用` 业务运行参数.  
`run_plan_id` |  `int` |  `系统调用` 回测计划id.  
`creator_id` |  `int` |  `系统调用` 默认0，创建人.  
`currency` |  `str` |  `系统调用` 默认'CNY'，回测资金币种.  
`fut_month_rollover` |  `bool` |  `选填` 默认False, 不开启期货自动换月功能.  
`running_bar` |  `bool` |  `选填` 默认False,不启用, 是否启用running_bar功能(即实时更新k线).  
  
**示例：**
    
    
    import datetime
    import uuid
    import backtrader as bt
    from ait0 import strategy, config
    
    class MyStrategy(strategy.AIStrategy):
        def __init__(self):
            # 初始化代码
            pass
    
    if __name__ == '__main__':
        # 创建Cerebro实例.
        cerebro = strategy.AICerebro()
        # 添加策略
        cerebro.addstrategy(MyStrategy)
        # 设置下单手数,每次都是100股.
        cerebro.addsizer(bt.sizers.FixedSize, stake=100)
        # 生成随机批次号
        running_code = str(uuid.uuid4())
    
        # 运行策略.
        result = cerebro.run(
            symbols=['SZSE.000333'],  # 设置回测的标的,`必填`  .
            fromdate=datetime.datetime(2023, 3, 30, 8, 0, 0),  # 设置回测的开始时间,`必填`  .
            todate=datetime.datetime(2023, 4, 3, 16, 0, 0),  # 设置回测的结束时间,`必填`  .
            portfolio="HcZ8czvX9pcvLGs",  # 设置投资组合的Token,`必填`  .
            running_code=running_code,  # 设置批次号,可`选填`.
            strategy_code="AT2407051919240001",  # 设置策略编号,`必填`  .
            period="1d",  # k线周期,默认值为60s即1分钟线,回测1分钟线时可不填.
            initial_cash=500000,  # 设置回测初始资金.
            adjust=1,  # 前复权,默认值为不复权.
            run_mode=2,  # 回测模式,默认值为2,回测时可不填.
        )
    

## 日期时间¶

###  now \- 获取当前行情时间.  `property` ¶
    
    
    now: datetime.datetime
    

**返回：**

类型 | 描述  
---|---  
`datetime` |  当前行情时间.  
  
**示例：**
    
    
    print("current bar time: ", self.now)
    

###  trade_date \- 获取当前交易日  `property` ¶
    
    
    trade_date: datetime.datetime
    

**返回：**

类型 | 描述  
---|---  
`datetime` |  当前交易日  
  
**示例：**
    
    
    print("current trade date: ", self.trade_date)
    

###  pre_trade_date \- 获取前一交易日.  `property` ¶
    
    
    pre_trade_date: datetime.datetime
    

**返回：**

类型 | 描述  
---|---  
`datetime` |  前一交易日  
  
**示例：**
    
    
    print("previous trade date: ", self.pre_trade_date)
    

## 数据获取¶

###  symbols \- 获取当前标的列表.  `property` ¶
    
    
    symbols: list
    

**返回：**

类型 | 描述  
---|---  
`list[str]` |  当前标的列表.  
  
**示例：**

输入: 
    
    
    print("current symbols: ", self.symbols)
    

输出: 
    
    
    current symbols: ['SHSE.600000', 'SZSE.000001']
    

###  getdatas \- 获取前序data（数据滑窗） ¶
    
    
    getdatas(data, count, fields=None)
    

提示

  1. 需要在 [run](./#ait0.strategy.AICerebro.run) 接口配置 prefetch 参数，且prefetch需大于等于count
  2. 返回数据含当前数据

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  datafeed或者datafeed名称 |  _必需_  
`count` |  `int` |  数量 |  _必需_  
`fields` |  `str` |  数据列名 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`dict` |  数据字典  
  
**示例：**
    
    
    class MyStrategy(strategy.AIStrategy):
        def next(self, datas):
            for data in datas:
                close_data = self.getdatas(data, count=100, fields='close')['close']
                print(close_data)
    
    if __name__ == '__main__':
        cerebro = strategy.AICerebro()
        cerebro.addstrategy(MyStrategy)
        running_code = str(uuid.uuid4())
        result = cerebro.run(
            symbols=['SZSE.000333'],  # 设置回测的标的,必填.
            fromdate=datetime.datetime(2023, 3, 30, 8, 0, 0),  # 设置回测的开始时间,必填.
            todate=datetime.datetime(2023, 4, 3, 16, 0, 0),  # 设置回测的结束时间,必填.
            portfolio="cDcZ8czvX9pcvLGs",  # 设置投资组合的Token,必填.
            running_code=running_code,  # 设置批次号,可选填.
            strategy_code="AT2407051919240001",  # 设置策略编号,`必填`  .
            period="1d",  # k线周期,默认值为60s即1分钟线,回测1分钟线时可不填.
            initial_cash=500000,  # 设置回测初始资金.
            adjust=1,  # 前复权,默认值为不复权.
            run_mode=2,  # 回测模式,默认值为2,回测时可不填.
            prefetch=100,  # 数据滑窗最大预取数量
        )
    

###  getdatabyname \- 获取指定已订阅的datafeed对象 ¶
    
    
    getdatabyname(name, period=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`name` |  `str` |  datafeed的名称 |  _必需_  
`period` |  `str` |  周期,多周期时需要用到 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds` |  datafeed对象  
  
**示例：**
    
    
    data = self.getdatabyname(name='SHSE.600000')
    data1 = self.getdatabyname(name='SHSE.600000', period='60s')
    

###  get_security_info \- 获取商品信息 ¶
    
    
    get_security_info(code)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`code` |  `str` |  商品代码 |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`[Security](../strategy_structures/#ait0.utils.Security "ait0.utils.Security")` |  商品信息  
  
**示例：**
    
    
    info = self.get_security_info(code='SHSE.600000')
    

###  getcash \- 获取账号现金 ¶
    
    
    getcash(account=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`account` |  `str` |  `仿真/实盘` 账号。默认为第一个账号 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`float` |  金额  
  
**示例：**
    
    
    cash = self.getcash(account="as9982902")
    

###  getvalue \- 获取账号资产 ¶
    
    
    getvalue(account=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`account` |  `str` |  `仿真/实盘` 账号。默认为第一个账号 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`float` |  金额  
  
**示例：**
    
    
    nav = self.getvalue(account="as9982902")
    

###  getposition \- 获取持仓对象 ¶
    
    
    getposition(data=None, broker=None, pos_type='Long', account=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  datafeed或者datafeed名称。默认为第一个datafeed。 |  `None`  
`broker` |  `BackTestBroker | LiveBroker` |  broker对象。默认为已绑定的broker对象。 |  `None`  
`pos_type` |  `int` |  持仓类型。默认获取多头头寸,'Long'-多头头寸,'Short'-空头头寸. |  `'Long'`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`[AIPosition](../strategy_structures/#ait0.strategy.cnfposition.AIPosition "ait0.strategy.cnfposition.AIPosition")` |  持仓对象。详见 [AIPosition](../strategy_structures/#ait0.strategy.cnfposition.AIPosition)  
  
**示例：**
    
    
    pos = self.getposition(data, pos_type='Long')
    

###  getpositionbyname \- 获取持仓对象 ¶
    
    
    getpositionbyname(name=None, broker=None, pos_type='Long', account=None)
    

说明

等同于[getposition](./#ait0.strategy.AIStrategy.getposition)的data参数填datafeed名称。例如： getposition(data='SHSE.600000')

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`name` |  `str` |  datafeed的名字。默认为配置的第一个datafeed。 |  `None`  
`broker` |  `BackTestBroker | LiveBroker` |  broker对象。默认为配置的第一个broker对象。 |  `None`  
`pos_type` |  `str` |  持仓类型。默认获取多头头寸,'Long'-多头头寸,'Short'-空头头寸. |  `'Long'`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`[AIPosition](../strategy_structures/#ait0.strategy.cnfposition.AIPosition "ait0.strategy.cnfposition.AIPosition")` |  持仓对象。详见 [AIPosition](../strategy_structures/#ait0.strategy.cnfposition.AIPosition)  
  
**示例：**
    
    
    pos = self.getpositionbyname(name='SHSE.600000', pos_type='Long')
    

###  getpositions \- 获取账号持仓 ¶
    
    
    getpositions(broker=None, account=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`broker` |  `BackTestBroker | LiveBroker` |  broker对象。默认为配置的第一个broker对象。 |  `None`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[[AIPosition](../strategy_structures/#ait0.strategy.cnfposition.AIPosition "ait0.strategy.cnfposition.AIPosition")]` |  持仓对象列表。详见 [AIPosition](../strategy_structures/#ait0.strategy.cnfposition.AIPosition)  
  
**示例：**
    
    
    pos = self.getpositions(account='FF00301')
    

###  is_constituent \- 判断data对应的symbol是否属于指定指数的成分股. ¶
    
    
    is_constituent(index=None, data=None, trade_date=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`index` |  `str` |  指数代码. |  `None`  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  datafeed或者datafeed名称 |  `None`  
`trade_date` |  `datetime | str` |  交易日。若为None，则为当前交易日 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`bool` |  股票是否在指数的成分股中. True -- 在， False -- 不在  
  
###  current_constituent \- 获取当前有效的成分股 ¶
    
    
    current_constituent(trade_date=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_date` |  `datetime | str` |  交易日。若为None，则为当前交易日 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[str]` |  当前有效的成分股列表.  
  
**示例：**
    
    
    # 获取当前交易日的有效成分股
    self.current_constituent()
    
    # 获取指定交易日的有效成分股
    self.current_constituent(trade_date='2023-11-12')
    
    # 获取上一交易日的有效成分股
    self.current_constituent(trade_date=self.pre_trade_date)
    

###  user_load_data \- 读取用户数据 ¶
    
    
    user_load_data(key, defVal=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`key` |  `str` |  用户数据key |  _必需_  
`defVal` |  `any` |  任意类型，找不到key，返回defVal值，默认为None |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`any` |  返回key对应的值  
  
**示例：**
    
    
    key1 = self.user_load_data("key1", 0)
    key3 = self.user_load_data("key3",{})
    

###  user_save_data \- 保存用户数据 ¶
    
    
    user_save_data(key, val)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`key` |  `str` |  用户数据key |  _必需_  
`val` |  `any` |  任意类型，基础数据类型必须能够支持json |  _必需_  
  
**示例：**
    
    
    self.user_save_data("key1", 99)
    self.user_save_data("key2", "1d")
    self.user_save_data("key_map", {"fff":8,"yyy":10})
    

## 策略交易接口¶

###  buy \- 下买单. ¶
    
    
    buy(data, size=None, price=None, open_close_mode=1, account=None, order_style=1, **kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  标的对应的datafeed或者symbol

  * BarFeeds: 回测bar
  * TickFeeds: 回测tick
  * LiveBarFeeds: 仿真bar
  * LiveTickFeeds: 仿真tick
  * str: symbol

一般情况，data通过next参数传入。当data为str时会以data作为symbol查询对应的datafeed。 |  _必需_  
`size` |  `int` |  下单数量,若为None取sizer. 参考：cerebro.addsizer() |  `None`  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`open_close_mode` |  `int` |  开平方向,默认:1(开仓)。 1 -- 开仓, 2 -- 平仓, 3 -- 平今, 4 -- 平昨 |  `1`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
`order_style` |  `int` |  委托风格，默认：1(按指定量委托)。 1--按指定量委托，2--按指定价值委托，3--按指定比例委托，4--调仓到目标持仓量，5--调仓到目标持仓额，6--调仓到目标持仓比例 |  `1`  
  
**返回：**

类型 | 描述  
---|---  
`[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")` |  委托单据。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    # 按当前close价格买开1000
    order1 = self.buy(data, size=1000, price=data.close[0])
    
    # 按当前市价价格买开1000
    order2 = self.buy(data, size=1000)
    
    # 按当前市价价格买平1000
    order3 = self.buy(data, size=1000, open_close_mode=2)
    

###  sell \- 下卖单. ¶
    
    
    sell(data, size=None, price=None, open_close_mode=2, account=None, order_style=1, **kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  标的对应的datafeed或者symbol

  * BarFeeds: 回测bar
  * TickFeeds: 回测tick
  * LiveBarFeeds: 仿真bar
  * LiveTickFeeds: 仿真tick
  * str: symbol

一般情况，data通过next参数传入。当data为str时会以data作为symbol查询对应的datafeed。 |  _必需_  
`size` |  `int` |  下单数量,若为None取sizer. 参考：cerebro.addsizer() |  `None`  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`open_close_mode` |  `int` |  开平方向,默认: 2(平仓)。 1 -- 开仓, 2 -- 平仓, 3 -- 平今, 4 -- 平昨 |  `2`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
`order_style` |  `int` |  委托风格，默认：1(按指定量委托)。 1--按指定量委托，2--按指定价值委托，3--按指定比例委托，4--调仓到目标持仓量，5--调仓到目标持仓额，6--调仓到目标持仓比例 |  `1`  
  
**返回：**

类型 | 描述  
---|---  
`[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")` |  委托单据。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    # 按当前close价格卖平1000
    order1 = self.sell(data, size=1000, price=data.close[0])
    
    # 按当前市价价格卖平1000
    order2 = self.sell(data, size=1000)
    
    # 按当前市价价格卖开1000
    order3 = self.sell(data, size=1000, open_close_mode=1)
    

###  order_close \- 指定平仓 ¶
    
    
    order_close(data, price=None, account=None, **kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  标的对应的datafeed或者symbol

  * BarFeeds: 回测bar
  * TickFeeds: 回测tick
  * LiveBarFeeds: 仿真bar
  * LiveTickFeeds: 仿真tick
  * str: symbol

一般情况，data通过next参数传入。当data为str时会以data作为symbol查询对应的datafeed。 |  _必需_  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")]` |  委托对象列表  
  
**示例：**
    
    
    self.order_close(data, price=data.close[0], account='3ff0dada-d69f-11ec-b8b4-00163')
    

###  order_close_all \- 平当前所有可平持仓 ¶
    
    
    order_close_all(account=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")]` |  委托对象列表。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    self.order_close_all(account_no='3ff0dada-d69f-11ec-b8b4-00163')
    

###  cancel \- 撤单 ¶
    
    
    cancel(order)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`order` |  `Order` |  委托单对象, 调用buy, sell返回的对象，可能的类型是BuyOpenOrder、BuyCloseAIOrder、BuyCloseTdAIOrder、 BuyCloseYdAIOrder、SellOpenAIOrder、SellCloseAIOrder、SellCloseTdOrder或SellCloseYdOrder |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
**示例：**
    
    
    self.cancel(order)
    

###  cancel_all \- 撤销所有委托单据 ¶
    
    
    cancel_all(account_no=None, commodity_no=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`account_no` |  `str` |  交易账号， account_no为None时为策略的所有交易账号 |  `None`  
`commodity_no` |  `str` |  品种代码 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
**示例：**
    
    
    # 撤销所有账号的所有委托单据
    self.cancel_all()
    
    # 撤销指定账号委托单据
    self.cancel_all(account_no='3ff0dada-d69f-11ec-b8b4-00163')
    
    # 撤销指定账号和指定品种委托单据
    self.cancel_all(account_no='3ff0dada-d69f-11ec-b8b4-00163', commodity_no='HSI')
    

###  order_value \- 按金额下单 ¶
    
    
    order_value(value, data=None, side=None, price=None, open_close_mode=1, account=None, **kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`value` |  `float` |  下单金额 |  _必需_  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  datafeed或者datafeed名称 |  `None`  
`side` |  `int` |  委托方向, enum.OrderSide_Buy -- 买方向, enum.OrderSide_Sell -- 卖方向. |  `None`  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`open_close_mode` |  `int` |  开平方向,默认是开仓,1->开仓,2-平仓,3-平今,4-平昨 |  `1`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")` |  委托单据。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    ord = self.order_value(value=100000.00, data=data, side=enum.OrderSide_Buy)
    

###  order_target_value \- 调仓到目标持仓额 ¶
    
    
    order_target_value(data=None, target=0.0, price=None, pos_type='Long', account=None, **kwargs)
    

注意

若有反方向持仓会全平掉

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  标的对应的datafeed或者symbol

  * BarFeeds: 回测bar
  * TickFeeds: 回测tick
  * LiveBarFeeds: 仿真bar
  * LiveTickFeeds: 仿真tick
  * str: symbol

一般情况，data通过next参数传入。当data为str时会以data作为symbol查询对应的datafeed。 |  `None`  
`target` |  `float` |  期望的目标持仓额. |  `0.0`  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`pos_type` |  `str` |  默认针对多头调仓,'Long'-多头头寸,'Short'-空头头寸. |  `'Long'`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")]` |  委托对象列表。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    orders = self.order_target_value(data, target=15000.00, price=data.close[0])
    

###  order_target_size \- 调仓到目标持仓量 ¶
    
    
    order_target_size(data, target=0, price=None, pos_type='Long', account=None, **kwargs)
    

注意

若有反方向持仓会全平掉

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  标的对应的datafeed或者symbol

  * BarFeeds: 回测bar
  * TickFeeds: 回测tick
  * LiveBarFeeds: 仿真bar
  * LiveTickFeeds: 仿真tick
  * str: symbol

一般情况，data通过next参数传入。当data为str时会以data作为symbol查询对应的datafeed。 |  _必需_  
`target` |  `int` |  期望的最终数量. |  `0`  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`pos_type` |  `str` |  默认针对多头调仓,'Long'-多头头寸,'Short'-空头头寸. |  `'Long'`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")]` |  委托对象列表。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    orders = self.order_target_size(data, target=10000, price=data.close[0])
    

###  order_target_weight \- 调仓到目标持仓比例 ¶
    
    
    order_target_weight(data, weight=0.0, price=None, pos_type='Long', account=None, **kwargs)
    

说明

按权重下单，总资产的比例

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  标的对应的datafeed或者symbol

  * BarFeeds: 回测bar
  * TickFeeds: 回测tick
  * LiveBarFeeds: 仿真bar
  * LiveTickFeeds: 仿真tick
  * str: symbol

一般情况，data通过next参数传入。当data为str时会以data作为symbol查询对应的datafeed。 |  _必需_  
`weight` |  `float` |  期望的最终占总资产比例. 如10%则填0.1 |  `0.0`  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`pos_type` |  `str` |  默认针对多头调仓,'Long'-多头头寸,'Short'-空头头寸. |  `'Long'`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")]` |  委托对象列表。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    orders = self.order_target_weight(data, weight=0.2, price=data.close[0])
    

###  order_target_percent \- 调仓到目标持仓比例 ¶
    
    
    order_target_percent(data, target=0.0, price=None, pos_type='Long', account=None, **kwargs)
    

说明

按权重下单，总资产的比例。详见 [order_target_weight](./#ait0.strategy.AIStrategy.order_target_weight)

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds | str` |  标的对应的datafeed或者symbol

  * BarFeeds: 回测bar
  * TickFeeds: 回测tick
  * LiveBarFeeds: 仿真bar
  * LiveTickFeeds: 仿真tick
  * str: symbol

一般情况，data通过next参数传入。当data为str时会以data作为symbol查询对应的datafeed。 |  _必需_  
`target` |  `float` |  期望的最终占总资产比例. 如10%则填0.1 |  `0.0`  
`price` |  `float` |  价格,若为None为市价单. |  `None`  
`pos_type` |  `str` |  默认针对多头调仓,'Long'-多头头寸,'Short'-空头头寸. |  `'Long'`  
`account` |  `str` |  交易账号。默认为配置的第一个账号。仿真交易或实盘交易时有效。 |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`list[[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")]` |  委托对象列表。详见 [AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder)  
  
**示例：**
    
    
    orders = self.order_target_percent(data, target=0.2, price=data.close[0])
    

## 事件通知¶

###  next_data \- 行情回调通知 ¶
    
    
    next_data(datas)
    

说明

同 next(datas)

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`datas` |  `list[BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds]` |  行情datafeed列表

  * [BarFeeds](../strategy_structures/#ait0.quote.barfeeds.BarFeeds): 回测bar
  * [TickFeeds](../strategy_structures/#ait0.quote.tickfeeds.TickFeeds): 回测tick
  * [LiveBarFeeds](../strategy_structures/#ait0.quote.livetickfeeds.LiveBarFeeds): 仿真bar
  * [LiveTickFeeds](../strategy_structures/#ait0.quote.livetickfeeds.LiveTickFeeds): 仿真tick

|  _必需_  
  
**示例：**
    
    
    ...
    class MyStrategy(strategy.AIStrategy):
        def next_data(self, datas):
            for data in datas:
                print(data.p.symbol, data.close[0])
    
    
    
    ...
    class MyStrategy(strategy.AIStrategy):
        def next(self, datas):
            for data in datas:
                print(data.p.symbol, data.close[0])
    

###  notify_trade \- 成交回调通知 ¶
    
    
    notify_trade(trade)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade` |  `[AITrade](../strategy_structures/#ait0.strategy.aitrade.AITrade "ait0.strategy.aitrade.AITrade")` |  成交对象 |  _必需_  
  
**示例：**
    
    
    ...
    class MyStrategy(strategy.AIStrategy):
        def notify_trade(self, trade):
            print(trade)
    

###  notify_order \- 订单通知回调 ¶
    
    
    notify_order(order)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`order` |  `[AIOrder](../strategy_structures/#ait0.strategy.cnforder.AIOrder "ait0.strategy.cnforder.AIOrder")` |  订单对象 |  _必需_  
  
**示例：**
    
    
    ...
    class MyStrategy(strategy.AIStrategy):
        def notify_order(self, order):
            print(order)
    

###  notify_data \- 单个行情到达通知 ¶
    
    
    notify_data(data, status, *args, **kwargs)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`data` |  `BarFeeds | TickFeeds | LiveBarFeeds | LiveTickFeeds` |  单个行情datafeed |  _必需_  
`status` |  `int` |  状态 0 - CONNECTED, 1 - DISCONNECTED, 2 - CONNBROKEN, 3 - DELAYED, 4 - LIVE, 5 - NOTSUBSCRIBED, 6 - NOTSUPPORTED_TF, 7 - UNKNOWN |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
**示例：**
    
    
    ...
    class MyStrategy(strategy.AIStrategy):
        def notify_data(self, data, status):
            print(f"data={data}, status={status}")
    

###  stop \- 回测结束通知 ¶
    
    
    stop()
    

**返回：**

类型 | 描述  
---|---  
`None` |  无  
  
**示例：**
    
    
    ...
    class MyStrategy(strategy.AIStrategy):
        def stop(self):
            print("回测结束")
    

## 获取票池¶

###  Group \- 选股部分的基类 ¶

Bases: `with_metaclass(MetaParams, object)`

提示

属性值的修改需在继承父类时用params进行覆盖默认值, 例如： 
    
    
    class HS300Group(strategy.Group):
        params = (
            ('portfolio', 'hxiE31AB54'),
        )
    

**属性：**

名称 | 类型 | 描述  
---|---|---  
`portfolio` |  `str` |  投资组合的密钥,密钥由投资组合管理员负责管理.  
`fromdate` |  `datetime` |  回测开始时间,datetime对象.  
`todate` |  `datetime` |  回测结束时间,datetime对象.  
`exchange_trade_date` |  `str` |  交易所代码,基于该交易所获取交易日历.  
`group_code` |  `str` |  票池代码,若有值会把票池推送到服务.  
`run_step` |  `int` |  运行模式,1-只运行选股部分.  
`serv_addr` |  `str` |  ait0 网关服务地址  
`run_mode` |  `int` |  策略运行模式,1-表示仿真/实盘,2-表示回测.  
  
**示例：**
    
    
    class HS300Group(ait0.strategy.Group):
        ## 自定义沪深300票池
        def next(self, trade_date: datetime.datetime) -> list:
            now = str(trade_date.date())
            last_date = ait0.get_previous_trading_date(now)
            stock300 = ait0.get_index_constituents(index=EnhancedIndexing.params.index_symbol, trade_date=last_date)
            return stock300.symbol.to_list()
    
    if __name__ == '__main__':
        cerebro = ait0.strategy.AICerebro()
        cerebro.addgroup(HS300Group)  # 添加票池
        ......
    

####  next \- 按交易日迭代 ¶
    
    
    next(trade_date)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_date` |  `datetime` |  交易日 |  _必需_  
  
####  next_range \- 按多个日期迭代 ¶
    
    
    next_range(trade_dates)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`trade_dates` |  `list[datetime]` |  交易日列表 |  _必需_  
  
####  run \- 执行 ¶
    
    
    run()
    

## 辅助接口¶

###  log \- 打印日志 ¶
    
    
    log(content, log_level='info')
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`content` |  `str` |  日志内容 |  _必需_  
`log_level` |  `datetime` |  日志等级，默认'info' |  `'info'`  
  
**示例：**
    
    
    ...
    class MyStrategy(strategy.AIStrategy):
        params = (
            ('file_log', True),  # 是否写文件开关，必须设置为True.
        )
    
        def next(self, datas):
            for data in datas:
                self.log(f"symbol={data.p.symbol}")
    ...
    
