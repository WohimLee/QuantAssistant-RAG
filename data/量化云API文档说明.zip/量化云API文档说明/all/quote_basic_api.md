---
# Converted from: quote_basic_api\index.html
---

# 通用数据函数¶

##  filter_stock \- 过滤股票. ¶
    
    
    filter_stock(symbols=None, trade_date=None, exchanges=None, st=0, suspended=0, gem=0, science=0, delisted=0, next_new=0, delisted_arrange=0)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list[str]` |  str(多个以逗号分隔)/list,选填,股票列表. symbols和exchanges至少必填一个 |  `None`  
`trade_date` |  `str` |  选填,交易日(格式为yyyy-mm-dd),默认为当前时间最近的交易日. |  `None`  
`exchanges` |  `str` |  (多个以逗号分隔),选填,交易所列表. symbols和exchanges至少必填一个 |  `None`  
`st` |  `int` |  0-不过滤st股票,1-过滤. |  `0`  
`suspended` |  `int` |  0-不过滤停牌股票,1-过滤. |  `0`  
`gem` |  `int` |  0-不过滤创业板股票,1-过滤. |  `0`  
`science` |  `int` |  0-不过滤科创板股票,1-过滤. |  `0`  
`delisted` |  `int` |  0-不过滤退市股票,1-过滤. |  `0`  
`next_new` |  `int` |  0-不过滤次新股股票,1-过滤. |  `0`  
`delisted_arrange` |  `int` |  0-不过滤退市整理股票,1-过滤. |  `0`  
  
**返回：**

类型 | 描述  
---|---  
`list` |  过滤后的股票列表  
  
**示例：**

  * Input: 
        
        import ait0
        
        ait0.set_api_key('QlaE6FGfdiKmIgEyLz9l')
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        datas = ait0.filter_stock(symbols=['SHSE.600070', 'SHSE.600078', 'SHSE.600112', 'SHSE.600117', 'SZSE.000001', 'SHSE.600000'],trade_date='2023-11-03')
        print(datas)
        

  * Output: 
        
        ['SHSE.600000', 'SZSE.000001']
        

##  fut_get_continuous_contracts \- 获取连续合约对应的真实合约 ¶
    
    
    fut_get_continuous_contracts(symbol, start_date=None, end_date=None, is_handle=False)
    

说明

暂支持国内期货交易所品种（[国内交易所：`CFFEX`, `SHFE`, `DCE`, `CZCE`, `INE`](../strategy_variables/)）

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  单个合约. |  _必需_  
`start_date` |  `str | date` |  str或datetime.date,开始时间,大于等于from_date的数据 |  `None`  
`end_date` |  `str | date` |  str或datetime.date,结束时间,小于等于to_date的数据 |  `None`  
`is_handle` |  `bool` |  False-返回数据不做处理，True-返回数据，发现是该真实合约最后交易日，返回下一个交易日的真实品种 |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  合约  
`trade_date` |  `str` |  交易日  
`csymbol` |  `str` |  主合约  
`cname` |  `str` |  主合约名字  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        df = ait0.fut_get_continuous_contracts(symbol='SHFE.NImain',start_date="2023-11-11", end_date="2023-12-11")
        print(df)
        

  * Output: 
        
        symbol  trade_date      csymbol cname
        0   SHFE.ni2312  2023-11-13  SHFE.nimain  None
        1   SHFE.ni2312  2023-11-14  SHFE.nimain  None
        2   SHFE.ni2312  2023-11-15  SHFE.nimain  None
        3   SHFE.ni2312  2023-11-16  SHFE.nimain  None
        4   SHFE.ni2312  2023-11-17  SHFE.nimain  None
        5   SHFE.ni2312  2023-11-20  SHFE.nimain  None
        6   SHFE.ni2312  2023-11-21  SHFE.nimain  None
        7   SHFE.ni2312  2023-11-22  SHFE.nimain  None
        8   SHFE.ni2312  2023-11-23  SHFE.nimain  None
        9   SHFE.ni2312  2023-11-24  SHFE.nimain  None
        10  SHFE.ni2401  2023-11-27  SHFE.nimain  None
        11  SHFE.ni2401  2023-11-28  SHFE.nimain  None
        12  SHFE.ni2401  2023-11-29  SHFE.nimain  None
        13  SHFE.ni2401  2023-11-30  SHFE.nimain  None
        14  SHFE.ni2401  2023-12-01  SHFE.nimain  None
        15  SHFE.ni2401  2023-12-04  SHFE.nimain  None
        16  SHFE.ni2401  2023-12-05  SHFE.nimain  None
        17  SHFE.ni2401  2023-12-06  SHFE.nimain  None
        18  SHFE.ni2401  2023-12-07  SHFE.nimain  None
        19  SHFE.ni2401  2023-12-08  SHFE.nimain  None
        20  SHFE.ni2401  2023-12-11  SHFE.nimain  None
        

##  get_all_securities \- 获取平台支持的所有股票、基金、指数、期货信息 ¶
    
    
    get_all_securities(types=None, exchange_code=None, symbols=None, trade_date=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`types` |  `list` |  用来过滤securities的类型，list元素可选: ‘stock’, 'futures', 'index', 'fund', 'bond'. types为空时返回所有股票,目前仅支持股票/期货/指数/基金/债券. |  `None`  
`exchange_code` |  `str | list[str]` |  交易所代码列表，支持list[str]/str，str时多个以逗号分隔. |  `None`  
`symbols` |  `str | list[str]` |  代码列表，支持list[str]/str，str时多个以逗号分隔. |  `None`  
`trade_date` |  `str | datetime | date` |  交易日期，一个字符串或者 datetime.datetime/datetime.date 对象，用于获取某日期还在上市的股票信息. 默认值为 None，表示获取所有日期的股票信息 |  `None`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`display_name` |  `str` |  品种名字  
`name` |  `str` |  名字  
`start_date` |  `str` |  开始日期 (%Y-%m-%d)  
`end_date` |  `str` |  开始日期 (%Y-%m-%d)  
`type` |  `str` |  类型。'stock'--股票, 'futures'--期货, 'index'--指数  
`contract_size` |  `int` |  合约乘数  
`exchange_code` |  `str` |  交易所代码  
`commodity_no` |  `str` |  品种代码  
`lot_min` |  `int` |  每手最少数量  
`lot_step` |  `int` |  数量步长  
`commodity_tick_size` |  `int` |  最小跳动单位  
`trade_n` |  `int` |  交易制度, 0 表示 T+0，1 表示 T+1，2 表示 T+2  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        df = ait0.get_all_securities(types=['stock'], exchange_code='SHSE', trade_date='2023-10-11')
        print(df)
        

  * Output: 
        
        display_name    name start_date   end_date   type contract_size exchange_code commodity_no  lot_min  lot_step commodity_tick_size
        symbol
        SHSE.600000         浦发银行  600000 1999-11-10 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.600004         白云机场  600004 2003-04-28 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.600006         东风汽车  600006 1999-07-27 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.600007         中国国贸  600007 1999-03-12 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.600008         首创环保  600008 2000-04-27 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        ...                  ...     ...        ...        ...    ...           ...           ...          ...      ...       ...                 ...
        SHSE.900947         振华B股  900947 1997-08-05 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.900948         伊泰B股  900948 1997-08-08 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.900952         锦港B股  900952 1998-05-19 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.900953          凯马B  900953 1998-06-24 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        SHSE.900957         凌云B股  900957 2000-07-28 2038-01-01  stock      1.000000          SHSE           SH      100       100                0.01
        
        [2289 rows x 11 columns]
        

##  get_security_info \- 获取股票/基金/指数的信息  `cached` ¶
    
    
    get_security_info(code, trade_date=None, df=False)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`code` |  `str` |  证券代码 |  _必需_  
`trade_date` |  `str | datetime | date` |  查询交易日期: 日期字符串/date对象/datetime对象, 注意传入datetime对象时忽略日内时间 |  `None`  
`df` |  `bool` |  默认为False - 返回Security实例，df=True则返回DataFrame |  `False`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`symbol` |  `str` |  商品代码  
`contract_no` |  `str` |  合约编号  
`exchange_code` |  `str` |  交易所代码  
`exchange_area` |  `str` |  地区缩写  
`exchange_name` |  `str` |  交易所名称  
`commodity_no` |  `str` |  品种代码  
`commodity_name` |  `str` |  品种名称  
`commodity_tick_size` |  `float` |  最小变动单位  
`contract_name` |  `str` |  合约名称  
`contract_size` |  `float` |  合约乘数  
`last_trade_date` |  `str` |  最后交易日  
`is_main` |  `int` |  是否主力, 1:是 0:否  
`extension` |  `str` |  备注  
`digits` |  `int` |  小数点数  
`currency_no` |  `str` |  货币类型  
`commodity_type` |  `int` |  品种类型  
`origin_symbol` |  `str` |  不含交易所前辍  
`data_source` |  `str` |  源  
`status` |  `int` |  合约状态 0:不过期 1:过期  
`contract_type` |  `int` |  合约类型 70:期货，84:股票  
`first_trade_date` |  `str` |  上市日  
`trade_time` |  `str` |  交易时间段  
`lot_min` |  `int` |  最小下单量。期货为手，股票为股。例如：普通A股为100，创业板为200  
`lot_step` |  `int` |  步长。期货为手，股票为股。例如：普通A股为100，创业板为1（需超过200后）  
`trade_n` |  `int` |  交易制度,0 表示 T+0，1 表示 T+1，2 表示 T+2  
  
**示例：**

  * Input: 
        
        import pandas as pd
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        pd.set_option('display.max_columns', None)
        data = ait0.get_security_info(code='SHSE_600008', trade_date='2023-10-11',df=True)
        print(data)
        

  * Output: 
        
        symbol contract_no exchange_code exchange_area exchange_name  \
              0  SHSE_600008      600008          SHSE            CN           上交所
        
                  commodity_no commodity_name commodity_tick_size contract_name contract_size  \
              0           SH             SH                0.01          首创环保      1.000000
        
                  last_trade_date is_main extension  digits currency_no  commodity_type  \
              0      2038-01-01       1                 2         CNY              84
        
                  origin_symbol data_source  status  contract_type first_trade_date  \
              0        600008          GM       0             84       2000-04-27
        
                                trade_time  lot_min  lot_step
              0  09:30-11:30|13:00-15:00      100       100
        
        [1 rows x 24 columns]
        

##  get_fundamentals \- 查询基础数据  `cached` ¶
    
    
    get_fundamentals(table, fields=None, filter=None, order_by=None, limit=1000, source='wind', df=False)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`table` |  `str` |  表名，只支持单表查询. 具体表名及fields字段名及filter可过滤的字段参考 财务数据文档 |  _必需_  
`fields` |  `str` |  查询字段 |  `None`  
`filter` |  `str` |  查询过滤,使用方法参考例3、例4 |  `None`  
`order_by` |  `str` |  排序方式, 默认 None. 排序字段, 逗号隔开, 默认升序, 在字段名前加"-"表示反降序, 如 tradeDate 升序 -tradeDate 降序 |  `None`  
`limit` |  `int` |  数量. 默认是1000, 为保护服务器, 单次查询最多返回 40000 条记录 |  `1000`  
`source` |  `str` |  数据来源,目前支持的来源有wind/tushare/gm |  `'wind'`  
`df` |  `bool` |  默认为False - 返回list[dict]，df=True则返回DataFrame |  `False`  
  
**返回：**

类型 | 描述  
---|---  
`DataFrame` |  DataFrame  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        datas = ait0.get_fundamentals(table='stkdes',  filter='trade_date="2023-04-26"',source='tushare', df=True)
        print(datas)
        

  * Output: 
        
        AUTOID delist_date   list_date      name  trade_date       symbol
        0         1  2042-06-26  1991-04-03      平安银行  2023-04-26  SZSE.000001
        1         2  2042-06-26  1991-01-29       万科A  2023-04-26  SZSE.000002
        2         3  2002-06-14  1991-07-03  PT金田A(退)  2023-04-26  SZSE.000003
        3         4  2042-06-26  1991-01-14      ST国华  2023-04-26  SZSE.000004
        4         5  2042-06-26  1990-12-10      ST星源  2023-04-26  SZSE.000005
        ..      ...         ...         ...       ...         ...          ...
        995     996  2042-06-26  2010-05-28      雷科防务  2023-04-26  SZSE.002413
        996     997  2042-06-26  2010-07-16      高德红外  2023-04-26  SZSE.002414
        997     998  2042-06-26  2010-05-28      海康威视  2023-04-26  SZSE.002415
        998     999  2042-06-26  2010-05-28       爱施德  2023-04-26  SZSE.002416
        999    1000  2042-06-26  2010-06-01     *ST深南  2023-04-26  SZSE.002417
        
        [1000 rows x 6 columns]
        

##  get_group_detail \- 按照分组查询股票列表 ¶
    
    
    get_group_detail(gem=0, science=0)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`gem` |  `int` |  0-不查询创业板股票,1-查询. |  `0`  
`science` |  `int` |  0-不查询科创板股票,1-查询. |  `0`  
  
**返回：**

类型 | 描述  
---|---  
`list` |  list,股票列表  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        datas = ait0.get_group_detail(gem=1)
        print(datas)
        

  * Output: 
        
        ['SZSE.300001', 'SZSE.300002', 'SZSE.300003', 'SZSE.300004', 'SZSE.300005', 'SZSE.300006', 'SZSE.300007', 'SZSE.300008', 'SZSE.300009', 'SZSE.300010', 'SZSE.300011', 'SZSE.300012', 'SZSE.300013', 'SZSE.300014', 'SZSE.300015', 'SZSE.300016', 'SZSE.300017', 'SZSE.300018', 'SZSE.300019', 'SZSE.300020', 'SZSE.300021', 'SZSE.300022', 'SZSE.300024', 'SZSE.300025', 'SZSE.300026', 'SZSE.300027', 'SZSE.300028', 'SZSE.300029', 'SZSE.300030', 'SZSE.300031', 'SZSE.300032', 'SZSE.300033', 'SZSE.300034', 'SZSE.300035', 'SZSE.300036', 'SZSE.300037', 'SZSE.300039', 'SZSE.300040', 'SZSE.300041', 'SZSE.300042', 'SZSE.300043', 'SZSE.300044', 'SZSE.300045', 'SZSE.300046', 'SZSE.300047', 'SZSE.300048', 'SZSE.300049', 'SZSE.300050', 'SZSE.300051', 'SZSE.300052', 'SZSE.300053', 'SZSE.300054', 'SZSE.300055', 'SZSE.300056', 'SZSE.300057', 'SZSE.300058', 'SZSE.300059', 'SZSE.300061', 'SZSE.300062', 'SZSE.300063', 'SZSE.300065', 'SZSE.300066', 'SZSE.300067', 'SZSE.300068', 'SZSE.300069', 'SZSE.300070', 'SZSE.300071', 'SZSE.300072', 'SZSE.300073', 'SZSE.300074', 'SZSE.300075', 'SZSE.300076', 'SZSE.300077', 'SZSE.300078', 'SZSE.300079', 'SZSE.300080', 'SZSE.300081', 'SZSE.300082', 'SZSE.300083', 'SZSE.300084', 'SZSE.300085', 'SZSE.300086', 'SZSE.300087', 'SZSE.300088', 'SZSE.300090', 'SZSE.300091', 'SZSE.300092', 'SZSE.300093', 'SZSE.300094', 'SZSE.300095', 'SZSE.300096', 'SZSE.300097', 'SZSE.300098', 'SZSE.300099', 'SZSE.300100', 'SZSE.300101', 'SZSE.300102', 'SZSE.300103', 'SZSE.300104', 'SZSE.300105', 'SZSE.300106', 'SZSE.300107', 'SZSE.300108', 'SZSE.300109', 'SZSE.300110', 'SZSE.300111', 'SZSE.300112', 'SZSE.300113', 'SZSE.300114', 'SZSE.300115', 'SZSE.300116', 'SZSE.300117', 'SZSE.300118', 'SZSE.300119', 'SZSE.300120', 'SZSE.300121', 'SZSE.300122', 'SZSE.300123', 'SZSE.300124', 'SZSE.300125', 'SZSE.300126', 'SZSE.300127', 'SZSE.300128', 'SZSE.300129', 'SZSE.300130', 'SZSE.300131', 'SZSE.300132', 'SZSE.300133', 'SZSE.300134', 'SZSE.300135', 'SZSE.300136', 'SZSE.300137', 'SZSE.300138', 'SZSE.300139', 'SZSE.300140', 'SZSE.300141', 'SZSE.300142', 'SZSE.300143', 'SZSE.300144', 'SZSE.300145', 'SZSE.300146', 'SZSE.300147', 'SZSE.300148', 'SZSE.300149', 'SZSE.300150', 'SZSE.300151', 'SZSE.300152', 'SZSE.300153', 'SZSE.300154', 'SZSE.300155', 'SZSE.300156', 'SZSE.300157', 'SZSE.300158', 'SZSE.300159', 'SZSE.300160', 'SZSE.300161', 'SZSE.300162', 'SZSE.300163', 'SZSE.300164', 'SZSE.300165', 'SZSE.300166', 'SZSE.300167', 'SZSE.300168', 'SZSE.300169', 'SZSE.300170', 'SZSE.300171', 'SZSE.300172', 'SZSE.300173', 'SZSE.300174', 'SZSE.300175', 'SZSE.300176', 'SZSE.300177', 'SZSE.300179', 'SZSE.300180', 'SZSE.300181', 'SZSE.300182', 'SZSE.300183', 'SZSE.300184', 'SZSE.300185', 'SZSE.300187', 'SZSE.300188', 'SZSE.300189', 'SZSE.300190', 'SZSE.300191', 'SZSE.300192', 'SZSE.300193', 'SZSE.300194', 'SZSE.300195', 'SZSE.300196', 'SZSE.300197', 'SZSE.300198', 'SZSE.300199', 'SZSE.300200', 'SZSE.300201', 'SZSE.300203', 'SZSE.300204', 'SZSE.300205', 'SZSE.300206', 'SZSE.300207', 'SZSE.300208', 'SZSE.300209', 'SZSE.300210', 'SZSE.300211', 'SZSE.300212', 'SZSE.300213', 'SZSE.300214', 'SZSE.300215', 'SZSE.300216', 'SZSE.300217', 'SZSE.300218', 'SZSE.300219', 'SZSE.300220', 'SZSE.300221', 'SZSE.300222', 'SZSE.300223', 'SZSE.300224', 'SZSE.300225', 'SZSE.300226', 'SZSE.300227', 'SZSE.300228', 'SZSE.300229', 'SZSE.300230', 'SZSE.300231', 'SZSE.300232', 'SZSE.300233', 'SZSE.300234', 'SZSE.300235', 'SZSE.300236', 'SZSE.300237', 'SZSE.300238', 'SZSE.300239', 'SZSE.300240', 'SZSE.300241', 'SZSE.300242', 'SZSE.300243', 'SZSE.300244', 'SZSE.300245', 'SZSE.300246', 'SZSE.300247', 'SZSE.300248', 'SZSE.300249', 'SZSE.300250', 'SZSE.300251', 'SZSE.300252', 'SZSE.300253', 'SZSE.300254', 'SZSE.300255', 'SZSE.300256', 'SZSE.300257', 'SZSE.300258', 'SZSE.300259', 'SZSE.300260', 'SZSE.300261', 'SZSE.300262', 'SZSE.300263', 'SZSE.300264', 'SZSE.300265', 'SZSE.300266', 'SZSE.300267', 'SZSE.300268', 'SZSE.300269', 'SZSE.300270', 'SZSE.300271', 'SZSE.300272', 'SZSE.300274', 'SZSE.300275', 'SZSE.300276', 'SZSE.300277', 'SZSE.300278', 'SZSE.300279', 'SZSE.300280', 'SZSE.300281', 'SZSE.300282', 'SZSE.300283', 'SZSE.300284', 'SZSE.300285', 'SZSE.300286', 'SZSE.300287', 'SZSE.300288', 'SZSE.300289', 'SZSE.300290', 'SZSE.300291', 'SZSE.300292', 'SZSE.300293', 'SZSE.300294', 'SZSE.300295', 'SZSE.300296', 'SZSE.300298', 'SZSE.300299', 'SZSE.300300', 'SZSE.300301', 'SZSE.300302', 'SZSE.300303', 'SZSE.300304', 'SZSE.300305', 'SZSE.300306', 'SZSE.300307', 'SZSE.300308', 'SZSE.300310', 'SZSE.300311', 'SZSE.300313', 'SZSE.300314', 'SZSE.300315', 'SZSE.300316', 'SZSE.300317', 'SZSE.300318', 'SZSE.300319', 'SZSE.300320', 'SZSE.300321', 'SZSE.300322', 'SZSE.300323', 'SZSE.300324', 'SZSE.300326', 'SZSE.300327', 'SZSE.300328', 'SZSE.300329', 'SZSE.300331', 'SZSE.300332', 'SZSE.300333', 'SZSE.300334', 'SZSE.300335', 'SZSE.300337', 'SZSE.300338', 'SZSE.300339', 'SZSE.300340', 'SZSE.300341', 'SZSE.300342', 'SZSE.300343', 'SZSE.300344', 'SZSE.300345', 'SZSE.300346', 'SZSE.300347', 'SZSE.300348', 'SZSE.300349', 'SZSE.300350', 'SZSE.300351', 'SZSE.300352', 'SZSE.300353', 'SZSE.300354', 'SZSE.300355', 'SZSE.300357', 'SZSE.300358', 'SZSE.300359', 'SZSE.300360', 'SZSE.300363', 'SZSE.300364', 'SZSE.300365', 'SZSE.300366', 'SZSE.300368', 'SZSE.300369', 'SZSE.300370', 'SZSE.300371', 'SZSE.300373', 'SZSE.300374', 'SZSE.300375', 'SZSE.300376', 'SZSE.300377', 'SZSE.300378', 'SZSE.300379', 'SZSE.300380', 'SZSE.300381', 'SZSE.300382', 'SZSE.300383', 'SZSE.300384', 'SZSE.300385', 'SZSE.300386', 'SZSE.300387', 'SZSE.300388', 'SZSE.300389', 'SZSE.300390', 'SZSE.300391', 'SZSE.300393', 'SZSE.300394', 'SZSE.300395', 'SZSE.300396', 'SZSE.300397', 'SZSE.300398', 'SZSE.300399', 'SZSE.300400', 'SZSE.300401', 'SZSE.300402', 'SZSE.300403', 'SZSE.300404', 'SZSE.300405', 'SZSE.300406', 'SZSE.300407', 'SZSE.300408', 'SZSE.300409', 'SZSE.300410', 'SZSE.300411', 'SZSE.300412', 'SZSE.300413', 'SZSE.300414', 'SZSE.300415', 'SZSE.300416', 'SZSE.300417', 'SZSE.300418', 'SZSE.300419', 'SZSE.300420', 'SZSE.300421', 'SZSE.300422', 'SZSE.300423', 'SZSE.300424', 'SZSE.300425', 'SZSE.300426', 'SZSE.300427', 'SZSE.300428', 'SZSE.300429', 'SZSE.300430', 'SZSE.300431', 'SZSE.300432', 'SZSE.300433', 'SZSE.300434', 'SZSE.300435', 'SZSE.300436', 'SZSE.300437', 'SZSE.300438', 'SZSE.300439', 'SZSE.300440', 'SZSE.300441', 'SZSE.300442', 'SZSE.300443', 'SZSE.300444', 'SZSE.300445', 'SZSE.300446', 'SZSE.300447', 'SZSE.300448', 'SZSE.300449', 'SZSE.300450', 'SZSE.300451', 'SZSE.300452', 'SZSE.300453', 'SZSE.300454', 'SZSE.300455', 'SZSE.300456', 'SZSE.300457', 'SZSE.300458', 'SZSE.300459', 'SZSE.300460', 'SZSE.300461', 'SZSE.300462', 'SZSE.300463', 'SZSE.300464', 'SZSE.300465', 'SZSE.300466', 'SZSE.300467', 'SZSE.300468', 'SZSE.300469', 'SZSE.300470', 'SZSE.300471', 'SZSE.300472', 'SZSE.300473', 'SZSE.300474', 'SZSE.300475', 'SZSE.300476', 'SZSE.300477', 'SZSE.300478', 'SZSE.300479', 'SZSE.300480', 'SZSE.300481', 'SZSE.300482', 'SZSE.300483', 'SZSE.300484', 'SZSE.300485', 'SZSE.300486', 'SZSE.300487', 'SZSE.300488', 'SZSE.300489', 'SZSE.300490', 'SZSE.300491', 'SZSE.300492', 'SZSE.300493', 'SZSE.300494', 'SZSE.300495', 'SZSE.300496', 'SZSE.300497', 'SZSE.300498', 'SZSE.300499', 'SZSE.300500', 'SZSE.300501', 'SZSE.300502', 'SZSE.300503', 'SZSE.300504', 'SZSE.300505', 'SZSE.300506', 'SZSE.300507', 'SZSE.300508', 'SZSE.300509', 'SZSE.300510', 'SZSE.300511', 'SZSE.300512', 'SZSE.300513', 'SZSE.300514', 'SZSE.300515', 'SZSE.300516', 'SZSE.300517', 'SZSE.300518', 'SZSE.300519', 'SZSE.300520', 'SZSE.300521', 'SZSE.300522', 'SZSE.300523', 'SZSE.300525', 'SZSE.300527', 'SZSE.300528', 'SZSE.300529', 'SZSE.300530', 'SZSE.300531', 'SZSE.300532', 'SZSE.300533', 'SZSE.300534', 'SZSE.300535', 'SZSE.300536', 'SZSE.300537', 'SZSE.300538', 'SZSE.300539', 'SZSE.300540', 'SZSE.300541', 'SZSE.300542', 'SZSE.300543', 'SZSE.300545', 'SZSE.300546', 'SZSE.300547', 'SZSE.300548', 'SZSE.300549', 'SZSE.300550', 'SZSE.300551', 'SZSE.300552', 'SZSE.300553', 'SZSE.300554', 'SZSE.300555', 'SZSE.300556', 'SZSE.300557', 'SZSE.300558', 'SZSE.300559', 'SZSE.300560', 'SZSE.300561', 'SZSE.300562', 'SZSE.300563', 'SZSE.300564', 'SZSE.300565', 'SZSE.300566', 'SZSE.300567', 'SZSE.300568', 'SZSE.300569', 'SZSE.300570', 'SZSE.300571', 'SZSE.300572', 'SZSE.300573', 'SZSE.300575', 'SZSE.300576', 'SZSE.300577', 'SZSE.300578', 'SZSE.300579', 'SZSE.300580', 'SZSE.300581', 'SZSE.300582', 'SZSE.300583', 'SZSE.300584', 'SZSE.300585', 'SZSE.300586', 'SZSE.300587', 'SZSE.300588', 'SZSE.300589', 'SZSE.300590', 'SZSE.300591', 'SZSE.300592', 'SZSE.300593', 'SZSE.300594', 'SZSE.300595', 'SZSE.300596', 'SZSE.300597', 'SZSE.300598', 'SZSE.300599', 'SZSE.300600', 'SZSE.300601', 'SZSE.300602', 'SZSE.300603', 'SZSE.300604', 'SZSE.300605', 'SZSE.300606', 'SZSE.300607', 'SZSE.300608', 'SZSE.300609', 'SZSE.300610', 'SZSE.300611', 'SZSE.300612', 'SZSE.300613', 'SZSE.300614', 'SZSE.300615', 'SZSE.300616', 'SZSE.300617', 'SZSE.300618', 'SZSE.300619', 'SZSE.300620', 'SZSE.300621', 'SZSE.300622', 'SZSE.300623', 'SZSE.300624', 'SZSE.300625', 'SZSE.300626', 'SZSE.300627', 'SZSE.300628', 'SZSE.300629', 'SZSE.300630', 'SZSE.300631', 'SZSE.300632', 'SZSE.300633', 'SZSE.300634', 'SZSE.300635', 'SZSE.300636', 'SZSE.300637', 'SZSE.300638', 'SZSE.300639', 'SZSE.300640', 'SZSE.300641', 'SZSE.300642', 'SZSE.300643', 'SZSE.300644', 'SZSE.300645', 'SZSE.300647', 'SZSE.300648', 'SZSE.300649', 'SZSE.300650', 'SZSE.300651', 'SZSE.300652', 'SZSE.300653', 'SZSE.300654', 'SZSE.300655', 'SZSE.300656', 'SZSE.300657', 'SZSE.300658', 'SZSE.300659', 'SZSE.300660', 'SZSE.300661', 'SZSE.300662', 'SZSE.300663', 'SZSE.300664', 'SZSE.300665', 'SZSE.300666', 'SZSE.300667', 'SZSE.300668', 'SZSE.300669', 'SZSE.300670', 'SZSE.300671', 'SZSE.300672', 'SZSE.300673', 'SZSE.300674', 'SZSE.300675', 'SZSE.300676', 'SZSE.300677', 'SZSE.300678', 'SZSE.300679', 'SZSE.300680', 'SZSE.300681', 'SZSE.300682', 'SZSE.300683', 'SZSE.300684', 'SZSE.300685', 'SZSE.300686', 'SZSE.300687', 'SZSE.300688', 'SZSE.300689', 'SZSE.300690', 'SZSE.300691', 'SZSE.300692', 'SZSE.300693', 'SZSE.300694', 'SZSE.300695', 'SZSE.300696', 'SZSE.300697', 'SZSE.300698', 'SZSE.300699', 'SZSE.300700', 'SZSE.300701', 'SZSE.300702', 'SZSE.300703', 'SZSE.300705', 'SZSE.300706', 'SZSE.300707', 'SZSE.300708', 'SZSE.300709', 'SZSE.300710', 'SZSE.300711', 'SZSE.300712', 'SZSE.300713', 'SZSE.300715', 'SZSE.300716', 'SZSE.300717', 'SZSE.300718', 'SZSE.300719', 'SZSE.300720', 'SZSE.300721', 'SZSE.300722', 'SZSE.300723', 'SZSE.300724', 'SZSE.300725', 'SZSE.300726', 'SZSE.300727', 'SZSE.300729', 'SZSE.300730', 'SZSE.300731', 'SZSE.300732', 'SZSE.300733', 'SZSE.300735', 'SZSE.300736', 'SZSE.300737', 'SZSE.300738', 'SZSE.300739', 'SZSE.300740', 'SZSE.300741', 'SZSE.300742', 'SZSE.300743', 'SZSE.300745', 'SZSE.300746', 'SZSE.300747', 'SZSE.300748', 'SZSE.300749', 'SZSE.300750', 'SZSE.300751', 'SZSE.300752', 'SZSE.300753', 'SZSE.300755', 'SZSE.300756', 'SZSE.300757', 'SZSE.300758', 'SZSE.300759', 'SZSE.300760', 'SZSE.300761', 'SZSE.300762', 'SZSE.300763', 'SZSE.300765', 'SZSE.300766', 'SZSE.300767', 'SZSE.300768', 'SZSE.300769', 'SZSE.300770', 'SZSE.300771', 'SZSE.300772', 'SZSE.300773', 'SZSE.300774', 'SZSE.300775', 'SZSE.300776', 'SZSE.300777', 'SZSE.300778', 'SZSE.300779', 'SZSE.300780', 'SZSE.300781', 'SZSE.300782', 'SZSE.300783', 'SZSE.300785', 'SZSE.300786', 'SZSE.300787', 'SZSE.300788', 'SZSE.300789', 'SZSE.300790', 'SZSE.300791', 'SZSE.300792', 'SZSE.300793', 'SZSE.300795', 'SZSE.300796', 'SZSE.300797', 'SZSE.300798', 'SZSE.300799', 'SZSE.300800', 'SZSE.300801', 'SZSE.300802', 'SZSE.300803', 'SZSE.300804', 'SZSE.300805', 'SZSE.300806', 'SZSE.300807', 'SZSE.300808', 'SZSE.300809', 'SZSE.300810', 'SZSE.300811', 'SZSE.300812', 'SZSE.300813', 'SZSE.300814', 'SZSE.300815', 'SZSE.300816', 'SZSE.300817', 'SZSE.300818', 'SZSE.300819', 'SZSE.300820', 'SZSE.300821', 'SZSE.300822', 'SZSE.300823', 'SZSE.300824', 'SZSE.300825', 'SZSE.300826', 'SZSE.300827', 'SZSE.300828', 'SZSE.300829', 'SZSE.300830', 'SZSE.300831', 'SZSE.300832', 'SZSE.300833', 'SZSE.300834', 'SZSE.300835', 'SZSE.300836', 'SZSE.300837', 'SZSE.300838', 'SZSE.300839', 'SZSE.300840', 'SZSE.300841', 'SZSE.300842', 'SZSE.300843', 'SZSE.300844', 'SZSE.300845', 'SZSE.300846', 'SZSE.300847', 'SZSE.300848', 'SZSE.300849', 'SZSE.300850', 'SZSE.300851', 'SZSE.300852', 'SZSE.300853', 'SZSE.300854', 'SZSE.300855', 'SZSE.300856', 'SZSE.300857', 'SZSE.300858', 'SZSE.300859', 'SZSE.300860', 'SZSE.300861', 'SZSE.300862', 'SZSE.300863', 'SZSE.300864', 'SZSE.300865', 'SZSE.300866', 'SZSE.300867', 'SZSE.300868', 'SZSE.300869', 'SZSE.300870', 'SZSE.300871', 'SZSE.300872', 'SZSE.300873', 'SZSE.300875', 'SZSE.300876', 'SZSE.300877', 'SZSE.300878', 'SZSE.300879', 'SZSE.300880', 'SZSE.300881', 'SZSE.300882', 'SZSE.300883', 'SZSE.300884', 'SZSE.300885', 'SZSE.300886', 'SZSE.300887', 'SZSE.300888', 'SZSE.300889', 'SZSE.300890', 'SZSE.300891', 'SZSE.300892', 'SZSE.300893', 'SZSE.300894', 'SZSE.300895', 'SZSE.300896', 'SZSE.300897', 'SZSE.300898', 'SZSE.300899', 'SZSE.300900', 'SZSE.300901', 'SZSE.300902', 'SZSE.300903', 'SZSE.300904', 'SZSE.300905', 'SZSE.300906', 'SZSE.300907', 'SZSE.300908', 'SZSE.300909', 'SZSE.300910', 'SZSE.300911', 'SZSE.300912', 'SZSE.300913', 'SZSE.300915', 'SZSE.300916', 'SZSE.300917', 'SZSE.300918', 'SZSE.300919', 'SZSE.300920', 'SZSE.300921', 'SZSE.300922', 'SZSE.300923', 'SZSE.300925', 'SZSE.300926', 'SZSE.300927', 'SZSE.300928', 'SZSE.300929', 'SZSE.300930', 'SZSE.300931', 'SZSE.300932', 'SZSE.300933', 'SZSE.300935', 'SZSE.300936', 'SZSE.300937', 'SZSE.300938', 'SZSE.300939', 'SZSE.300940', 'SZSE.300941', 'SZSE.300942', 'SZSE.300943', 'SZSE.300945', 'SZSE.300946', 'SZSE.300947', 'SZSE.300948', 'SZSE.300949', 'SZSE.300950', 'SZSE.300951', 'SZSE.300952', 'SZSE.300953', 'SZSE.300955', 'SZSE.300956', 'SZSE.300957', 'SZSE.300958', 'SZSE.300959', 'SZSE.300960', 'SZSE.300961', 'SZSE.300962', 'SZSE.300963', 'SZSE.300964', 'SZSE.300965', 'SZSE.300966', 'SZSE.300967', 'SZSE.300968', 'SZSE.300969', 'SZSE.300970', 'SZSE.300971', 'SZSE.300972', 'SZSE.300973', 'SZSE.300975', 'SZSE.300976', 'SZSE.300977', 'SZSE.300978', 'SZSE.300979', 'SZSE.300980', 'SZSE.300981', 'SZSE.300982', 'SZSE.300983', 'SZSE.300984', 'SZSE.300985', 'SZSE.300986', 'SZSE.300987', 'SZSE.300988', 'SZSE.300989', 'SZSE.300990', 'SZSE.300991', 'SZSE.300992', 'SZSE.300993', 'SZSE.300994', 'SZSE.300995', 'SZSE.300996', 'SZSE.300997', 'SZSE.300998', 'SZSE.300999', 'SZSE.301000', 'SZSE.301001', 'SZSE.301002', 'SZSE.301003', 'SZSE.301004', 'SZSE.301005', 'SZSE.301006', 'SZSE.301007', 'SZSE.301008', 'SZSE.301009', 'SZSE.301010', 'SZSE.301011', 'SZSE.301012', 'SZSE.301013', 'SZSE.301015', 'SZSE.301016', 'SZSE.301017', 'SZSE.301018', 'SZSE.301019', 'SZSE.301020', 'SZSE.301021', 'SZSE.301022', 'SZSE.301023', 'SZSE.301024', 'SZSE.301025', 'SZSE.301026', 'SZSE.301027', 'SZSE.301028', 'SZSE.301029', 'SZSE.301030', 'SZSE.301031', 'SZSE.301032', 'SZSE.301033', 'SZSE.301035', 'SZSE.301036', 'SZSE.301037', 'SZSE.301038', 'SZSE.301039', 'SZSE.301040', 'SZSE.301041', 'SZSE.301042', 'SZSE.301043', 'SZSE.301045', 'SZSE.301046', 'SZSE.301047', 'SZSE.301048', 'SZSE.301049', 'SZSE.301050', 'SZSE.301051', 'SZSE.301052', 'SZSE.301053', 'SZSE.301055', 'SZSE.301056', 'SZSE.301057', 'SZSE.301058', 'SZSE.301059', 'SZSE.301060', 'SZSE.301061', 'SZSE.301062', 'SZSE.301063', 'SZSE.301065', 'SZSE.301066', 'SZSE.301067', 'SZSE.301068', 'SZSE.301069', 'SZSE.301070', 'SZSE.301071', 'SZSE.301072', 'SZSE.301073', 'SZSE.301075', 'SZSE.301076', 'SZSE.301077', 'SZSE.301078', 'SZSE.301079', 'SZSE.301080', 'SZSE.301081', 'SZSE.301082', 'SZSE.301083', 'SZSE.301085', 'SZSE.301086', 'SZSE.301087', 'SZSE.301088', 'SZSE.301089', 'SZSE.301090', 'SZSE.301091', 'SZSE.301092', 'SZSE.301093', 'SZSE.301095', 'SZSE.301096', 'SZSE.301097', 'SZSE.301098', 'SZSE.301099', 'SZSE.301100', 'SZSE.301101', 'SZSE.301102', 'SZSE.301103', 'SZSE.301105', 'SZSE.301106', 'SZSE.301107', 'SZSE.301108', 'SZSE.301109', 'SZSE.301110', 'SZSE.301111', 'SZSE.301112', 'SZSE.301113', 'SZSE.301115', 'SZSE.301116', 'SZSE.301117', 'SZSE.301118', 'SZSE.301119', 'SZSE.301120', 'SZSE.301121', 'SZSE.301122', 'SZSE.301123', 'SZSE.301125', 'SZSE.301126', 'SZSE.301127', 'SZSE.301128', 'SZSE.301129', 'SZSE.301130', 'SZSE.301131', 'SZSE.301132', 'SZSE.301133', 'SZSE.301135', 'SZSE.301136', 'SZSE.301137', 'SZSE.301138', 'SZSE.301139', 'SZSE.301141', 'SZSE.301148', 'SZSE.301149', 'SZSE.301150', 'SZSE.301151', 'SZSE.301152', 'SZSE.301153', 'SZSE.301155', 'SZSE.301156', 'SZSE.301157', 'SZSE.301158', 'SZSE.301159', 'SZSE.301160', 'SZSE.301161', 'SZSE.301162', 'SZSE.301163', 'SZSE.301165', 'SZSE.301166', 'SZSE.301167', 'SZSE.301168', 'SZSE.301169', 'SZSE.301170', 'SZSE.301171', 'SZSE.301172', 'SZSE.301175', 'SZSE.301176', 'SZSE.301177', 'SZSE.301178', 'SZSE.301179', 'SZSE.301180', 'SZSE.301181', 'SZSE.301182', 'SZSE.301183', 'SZSE.301185', 'SZSE.301186', 'SZSE.301187', 'SZSE.301188', 'SZSE.301189', 'SZSE.301190', 'SZSE.301191', 'SZSE.301192', 'SZSE.301193', 'SZSE.301195', 'SZSE.301196', 'SZSE.301197', 'SZSE.301198', 'SZSE.301199', 'SZSE.301200', 'SZSE.301201', 'SZSE.301202', 'SZSE.301203', 'SZSE.301205', 'SZSE.301206', 'SZSE.301207', 'SZSE.301208', 'SZSE.301209', 'SZSE.301210', 'SZSE.301211', 'SZSE.301212', 'SZSE.301213', 'SZSE.301215', 'SZSE.301216', 'SZSE.301217', 'SZSE.301218', 'SZSE.301219', 'SZSE.301220', 'SZSE.301221', 'SZSE.301222', 'SZSE.301223', 'SZSE.301225', 'SZSE.301226', 'SZSE.301227', 'SZSE.301228', 'SZSE.301229', 'SZSE.301230', 'SZSE.301231', 'SZSE.301232', 'SZSE.301233', 'SZSE.301234', 'SZSE.301235', 'SZSE.301236', 'SZSE.301237', 'SZSE.301238', 'SZSE.301239', 'SZSE.301246', 'SZSE.301248', 'SZSE.301251', 'SZSE.301252', 'SZSE.301255', 'SZSE.301256', 'SZSE.301257', 'SZSE.301258', 'SZSE.301259', 'SZSE.301260', 'SZSE.301261', 'SZSE.301262', 'SZSE.301263', 'SZSE.301265', 'SZSE.301266', 'SZSE.301267', 'SZSE.301268', 'SZSE.301269', 'SZSE.301270', 'SZSE.301272', 'SZSE.301273', 'SZSE.301276', 'SZSE.301277', 'SZSE.301278', 'SZSE.301279', 'SZSE.301280', 'SZSE.301281', 'SZSE.301282', 'SZSE.301283', 'SZSE.301285', 'SZSE.301286', 'SZSE.301287', 'SZSE.301288', 'SZSE.301289', 'SZSE.301290', 'SZSE.301291', 'SZSE.301292', 'SZSE.301293', 'SZSE.301295', 'SZSE.301296', 'SZSE.301297', 'SZSE.301298', 'SZSE.301299', 'SZSE.301300', 'SZSE.301301', 'SZSE.301302', 'SZSE.301303', 'SZSE.301305', 'SZSE.301306', 'SZSE.301307', 'SZSE.301308', 'SZSE.301309', 'SZSE.301310', 'SZSE.301311', 'SZSE.301312', 'SZSE.301313', 'SZSE.301314', 'SZSE.301315', 'SZSE.301316', 'SZSE.301317', 'SZSE.301318', 'SZSE.301319', 'SZSE.301320', 'SZSE.301321', 'SZSE.301322', 'SZSE.301323', 'SZSE.301325', 'SZSE.301326', 'SZSE.301327', 'SZSE.301328', 'SZSE.301329', 'SZSE.301330', 'SZSE.301331', 'SZSE.301332', 'SZSE.301333', 'SZSE.301335', 'SZSE.301336', 'SZSE.301337', 'SZSE.301338', 'SZSE.301339', 'SZSE.301345', 'SZSE.301348', 'SZSE.301349', 'SZSE.301353', 'SZSE.301355', 'SZSE.301356', 'SZSE.301357', 'SZSE.301358', 'SZSE.301359', 'SZSE.301360', 'SZSE.301361', 'SZSE.301362', 'SZSE.301363', 'SZSE.301365', 'SZSE.301366', 'SZSE.301367', 'SZSE.301368', 'SZSE.301369', 'SZSE.301370', 'SZSE.301371', 'SZSE.301372', 'SZSE.301373', 'SZSE.301376', 'SZSE.301377', 'SZSE.301378', 'SZSE.301379', 'SZSE.301380', 'SZSE.301381', 'SZSE.301382', 'SZSE.301383', 'SZSE.301386', 'SZSE.301387', 'SZSE.301388', 'SZSE.301389', 'SZSE.301390', 'SZSE.301391', 'SZSE.301393', 'SZSE.301395', 'SZSE.301396', 'SZSE.301397', 'SZSE.301398', 'SZSE.301399', 'SZSE.301408', 'SZSE.301418', 'SZSE.301419', 'SZSE.301421', 'SZSE.301428', 'SZSE.301429', 'SZSE.301439', 'SZSE.301446', 'SZSE.301448', 'SZSE.301456', 'SZSE.301468', 'SZSE.301469', 'SZSE.301486', 'SZSE.301487', 'SZSE.301488', 'SZSE.301498', 'SZSE.301499', 'SZSE.301500', 'SZSE.301503', 'SZSE.301505', 'SZSE.301507', 'SZSE.301509', 'SZSE.301510', 'SZSE.301511', 'SZSE.301512', 'SZSE.301515', 'SZSE.301518', 'SZSE.301519', 'SZSE.301520', 'SZSE.301525', 'SZSE.301528', 'SZSE.301529', 'SZSE.301533', 'SZSE.301548', 'SZSE.301550']
        

##  get_index_constituents \- 查询指数成分股信息. ¶
    
    
    get_index_constituents(index, trade_date=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`index` |  `str` |  指数代码,必填,只能输入一个指数,如`SHSE.000300`. |  _必需_  
`trade_date` |  `str` |  str交易日(格式为yyyy-mm-dd),默认None为最新交易日. |  `None`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`index` |  `str` |  指数代码  
`symbol` |  `str` |  合约代码  
`weight` |  `float` |  权重  
`trade_date` |  `str` |  交易日  
`market_value_total` |  `float` |  总市值 单位：亿元  
`market_value_circ` |  `float` |  流通市值 单位：亿元  
  
**示例：**

  * Input: 
        
        import pandas as pd
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        pd.set_option('display.max_columns', None)
        datas = ait0.get_index_constituents(index='SHSE.000300',trade_date='2023-11-11')
        print(datas)
        

  * Output: 
        
        index       symbol    weight  trade_date  market_value_total                  0    SHSE.000300  SHSE.600000  0.004569  2023-11-10           2019.4297
                1    SHSE.000300  SHSE.600009  0.002600  2023-11-10            922.9777
                2    SHSE.000300  SHSE.600010  0.002040  2023-11-10            721.9386
                3    SHSE.000300  SHSE.600011  0.001863  2023-11-10           1194.6249
                4    SHSE.000300  SHSE.600015  0.001998  2023-11-10            884.8700
                ..           ...          ...       ...         ...                 ...
                295  SHSE.000300  SZSE.300896  0.002009  2023-11-10            707.1727
                296  SHSE.000300  SZSE.300919  0.000828  2023-11-10            366.3938
                297  SHSE.000300  SZSE.300957  0.000556  2023-11-10            328.4594
                298  SHSE.000300  SZSE.300979  0.000430  2023-11-10            591.4356
                299  SHSE.000300  SZSE.300999  0.001167  2023-11-10           1881.8344
        
                     market_value_circ
                0            2019.4297
                1             714.7089
                2             500.8042
                3             836.9257
                4             712.9414
                ..                 ...
                295           488.2664
                296           157.2547
                297           168.5671
                298            74.0320
                299           188.3528
        
                [300 rows x 6 columns]
        

##  get_industry \- 查询股票所属行业. ¶
    
    
    get_industry(security, trade_date=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`security` |  `str | list` |  类型为字符串或列表,如:'SZSE.000001'或['SZSE.000001','SZSE.000002'] |  _必需_  
`trade_date` |  `str | datetime | date` |  查询的交易日期,默认为None,指定查询当天的数据. |  `None`  
  
**返回：**

类型 | 描述  
---|---  
`dict` |  返回结果是一个dict，key是传入的股票代码  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        data = ait0.get_industry(security='SZSE.000995', trade_date='2021-07-01')
        print(data)
        

  * Output: 
        
        {'SZSE.000995': {'zjw': {'industry_code': '15', 'industry_name': '酒、饮料和精制茶制造业'}}}
        

##  get_next_trading_date \- 获取指定日期的下一个交易日 ¶
    
    
    get_next_trading_date(date=None, exchange='SHSE')
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`date` |  `str | datetime | date` |  日期. None-默认为当天 |  `None`  
`exchange` |  `str` |  交易所代码, 默认 上海股票交易所 |  `'SHSE'`  
  
**返回：**

类型 | 描述  
---|---  
`str` |  下一个交易日YYYY-MM-DD  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        df = ait0.get_next_trading_date()
        print(df)
        

  * Output: 
        
        2023-12-27
        

##  get_previous_trading_date \- 获取指定日期的上一个交易日 ¶
    
    
    get_previous_trading_date(date=None, exchange='SHSE')
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`date` |  `str | datetime | date` |  日期. None-默认为当天 |  `None`  
`exchange` |  `str` |  交易所代码, 默认 上海股票交易所 |  `'SHSE'`  
  
**返回：**

类型 | 描述  
---|---  
`str` |  上一个交易日YYYY-MM-DD  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        df = ait0.get_previous_trading_date()
        print(df)
        

  * Output: 
        
        2023-12-25
        

##  get_trade_days \- 获取指定日期范围内的所有交易日  `cached` ¶
    
    
    get_trade_days(start_date=None, end_date=None, count=None, exchange='SHSE')
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`start_date` |  `str | datetime | date` |  开始日期: 日期字符串/date对象/datetime对象, 注意传入datetime对象时忽略日内时间 |  `None`  
`end_date` |  `str | datetime | date` |  结束日期: 日期字符串/date对象/datetime对象, 注意传入datetime对象时忽略日内时间 |  `None`  
`count` |  `int` |  条数和start_date只能二选一. |  `None`  
`exchange` |  `str` |  交易所代码, 默认 上海股票交易所 |  `'SHSE'`  
  
**返回：**

类型 | 描述  
---|---  
`list` |  numpy.ndarray, 包含指定的 start_date 和 end_date, 默认返回至 datatime.date.today() 的所有交易日  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        data = ait0.get_trade_days(start_date='2023-10-11', end_date='2023-11-11',exchange='SHSE')
        print(data)
        

  * Output: 
        
        ['2023-10-11' '2023-10-12' '2023-10-13' '2023-10-16' '2023-10-17'
         '2023-10-18' '2023-10-19' '2023-10-20' '2023-10-23' '2023-10-24'
         '2023-10-25' '2023-10-26' '2023-10-27' '2023-10-30' '2023-10-31'
         '2023-11-01' '2023-11-02' '2023-11-03' '2023-11-06' '2023-11-07'
         '2023-11-08' '2023-11-09' '2023-11-10']
        

##  get_current_trade_date \- 根据标的查询当前交易日 ¶
    
    
    get_current_trade_date(symbol)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  合约，只支持单个合约，采用交易所前缀格式，如：SZSE.000001 |  _必需_  
  
**返回：**

类型 | 描述  
---|---  
`date` |  当前交易日 (datetime.date)  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        datas = ait0.get_current_trade_date(symbol='SZSE.000002')
        print(datas)
        

  * Output: 
        
        2024-03-21
        

##  stk_get_fundamentals_balance_batch \- 批量查询资产负债表数据. ¶
    
    
    stk_get_fundamentals_balance_batch(symbols, data_type, end_date=None, count=1, rpt_type=None, fields=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbols` |  `str | list[str]` |  股票代码，支持多个. |  _必需_  
`data_type` |  `int` |  数据类型,101-合并原始,102-合并调整,201-母公司原始,202-母公司调整. |  _必需_  
`end_date` |  `str | datetime | date` |  结束时间,时间类型为报告日期,默认为None表示当前最新时间. |  `None`  
`count` |  `int` |  返回数量. |  `1`  
`rpt_type` |  `int` |  报表类型,1- 一季度报,6- 中报,9- 前三季报,12- 年报,默认为None即不限. |  `None`  
`fields` |  `str | list[str]` |  返回字段，支持多个. |  `None`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`cash_bal_cb` |  `float` |  现金及存放中央银行款项（元）  
`dpst_ob` |  `float` |  存放同业款项（元）  
`mny_cptl` |  `float` |  货币资金（元）  
`cust_cred_dpst` |  `float` |  客户信用资金存款（元）  
`cust_dpst` |  `float` |  客户资金存款（元）  
`pm` |  `float` |  贵金属（元）  
`bal_clr` |  `float` |  结算备付金（元）  
`cust_rsv` |  `float` |  客户备付金（元）  
`ln_to_ob` |  `float` |  拆出资金（元）  
`fair_val_fin_ast` |  `float` |  以公允价值计量且其变动计入当期损益的金融资产（元）  
`ppay` |  `float` |  预付款项（元）  
`fin_out` |  `float` |  融出资金（元）  
`trd_fin_ast` |  `float` |  交易性金融资产（元）  
`deriv_fin_ast` |  `float` |  衍生金融资产（元）  
`note_acct_rcv` |  `float` |  应收票据及应收账款（元）  
`note_rcv` |  `float` |  应收票据（元）  
`acct_rcv` |  `float` |  应收账款（元）  
`acct_rcv_fin` |  `float` |  应收款项融资（元）  
`int_rcv` |  `float` |  应收利息（元）  
`dvd_rcv` |  `float` |  应收股利（元）  
`oth_rcv` |  `float` |  其他应收款（元）  
`in_prem_rcv` |  `float` |  应收保费（元）  
`rin_acct_rcv` |  `float` |  应收分保账款（元）  
`rin_rsv_rcv` |  `float` |  应收分保合同准备金（元）  
`rcv_un_prem_rin_rsv` |  `float` |  应收分保未到期责任准备金（元）  
`rcv_clm_rin_rsv` |  `float` |  应收分保未决赔偿准备金（元）  
`rcv_li_rin_rsv` |  `float` |  应收分保寿险责任准备金（元）  
`rcv_lt_hi_rin_rsv` |  `float` |  应收分保长期健康险责任准备金（元）  
`ph_plge_ln` |  `float` |  保户质押贷款（元）  
`ttl_oth_rcv` |  `float` |  其他应收款合计（元）  
`rfd_dpst` |  `float` |  存出保证金（元）  
`term_dpst` |  `float` |  定期存款（元）  
`pur_resell_fin` |  `float` |  买入返售金融资产（元）  
`aval_sale_fin` |  `float` |  可供出售金融资产（元）  
`htm_inv` |  `float` |  持有至到期投资（元）  
`hold_for_sale` |  `float` |  持有待售资产（元）  
`acct_rcv_inv` |  `float` |  应收款项类投资（元）  
`invt` |  `float` |  存货（元）  
`contr_ast` |  `float` |  合同资产（元）  
`ncur_ast_one_y` |  `float` |  一年内到期的非流动资产（元）  
`oth_cur_ast` |  `float` |  其他流动资产（元）  
`cur_ast_oth_item` |  `float` |  流动资产其他项目（元）  
`ttl_cur_ast` |  `float` |  流动资产合计（元）  
`loan_adv` |  `float` |  发放委托贷款及垫款（元）  
`cred_inv` |  `float` |  债权投资（元）  
`oth_cred_inv` |  `float` |  其他债权投资（元）  
`lt_rcv` |  `float` |  长期应收款（元）  
`lt_eqy_inv` |  `float` |  长期股权投资（元）  
`oth_eqy_inv` |  `float` |  其他权益工具投资（元）  
`rfd_cap_guar_dpst` |  `float` |  存出资本保证金（元）  
`oth_ncur_fin_ast` |  `float` |  其他非流动金融资产（元）  
`amor_cos_fin_ast_ncur` |  `float` |  以摊余成本计量的金融资产（非流动）（元）  
`fair_val_oth_inc_ncur` |  `float` |  以公允价值计量且其变动计入其他综合收益的金融资产（非流动）（元）  
`inv_prop` |  `float` |  投资性房地产（元）  
`fix_ast` |  `float` |  固定资产（元）  
`const_prog` |  `float` |  在建工程（元）  
`const_matl` |  `float` |  工程物资（元）  
`fix_ast_dlpl` |  `float` |  固定资产清理（元）  
`cptl_bio_ast` |  `float` |  生产性生物资产（元）  
`oil_gas_ast` |  `float` |  油气资产（元）  
`rig_ast` |  `float` |  使用权资产（元）  
`intg_ast` |  `float` |  无形资产（元）  
`trd_seat_fee` |  `float` |  交易席位费（元）  
`dev_exp` |  `float` |  开发支出（元）  
`gw` |  `float` |  商誉（元）  
`lt_ppay_exp` |  `float` |  长期待摊费用（元）  
`dfr_tax_ast` |  `float` |  递延所得税资产（元）  
`oth_ncur_ast` |  `float` |  其他非流动资产（元）  
`ncur_ast_oth_item` |  `float` |  非流动资产其他项目（元）  
`ttl_ncur_ast` |  `float` |  非流动资产合计（元）  
`oth_ast` |  `float` |  其他资产（元）  
`ast_oth_item` |  `float` |  资产其他项目（元）  
`ind_acct_ast` |  `float` |  独立账户资产（元）  
`ttl_ast` |  `float` |  资产总计（元）  
`brw_cb` |  `float` |  向中央银行借款（元）  
`dpst_ob_fin_inst` |  `float` |  同业和其他金融机构存放款项（元）  
`ln_fm_ob` |  `float` |  拆入资金（元）  
`fair_val_fin_liab` |  `float` |  以公允价值计量且其变动计入当期损益的金融负债（元）  
`sht_ln` |  `float` |  短期借款（元）  
`adv_acct` |  `float` |  预收款项（元）  
`contr_liab` |  `float` |  合同负债（元）  
`trd_fin_liab` |  `float` |  交易性金融负债（元）  
`deriv_fin_liab` |  `float` |  衍生金融负债（元）  
`sell_repo_ast` |  `float` |  卖出回购金融资产款（元）  
`cust_bnk_dpst` |  `float` |  吸收存款（元）  
`dpst_cb_note_pay` |  `float` |  存款证及应付票据（元）  
`dpst_cb` |  `float` |  存款证（元）  
`acct_rcv_adv` |  `float` |  预收账款（元）  
`in_prem_rcv_adv` |  `float` |  预收保费（元）  
`fee_pay` |  `float` |  应付手续费及佣金（元）  
`note_acct_pay` |  `float` |  应付票据及应付账款（元）  
`stlf_pay` |  `float` |  应付短期融资款（元）  
`note_pay` |  `float` |  应付票据（元）  
`acct_pay` |  `float` |  应付账款（元）  
`rin_acct_pay` |  `float` |  应付分保账款（元）  
`emp_comp_pay` |  `float` |  应付职工薪酬（元）  
`tax_pay` |  `float` |  应交税费（元）  
`int_pay` |  `float` |  应付利息（元）  
`dvd_pay` |  `float` |  应付股利（元）  
`ph_dvd_pay` |  `float` |  应付保单红利（元）  
`indem_pay` |  `float` |  应付赔付款（元）  
`oth_pay` |  `float` |  其他应付款（元）  
`ttl_oth_pay` |  `float` |  其他应付款合计（元）  
`ph_dpst_inv` |  `float` |  保户储金及投资款（元）  
`in_contr_rsv` |  `float` |  保险合同准备金（元）  
`un_prem_rsv` |  `float` |  未到期责任准备金（元）  
`clm_rin_rsv` |  `float` |  未决赔款准备金（元）  
`li_liab_rsv` |  `float` |  寿险责任准备金（元）  
`lt_hi_liab_rsv` |  `float` |  长期健康险责任准备金（元）  
`cust_bnk_dpst_fin` |  `float` |  吸收存款及同业存放（元）  
`inter_pay` |  `float` |  内部应付款（元）  
`agy_secu_trd` |  `float` |  代理买卖证券款（元）  
`agy_secu_uw` |  `float` |  代理承销证券款（元）  
`sht_bnd_pay` |  `float` |  应付短期债券（元）  
`est_cur_liab` |  `float` |  预计流动负债（元）  
`liab_hold_for_sale` |  `float` |  持有待售负债（元）  
`ncur_liab_one_y` |  `float` |  一年内到期的非流动负债（元）  
`oth_cur_liab` |  `float` |  其他流动负债（元）  
`cur_liab_oth_item` |  `float` |  流动负债其他项目（元）  
`ttl_cur_liab` |  `float` |  流动负债合计（元）  
`lt_ln` |  `float` |  长期借款（元）  
`lt_pay` |  `float` |  长期应付款（元）  
`leas_liab` |  `float` |  租赁负债dfr_inc: 递延收益（元）  
`dfr_tax_liab` |  `float` |  递延所得税负债（元）  
`bnd_pay` |  `float` |  应付债券（元）  
`bnd_pay_pbd` |  `float` |  其中:永续债（元）  
`bnd_pay_pfd` |  `float` |  其中:优先股（元）  
`oth_ncur_liab` |  `float` |  其他非流动负债（元）  
`spcl_pay` |  `float` |  专项应付款（元）  
`ncur_liab_oth_item` |  `float` |  非流动负债其他项目（元）  
`lt_emp_comp_pay` |  `float` |  长期应付职工薪酬（元）  
`est_liab` |  `float` |  预计负债（元）  
`oth_liab` |  `float` |  其他负债（元）  
`liab_oth_item` |  `float` |  负债其他项目（元）  
`ttl_ncur_liab` |  `float` |  非流动负债合计（元）  
`ind_acct_liab` |  `float` |  独立账户负债（元）  
`ttl_liab` |  `float` |  负债合计（元）  
`paid_in_cptl` |  `float` |  实收资本（或股本）（元）  
`oth_eqy` |  `float` |  其他权益工具（元）  
`oth_eqy_pfd` |  `float` |  其中:优先股（元）  
`oth_eqy_pbd` |  `float` |  其中:永续债（元）  
`oth_eqy_oth` |  `float` |  其中:其他权益工具（元）  
`cptl_rsv` |  `float` |  资本公积（元）  
`treas_shr` |  `float` |  库存股（元）  
`oth_comp_inc` |  `float` |  其他综合收益（元）  
`spcl_rsv` |  `float` |  专项储备（元）  
`sur_rsv` |  `float` |  盈余公积（元）  
`rsv_ord_rsk` |  `float` |  一般风险准备（元）  
`trd_risk_rsv` |  `float` |  交易风险准备（元）  
`ret_prof` |  `float` |  未分配利润（元）  
`sugg_dvd` |  `float` |  建议分派股利（元）  
`eqy_pcom_oth_item` |  `float` |  归属于母公司股东权益其他项目（元）  
`ttl_eqy_pcom` |  `float` |  归属于母公司股东权益合计（元）  
`min_sheqy` |  `float` |  少数股东权益（元）  
`sheqy_oth_item` |  `float` |  股东权益其他项目（元）  
`ttl_eqy` |  `float` |  股东权益合计（元）  
`ttl_liab_eqy` |  `float` |  负债和股东权益合计  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        datas = ait0.stk_get_fundamentals_balance_batch(symbols='SZSE.000995',data_type=101)
        print(datas)
        

  * Output: 
        
        acct_pay    acct_rcv acct_rcv_adv  ...   ttl_oth_pay  ttl_oth_rcv  un_prem_rsv
        0  73639681.38  5955644.56         None  ...  1.191091e+08  31296736.01         None
        

##  get_margin_rate \- 获取合约对应的保证金率. ¶
    
    
    get_margin_rate(symbol, pos_type=None)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  合约代码. |  _必需_  
`pos_type` |  `str` |  默认获取多头保证金,'Long'-多头,'Short'-空头. |  `None`  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`margin_rate` |  `float` |  保证金.  
`margin_type` |  `str` |  保证金收取方式,'volume'按照手数收取, 'money'按照成交金额收取.  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        margin_rate = ait0.get_margin_rate(symbol='CBOT.Omain')
        print(margin_rate)
        

  * Output: 
        
        2640, 'volume'
        

##  get_commission \- 获取合约对应的手续费. ¶
    
    
    get_commission(symbol)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`symbol` |  `str` |  合约代码. |  _必需_  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`commission` |  `dict` |  手续费,各字段如下:  
`type` |  `str` |  手续费收取方式,'volume'按照手数收取, 'money'按照成交金额收取.  
`open` |  `float` |  开仓手续费.  
`close` |  `float` |  平仓手续费.  
`closeTd` |  `float` |  平今手续费(国内期货交易所支持).  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        commission = ait0.get_commission(symbol='CBOT.Omain')
        print(commission)
        

  * Output: 
        
        {'type': 'volume', 'open': 100.0, 'close': 100.0}
        

##  get_currency_rate \- 获取汇率 ¶
    
    
    get_currency_rate(src_currency, dst_currency)
    

**参数：**

名称 | 类型 | 描述 | 默认  
---|---|---|---  
`src_currency` |  `str` |  源币种，如 CNY. |  _必需_  
`dst_currency` |  `str` |  目标币种，如 HKD. |  _必需_  
  
**返回：**

名称 | 类型 | 描述  
---|---|---  
`rate` |  `float` |  汇率  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        rate = ait0.get_currency_rate(src_currency='CNY', dst_currency='HKD')
        print(rate)
        

  * Output: 
        
        1.0808
        

##  get_exchange_info \- 获取交易所列表 ¶
    
    
    get_exchange_info()
    

**返回：**

名称 | 类型 | 描述  
---|---|---  
`exchange_code` |  `str` |  交易所代码.  
`exchange_name` |  `str` |  交易所名字.  
`exchange_area` |  `str` |  交易所所在地区.  
`chinese_name` |  `str` |  交易所中文名字.  
`english_name` |  `str` |  交易所英文简称.  
`alias` |  `str` |  别名.  
`group_name` |  `str` |  分组.  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)        
        df = ait0.get_exchange_info()
        print(df)
        

  * Output: 
        
        exchange_code exchange_name exchange_area chinese_name english_name
        0           AMEX       美国证券交易所             美      美国证券交易所         AMEX
        1           CBOT      芝加哥期货交易所             美     芝加哥期货交易所         CBOT
        2          CFFEX           中金所                        中金所        CFFEX
        3            CME      芝加哥商业交易所             美     芝加哥商业交易所          CME
        4          COMEX       纽约商品交易所             美      纽约商品交易所        COMEX
        5           CZCE           郑商所                        郑商所         CZCE
        6            DCE           大商所                        大商所          DCE
        7           GFEX           广期所             中          广期所         GFEX
        8           HKEX         香港交易所             港        香港交易所         HKEX
        9           HKSE       香港证券交易所             港      香港证券交易所         HKSE
        10           INE    上海国际能源交易中心                 上海国际能源交易中心          INE
        11        NASDAQ     纳斯达克证券交易所             美    纳斯达克证券交易所       NASDAQ
        12         NYMEX       纽约商业交易所             美      纽约商业交易所        NYMEX
        13          NYSE       纽约证券交易所             美      纽约证券交易所         NYSE
        14           SGX        新加坡交易所             新       新加坡交易所          SGX
        15          SHFE           上期所                        上期所         SHFE
        16          SHSE           上交所                        上交所         SHSE
        17          SZSE           深交所                        深交所         SZSE
        18           THS           同花顺             中          同花顺          THS
        

##  get_china_future_main \- 获取国内期货主力合约信息. ¶
    
    
    get_china_future_main()
    

**返回：**

名称 | 类型 | 描述  
---|---|---  
`display_name` |  `str` |  品种名字  
`name` |  `str` |  名字  
`start_date` |  `str` |  开始日期 (%Y-%m-%d)  
`end_date` |  `str` |  开始日期 (%Y-%m-%d)  
`type` |  `str` |  类型。'stock'--股票, 'futures'--期货, 'index'--指数  
`contract_size` |  `int` |  合约乘数  
`exchange_code` |  `str` |  交易所代码  
`commodity_no` |  `str` |  品种代码  
`lot_min` |  `int` |  每手最少数量  
`lot_step` |  `int` |  数量步长  
`commodity_tick_size` |  `int` |  最小跳动单位  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        df = ait0.get_china_future_main()
        print(df)
        

  * Output: 
        
        display_name    name start_date   end_date     type contract_size exchange_code commodity_no  lot_min  lot_step commodity_tick_size
        symbol
        DCE.amain         豆一 2409   amain 2023-09-15 2099-06-01  futures     10.000000           DCE            a        1         1                   1
        DCE.bmain         豆二 2409   bmain 2023-09-15 2099-06-01  futures     10.000000           DCE            b        1         1                   1
        DCE.cmain         玉米 2409   cmain 2023-09-15 2099-06-01  futures     10.000000           DCE            c        1         1                   1
        DCE.imain        铁矿石 2409   imain 2023-09-15 2099-06-01  futures    100.000000           DCE            i        1         1                 0.5
        DCE.jmain         焦炭 2409   jmain 2023-09-15 2099-06-01  futures    100.000000           DCE            j        1         1                 0.5
        ...                   ...     ...        ...        ...      ...           ...           ...          ...      ...       ...                 ...
        CFFEX.IHmain      上证 2407  IHmain 2024-05-20 2099-06-01  futures    300.000000         CFFEX           IH        1         1                 0.2
        CFFEX.IMmain  中证1000 2407  IMmain 2024-05-20 2099-06-01  futures    200.000000         CFFEX           IM        1         1                 0.2
        CFFEX.TFmain      TF 2409  TFmain 2023-12-11 2099-06-01  futures  10000.000000         CFFEX           TF        1         1               0.005
        CFFEX.TLmain      TL 2409  TLmain 2023-12-11 2099-06-01  futures  10000.000000         CFFEX           TL        1         1                0.01
        CFFEX.TSmain      TS 2409  TSmain 2023-12-11 2099-06-01  futures  20000.000000         CFFEX           TS        1         1               0.002
        

##  get_foreign_future_main \- 获取国际期货主力合约信息. ¶
    
    
    get_foreign_future_main()
    

**返回：**

名称 | 类型 | 描述  
---|---|---  
`display_name` |  `str` |  真实合约名称  
`name` |  `str` |  主力合约名称  
`start_date` |  `str` |  真实合约的第一交易日期 (%Y-%m-%d)  
`end_date` |  `str` |  真实合约的最后交易日期 (%Y-%m-%d)  
`type` |  `str` |  类型。'stock'--股票, 'futures'--期货, 'index'--指数  
`contract_size` |  `int` |  合约乘数  
`exchange_code` |  `str` |  交易所代码  
`commodity_no` |  `str` |  品种代码  
`lot_min` |  `int` |  每手最少数量  
`lot_step` |  `int` |  数量步长  
`commodity_tick_size` |  `int` |  最小跳动单位  
  
**示例：**

  * Input: 
        
        import ait0
        ait0.config.set_mode(ait0.config.MODE_LIVE_REMOTE)
        df = ait0.get_foreign_future_main()
        print(df)
        

  * Output: 
        
        display_name     name start_date   end_date     type    contract_size exchange_code commodity_no  lot_min  lot_step commodity_tick_size
        symbol
        CBOT.Cmain                  玉米 2412    Cmain            2024-12-13  futures        50.000000          CBOT            C        1         0                0.25
        CBOT.Smain                  大豆 2411    Smain            2024-11-14  futures        50.000000          CBOT            S        1         0                0.25
        CBOT.Wmain                  小麦 2409    Wmain            2024-09-13  futures        50.000000          CBOT            W        1         0                0.25
        CME.ADmain                  澳元 2409   ADmain            2024-09-16  futures    100000.000000           CME           AD        1         0             0.00005
        CME.BPmain                  英镑 2409   BPmain            2024-09-16  futures     62500.000000           CME           BP        1         0              0.0001
        CME.CDmain                  加元 2409   CDmain            2024-09-17  futures    100000.000000           CME           CD        1         0             0.00005
        CME.ECmain                  欧元 2409   ECmain            2024-09-16  futures    125000.000000           CME           EC        1         0             0.00005
        CME.ESmain                迷你标普 2409   ESmain            2024-09-20  futures        50.000000           CME           ES        1         0                0.25
        CME.JYmain                  日元 2409   JYmain            2024-09-16  futures  12500000.000000           CME           JY        1         0           0.0000005
        CME.NQmain         迷你纳斯达克100指数 2409   NQmain            2024-09-20  futures        20.000000           CME           NQ        1         0                0.25
        CME.SFmain                  瑞郎 2409   SFmain            2024-09-16  futures    125000.000000           CME           SF        1         0             0.00005
        SGX.CNmain               A50指数 2407   CNmain            2024-07-30  futures         1.000000           SGX           CN        1         0                   1
        CBOT.YMmain               迷你道指 2409   YMmain            2024-09-20  futures         5.000000          CBOT           YM        1         0                   1
        CBOT.ZBmain              三十年美债 2409   ZBmain            2024-09-19  futures      1000.000000          CBOT           ZB        1         0             0.03125
        CBOT.ZLmain              大豆油期货 2412   ZLmain            2024-12-13  futures       600.000000          CBOT           ZL        1         0                0.01
        CBOT.ZMmain                 豆粕 2412   ZMmain            2024-12-13  futures       100.000000          CBOT           ZM        1         0                 0.1
        CBOT.ZNmain               十年国债 2409   ZNmain            2024-09-19  futures      1000.000000          CBOT           ZN        1         0            0.015625
        CBOT.ZTmain               两年国债 2409   ZTmain            2024-09-30  futures      2000.000000          CBOT           ZT        1         0          0.00390625
        COMEX.GCmain                黄金 2408   GCmain            2024-08-28  futures       100.000000         COMEX           GC        1         0                 0.1
        COMEX.HGmain                 铜 2409   HGmain            2024-09-26  futures     25000.000000         COMEX           HG        1         0              0.0005
        COMEX.QImain              迷你白银 2409   QImain            2024-08-28  futures      2500.000000         COMEX           QI        1         0              0.0125
        COMEX.QOmain              迷你黄金 2408   QOmain            2024-07-29  futures        50.000000         COMEX           QO        1         0                0.25
        COMEX.SImain                白银 2409   SImain            2024-09-26  futures      5000.000000         COMEX           SI        1         0               0.005
        NYMEX.BZmain          布伦原油(现金) 2409   BZmain            2024-07-31  futures      1000.000000         NYMEX           BZ        1         0                0.01
        NYMEX.CLmain             WTI原油 2408   CLmain            2024-07-22  futures      1000.000000         NYMEX           CL        1         0                0.01
        NYMEX.NGmain               天然气 2408   NGmain            2024-07-29  futures     10000.000000         NYMEX           NG        1         0               0.001
        NYMEX.PAmain                钯金 2409   PAmain            2024-09-26  futures       100.000000         NYMEX           PA        1         0                 0.5
        NYMEX.PLmain                铂金 2410   PLmain            2024-10-29  futures        50.000000         NYMEX           PL        1         0                 0.1
        NYMEX.QMmain              迷你原油 2408   QMmain            2024-07-19  futures       500.000000         NYMEX           QM        1         0               0.025
        CME.M2Kmain   微型E-迷你罗素2000指数期货 2409  M2Kmain            2024-09-20  futures         5.000000           CME          M2K        1         0                 0.1
        CME.MESmain        微型E-迷你标普500 2409  MESmain            2024-09-20  futures         5.000000           CME          MES        1         0                0.25
        CME.MNQmain        微型E-纳斯达克100 2409  MNQmain            2024-09-20  futures         2.000000           CME          MNQ        1         0                0.25
        CME.RTYmain     E-迷你罗素2000指数期货 2409  RTYmain            2024-09-20  futures        50.000000           CME          RTY        1         0                 0.1
        CBOT.MYMmain          微型E-迷你道指 2409  MYMmain            2024-09-20  futures         0.500000          CBOT          MYM        1         0                   1
        HKEX.HHImain              国企指数 2407  HHImain            2024-07-30  futures        50.000000          HKEX          HHI        1         0                   1
        HKEX.HSImain              恒生指数 2407  HSImain            2024-07-30  futures        50.000000          HKEX          HSI        1         0                   1
        HKEX.HTImain            恒生科技指数 2407  HTImain            2024-07-30  futures        50.000000          HKEX          HTI        1         0                   1
        HKEX.MCHmain              小型国企 2407  MCHmain            2024-07-30  futures        10.000000          HKEX          MCH        1         0                   1
        HKEX.MHImain              小型恒指 2407  MHImain            2024-07-30  futures        10.000000          HKEX          MHI        1         0                   1
        

